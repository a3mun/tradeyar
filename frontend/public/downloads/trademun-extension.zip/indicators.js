// indicators.js
(function() {
  'use strict';
  window.DGA_Indicators = {
    EMA: function(data, period) {
      const ema = []; const k = 2 / (period + 1); let prev = null;
      for (let i = 0; i < data.length; i++) {
        if (i < period - 1) { ema.push(null); continue; }
        if (prev === null) { let sum = 0; for (let j = 0; j < period; j++) sum += data[i - j]; prev = sum / period; }
        else { prev = (data[i] - prev) * k + prev; }
        ema.push(prev);
      }
      return ema;
    },
    RSI: function(closes, period = 14) {
      const rsi = new Array(closes.length).fill(null);
      if (closes.length < period + 1) return rsi;
      let avgGain = 0, avgLoss = 0;
      for (let i = 1; i <= period; i++) { const diff = closes[i] - closes[i - 1]; if (diff > 0) avgGain += diff; else avgLoss -= diff; }
      avgGain /= period; avgLoss /= period;
      rsi[period] = 100 - 100 / (1 + (avgGain / (avgLoss || 1)));
      for (let i = period + 1; i < closes.length; i++) {
        const diff = closes[i] - closes[i - 1]; const gain = diff > 0 ? diff : 0; const loss = diff < 0 ? -diff : 0;
        avgGain = (avgGain * (period - 1) + gain) / period; avgLoss = (avgLoss * (period - 1) + loss) / period;
        rsi[i] = 100 - 100 / (1 + (avgGain / (avgLoss || 1)));
      }
      return rsi;
    },
    ATR: function(highs, lows, closes, period = 14) {
      const tr = [];
      for (let i = 0; i < closes.length; i++) {
        if (i === 0) { tr.push(highs[0] - lows[0]); continue; }
        tr.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1])));
      }
      return this.EMA(tr, period);
    },
    ADX: function(highs, lows, closes, period = 14) {
      const len = closes.length;
      const plusDM = new Array(len).fill(0); const minusDM = new Array(len).fill(0); const tr = new Array(len).fill(0);
      for (let i = 1; i < len; i++) {
        const upMove = highs[i] - highs[i - 1]; const downMove = lows[i - 1] - lows[i];
        plusDM[i] = (upMove > downMove && upMove > 0) ? upMove : 0;
        minusDM[i] = (downMove > upMove && downMove > 0) ? downMove : 0;
        tr[i] = Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]));
      }
      const smoothTR = new Array(len).fill(null); const smoothPlusDM = new Array(len).fill(null); const smoothMinusDM = new Array(len).fill(null);
      let sumTR = 0, sumPlus = 0, sumMinus = 0;
      for (let i = 1; i <= period; i++) { sumTR += tr[i]; sumPlus += plusDM[i]; sumMinus += minusDM[i]; }
      smoothTR[period] = sumTR; smoothPlusDM[period] = sumPlus; smoothMinusDM[period] = sumMinus;
      for (let i = period + 1; i < len; i++) {
        smoothTR[i] = smoothTR[i - 1] - (smoothTR[i - 1] / period) + tr[i];
        smoothPlusDM[i] = smoothPlusDM[i - 1] - (smoothPlusDM[i - 1] / period) + plusDM[i];
        smoothMinusDM[i] = smoothMinusDM[i - 1] - (smoothMinusDM[i - 1] / period) + minusDM[i];
      }
      const plusDI = new Array(len).fill(null); const minusDI = new Array(len).fill(null); const dx = new Array(len).fill(null);
      for (let i = period; i < len; i++) {
        if (smoothTR[i] === 0) continue;
        plusDI[i] = 100 * (smoothPlusDM[i] / smoothTR[i]); minusDI[i] = 100 * (smoothMinusDM[i] / smoothTR[i]);
        const sum = plusDI[i] + minusDI[i]; dx[i] = sum === 0 ? 0 : 100 * Math.abs(plusDI[i] - minusDI[i]) / sum;
      }
      const adx = new Array(len).fill(null); let sumDX = 0; let count = 0;
      for (let i = period; i < len; i++) {
        if (dx[i] === null) continue;
        if (count < period) { sumDX += dx[i]; count++; if (count === period) adx[i] = sumDX / period; }
        else { adx[i] = ((adx[i - 1] * (period - 1)) + dx[i]) / period; }
      }
      return { adx, plusDI, minusDI };
    },
    BBands: function(closes, period = 20, stdDevMult = 2) {
      const sma = []; for (let i = 0; i < closes.length; i++) { if (i < period - 1) { sma.push(null); continue; } let sum = 0; for (let j = 0; j < period; j++) sum += closes[i - j]; sma.push(sum / period); }
      const upper = new Array(closes.length).fill(null); const lower = new Array(closes.length).fill(null); const width = new Array(closes.length).fill(null);
      for (let i = period - 1; i < closes.length; i++) {
        let sumSq = 0; for (let j = 0; j < period; j++) sumSq += Math.pow(closes[i - j] - sma[i], 2);
        const std = Math.sqrt(sumSq / period); upper[i] = sma[i] + (std * stdDevMult); lower[i] = sma[i] - (std * stdDevMult);
        width[i] = sma[i] > 0 ? ((upper[i] - lower[i]) / sma[i]) * 100 : 0;
      }
      return { upper, lower, mid: sma, width };
    },
    MACD: function(closes, fast = 12, slow = 26, signal = 9) {
      const emaFast = this.EMA(closes, fast); const emaSlow = this.EMA(closes, slow);
      const macdLine = new Array(closes.length).fill(null);
      for (let i = 0; i < closes.length; i++) { if (emaFast[i] !== null && emaSlow[i] !== null) macdLine[i] = emaFast[i] - emaSlow[i]; }
      const validMacd = macdLine.filter(v => v !== null); const signalLine = this.EMA(validMacd, signal);
      const alignedSignal = new Array(closes.length).fill(null); let idx = 0;
      for (let i = 0; i < closes.length; i++) { if (macdLine[i] !== null) { alignedSignal[i] = signalLine[idx] || null; idx++; } }
      const hist = new Array(closes.length).fill(null);
      for (let i = 0; i < closes.length; i++) { if (macdLine[i] !== null && alignedSignal[i] !== null) hist[i] = macdLine[i] - alignedSignal[i]; }
      return { macd: macdLine, signal: alignedSignal, hist };
    },
    Stochastic: function(highs, lows, closes, kPeriod = 14, dPeriod = 3) {
      const k = new Array(closes.length).fill(null); const d = new Array(closes.length).fill(null);
      for (let i = kPeriod - 1; i < closes.length; i++) {
        let highest = -Infinity; let lowest = Infinity;
        for (let j = 0; j < kPeriod; j++) { highest = Math.max(highest, highs[i - j]); lowest = Math.min(lowest, lows[i - j]); }
        const denom = highest - lowest; k[i] = denom === 0 ? 50 : 100 * (closes[i] - lowest) / denom;
      }
      for (let i = kPeriod + dPeriod - 2; i < closes.length; i++) { let sum = 0; for (let j = 0; j < dPeriod; j++) sum += k[i - j]; d[i] = sum / dPeriod; }
      return { k, d };
    },
    WilliamsR: function(highs, lows, closes, period = 14) {
      const willr = new Array(closes.length).fill(null);
      for (let i = period - 1; i < closes.length; i++) {
        let highest = -Infinity; let lowest = Infinity;
        for (let j = 0; j < period; j++) { highest = Math.max(highest, highs[i - j]); lowest = Math.min(lowest, lows[i - j]); }
        const denom = highest - lowest; willr[i] = denom === 0 ? -50 : -100 * (highest - closes[i]) / denom;
      }
      return willr;
    },
    CCI: function(highs, lows, closes, period = 20) {
      const cci = new Array(closes.length).fill(null); const tp = [];
      for (let i = 0; i < closes.length; i++) tp.push((highs[i] + lows[i] + closes[i]) / 3);
      const smaTP = []; for (let i = 0; i < tp.length; i++) { if (i < period - 1) { smaTP.push(null); continue; } let sum = 0; for (let j = 0; j < period; j++) sum += tp[i - j]; smaTP.push(sum / period); }
      for (let i = period - 1; i < closes.length; i++) {
        let meanDev = 0; for (let j = 0; j < period; j++) meanDev += Math.abs(tp[i - j] - smaTP[i]);
        meanDev /= period; cci[i] = meanDev === 0 ? 0 : (tp[i] - smaTP[i]) / (0.015 * meanDev);
      }
      return cci;
    },
    ROC: function(closes, period = 10) {
      const roc = new Array(closes.length).fill(null);
      for (let i = period; i < closes.length; i++) { if (closes[i - period] === 0) continue; roc[i] = ((closes[i] - closes[i - period]) / closes[i - period]) * 100; }
      return roc;
    },
    Supertrend: function(highs, lows, closes, period = 10, multiplier = 3) {
      const len = closes.length; const atr = this.ATR(highs, lows, closes, period);
      const upperBand = new Array(len).fill(null); const lowerBand = new Array(len).fill(null); const trend = new Array(len).fill(1);
      for (let i = period; i < len; i++) {
        const hl2 = (highs[i] + lows[i]) / 2; const basicUpper = hl2 + (multiplier * atr[i]); const basicLower = hl2 - (multiplier * atr[i]);
        if (i === period) { upperBand[i] = basicUpper; lowerBand[i] = basicLower; }
        else {
          upperBand[i] = (basicUpper < upperBand[i - 1] || closes[i - 1] > upperBand[i - 1]) ? basicUpper : upperBand[i - 1];
          lowerBand[i] = (basicLower > lowerBand[i - 1] || closes[i - 1] < lowerBand[i - 1]) ? basicLower : lowerBand[i - 1];
        }
        if (trend[i - 1] === 1) trend[i] = closes[i] < lowerBand[i] ? -1 : 1;
        else trend[i] = closes[i] > upperBand[i] ? 1 : -1;
      }
      return { direction: trend[len - 1], value: trend[len - 1] === 1 ? lowerBand[len - 1] : upperBand[len - 1] };
    }
  };
})();