// ui.js (نسخه نهایی فاز ۱۵.۲ - مخفی کردن دکمه‌های راهنما و ریست در حالت مینیمایز)
(function() {
  'use strict';

  const isAlpha = window.location.hostname.includes('alphagoldx');
  const exchangeName = isAlpha ? 'آلفا گلد' : 'دریا گلد';
  const logoUrl = chrome.runtime.getURL('icons/icon128.png');

  const COLORS = {
    bgMain: '#07111f',
    gold: '#d6ad60',
    goldLight: '#e2c17e',
    goldDark: '#c89a49',
    textWhite: '#f3f5f8',
    textGray: '#94a3b8',
    green: '#10b981',
    red: '#ef4444',
    yellow: '#eab308',
    cardBg: 'rgba(13, 27, 45, 0.7)',
    border: 'rgba(214, 173, 96, 0.2)'
  };

  let audioCtx = null;
  let isSubscriptionValid = false; 
  let isServerError = false; 
  let isSoundEnabled = localStorage.getItem('dga_sound_enabled') !== 'false';
  let isTVSoundEnabled = localStorage.getItem('dga_tv_sound_enabled') !== 'false';

  function initAudio() {
    if (!audioCtx) {
      try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
    }
  }
  document.addEventListener('click', initAudio, { once: true });

  // ═══════════════════════════════════════════════════════════
  // توابع کمکی
  // ═══════════════════════════════════════════════════════════
  function makeDraggable(elmnt, handle) {
    let isDragging = false, offsetX, offsetY;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
      isDragging = true;
      offsetX = e.clientX - elmnt.getBoundingClientRect().left;
      offsetY = e.clientY - elmnt.getBoundingClientRect().top;
      handle.style.cursor = 'grabbing';
    });
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      let newX = e.clientX - offsetX, newY = e.clientY - offsetY;
      const maxX = window.innerWidth - elmnt.offsetWidth;
      const maxY = window.innerHeight - elmnt.offsetHeight;
      newX = Math.max(0, Math.min(newX, maxX));
      newY = Math.max(0, Math.min(newY, maxY));
      elmnt.style.left = newX + 'px';
      elmnt.style.top = newY + 'px';
      elmnt.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        handle.style.cursor = 'grab';
        savePosition(elmnt);
      }
    });
  }

  function savePosition(el) {
    localStorage.setItem('dga_panel_pos', JSON.stringify({ top: el.style.top, left: el.style.left }));
  }

  function restorePosition(el) {
    const saved = localStorage.getItem('dga_panel_pos');
    if (saved) {
      try {
        const pos = JSON.parse(saved);
        if (pos.top) el.style.top = pos.top;
        if (pos.left) el.style.left = pos.left;
        el.style.right = 'auto';
      } catch(e) {}
    }
  }

  function restoreMinimizedState(panel) {
    const isMinimized = localStorage.getItem('dga_panel_minimized') === 'true';
    const body = document.getElementById('dga-body');
    const toggleBtn = document.getElementById('dga-toggle-btn');
    const helpBtn = document.getElementById('dga-help-btn');
    const resetBtn = document.getElementById('dga-reset-btn'); // 👈 دکمه ریست
    const miniSummary = document.getElementById('dga-mini-summary');
    
    if (isMinimized) {
      body.style.display = 'none';
      if (helpBtn) helpBtn.style.display = 'none';
      if (resetBtn) resetBtn.style.display = 'none'; // 👈 مخفی کردن ریست
      if (miniSummary) miniSummary.style.display = 'flex';
      panel.style.minHeight = 'unset';
      panel.style.height = 'auto';
      if (toggleBtn) toggleBtn.innerText = '+';
    } else {
      if (miniSummary) miniSummary.style.display = 'none';
      if (helpBtn) helpBtn.style.display = 'flex';
      if (resetBtn) resetBtn.style.display = 'flex'; // 👈 نمایش ریست
    }
  }

  function setupToggles() {
    const toggleBtn = document.getElementById('dga-toggle-btn');
    const body = document.getElementById('dga-body');
    const helpBtn = document.getElementById('dga-help-btn');
    const resetBtn = document.getElementById('dga-reset-btn');
    const miniSummary = document.getElementById('dga-mini-summary');
    const panel = document.getElementById('dga-panel');
    
    if (!toggleBtn) return;
    
    toggleBtn.onclick = () => {
      const isCurrentlyMinimized = localStorage.getItem('dga_panel_minimized') === 'true';
      const newState = !isCurrentlyMinimized;
      
      if (newState) {
        body.style.display = 'none';
        if (helpBtn) helpBtn.style.display = 'none';
        if (resetBtn) resetBtn.style.display = 'none'; // 👈 مخفی کردن ریست
        if (miniSummary) miniSummary.style.display = 'flex';
        panel.style.minHeight = 'unset';
        panel.style.height = 'auto';
        toggleBtn.innerText = '+';
        localStorage.setItem('dga_panel_minimized', 'true');
      } else {
        body.style.display = 'block';
        if (helpBtn) helpBtn.style.display = 'flex';
        if (resetBtn) resetBtn.style.display = 'flex'; // 👈 نمایش ریست
        if (miniSummary) miniSummary.style.display = 'none';
        panel.style.minHeight = '300px';
        panel.style.height = '';
        toggleBtn.innerText = '−';
        localStorage.setItem('dga_panel_minimized', 'false');
      }
    };
  }

  function setupHideButton() {
    const hideBtn = document.getElementById('dga-hide-btn');
    if (!hideBtn) return;
    hideBtn.onclick = (e) => {
      e.stopPropagation();
      document.getElementById('dga-panel').style.display = 'none';
      localStorage.setItem('dga_panel_hidden', 'true');
      chrome.runtime.sendMessage({ action: 'PANEL_HIDDEN' }, () => {});
    };
  }

  function setupReset() {
    const resetBtn = document.getElementById('dga-reset-btn');
    if (!resetBtn) return;
    resetBtn.onclick = (e) => {
      e.stopPropagation();
      if (confirm('⚠️ آیا از پاک کردن تمام کندل‌ها و شروع مجدد جمع‌آوری اطلاعات مطمئن هستید؟')) {
        const priceEl = document.getElementById('dga-price');
        if (priceEl) priceEl.innerText = 'در حال ریست...';
        const lastPrice = (window.DGA_UI && window.DGA_UI.lastData) ? window.DGA_UI.lastData.price : 0;
        window.postMessage({ type: 'DGA_RESET_DATA', lastPrice: lastPrice }, '*');
        setTimeout(() => {
          if (priceEl) priceEl.innerText = 'ریست شد ✓';
          setTimeout(() => { if (priceEl) priceEl.innerText = '--'; }, 2000);
        }, 1500);
      }
    };
  }

  function setupSound() {
    const soundBtn = document.getElementById('dga-sound-btn');
    if (!soundBtn) return;
    updateSoundBtnStyle(soundBtn, isSoundEnabled);
    
    soundBtn.onclick = (e) => {
      e.stopPropagation();
      isSoundEnabled = !isSoundEnabled;
      localStorage.setItem('dga_sound_enabled', isSoundEnabled ? 'true' : 'false');
      updateSoundBtnStyle(soundBtn, isSoundEnabled);
    };
  }

  function updateSoundBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; btn.innerText = '🔊'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; btn.innerText = '🔇'; }
  }

  function setupTVSound() {
    const tvSoundBtn = document.getElementById('dga-tv-sound-btn');
    if (!tvSoundBtn) return;
    updateTVSoundBtnStyle(tvSoundBtn, isTVSoundEnabled);
    
    tvSoundBtn.onclick = (e) => {
      e.stopPropagation();
      isTVSoundEnabled = !isTVSoundEnabled;
      localStorage.setItem('dga_tv_sound_enabled', isTVSoundEnabled ? 'true' : 'false');
      updateTVSoundBtnStyle(tvSoundBtn, isTVSoundEnabled);
    };
  }

  function updateTVSoundBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; btn.innerText = '🔔'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; btn.innerText = '🔕'; }
  }

  function setupHelp() {
    const helpBtn = document.getElementById('dga-help-btn');
    if (helpBtn) {
      helpBtn.onclick = () => {
        document.getElementById('dga-modal').style.display = 'flex';
      };
    }
  }

  function setupModal() {
    const modalClose = document.getElementById('dga-modal-close');
    if (modalClose) {
      modalClose.onclick = () => {
        document.getElementById('dga-modal').style.display = 'none';
      };
    }
    const modalAccept = document.getElementById('dga-modal-accept');
    if (modalAccept) {
      modalAccept.onclick = () => {
        document.getElementById('dga-modal').style.display = 'none';
      };
    }
  }

  function setupAlarmButtons() {
    document.querySelectorAll('.dga-alarm-btn').forEach(btn => {
      const layer = btn.getAttribute('data-layer');
      const isEnabled = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
      updateAlarmBtnStyle(btn, isEnabled);
      btn.onclick = (e) => {
        e.stopPropagation();
        const current = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
        localStorage.setItem(`dga_alarm_layer_${layer}`, current ? 'false' : 'true');
        updateAlarmBtnStyle(btn, !current);
      };
    });
  }

  function updateAlarmBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; }
  }

  function setupTVButton() {
    const btn = document.getElementById('dga-tv-launch-btn');
    if (btn) {
      btn.onclick = () => {
        window.open('https://www.tradingview.com/symbols/XAUUSD/technicals/?exchange=FOREXCOM', '_blank');
      };
    }
  }

  function setupCopyHandlers() {
    document.querySelectorAll('.dga-copyable').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = el.innerText;
        if (!text || text === '--') return;
        navigator.clipboard.writeText(text).then(() => {
          const originalText = el.innerText;
          el.innerText = 'کپی شد!';
          el.style.color = COLORS.green;
          setTimeout(() => { el.innerText = originalText; el.style.color = ''; }, 1000);
        }).catch(() => {});
      });
    });
  }

  // ═══════════════════════════════════════════════════════════
  // ساخت پنل
  // ═══════════════════════════════════════════════════════════
  function createPanel() {
    if (document.getElementById('dga-panel')) return;
    if (localStorage.getItem('dga_panel_hidden') === 'true') return; 

    const panel = document.createElement('div');
    panel.id = 'dga-panel';
    panel.className = 'dga-panel';
    
    panel.style.backgroundImage = `url('${logoUrl}')`;
    panel.style.backgroundRepeat = 'no-repeat';
    panel.style.backgroundPosition = 'center center';
    panel.style.backgroundSize = '40%';
    panel.style.backgroundColor = COLORS.cardBg;
    panel.style.backgroundBlendMode = 'overlay';
    
    panel.innerHTML = `
      <div class="dga-header" id="dga-drag-handle">
        <div class="dga-title" style="color: ${COLORS.textWhite};">نوسان‌گیر تریدمون (${exchangeName}) <span id="dga-mini-lock-icon" style="display:none; color:${COLORS.red}; font-size:10px;">🔒</span></div>
        <div class="dga-header-actions">
          <button class="dga-icon-btn" id="dga-help-btn" title="راهنما" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold};">؟</button>
          <button class="dga-icon-btn" id="dga-sound-btn" title="صدا" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold};">🔊</button>
          <button class="dga-icon-btn" id="dga-reset-btn" title="ریست" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold};">↺</button>
          <button class="dga-icon-btn" id="dga-hide-btn" title="مخفی کردن پنل" style="background: rgba(239, 68, 68, 0.1); color: ${COLORS.red};">✖</button>
          <button class="dga-toggle-btn" id="dga-toggle-btn" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold}; font-weight: bold;">−</button>
        </div>
      </div>
      
      <div class="dga-body" id="dga-body" style="position: relative;">
        
        <div id="dga-auth-warning" style="
          display: none; flex-direction: column; align-items: center; justify-content: center;
          text-align: center; padding: 20px; box-sizing: border-box;
          background: linear-gradient(145deg, ${COLORS.bgMain}, #0d1b2d);
          border-radius: 8px; margin: 10px 0; border: 1px solid rgba(239, 68, 68, 0.3);
        ">
          <div id="auth-icon" style="font-size: 40px; margin-bottom: 10px;">🔒</div>
          <div id="auth-title" style="color: ${COLORS.red}; font-weight: bold; margin-bottom: 8px; font-size: 14px;">اشتراک شما فعال نیست</div>
          <div id="auth-desc" style="color: ${COLORS.textGray}; font-size: 11px; margin-bottom: 16px; line-height: 1.6;">
            برای مشاهده تحلیل‌ها، از سایت تریدمون اشتراک تهیه کنید.<br>
            <span style="color: ${COLORS.green}; margin-top: 4px; display: inline-block;">(دیتا در پس‌زمینه در حال جمع‌آوری است)</span>
          </div>
          <a href="https://trademun.ir/dashboard" target="_blank" style="background: ${COLORS.gold}; color: ${COLORS.bgMain}; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 12px;">رفتن به داشبورد</a>
        </div>

        <div id="dga-body-content">
            <div id="dga-stale-warning" style="
              display: none; align-items: center; justify-content: center; gap: 6px;
              background: rgba(234, 179, 8, 0.15); border: 1px solid rgba(234, 179, 8, 0.4);
              color: ${COLORS.yellow}; border-radius: 6px; padding: 6px 10px; margin-bottom: 6px;
              font-size: 10px; text-align: center; line-height: 1.4;
            ">
              <span style="font-size: 14px;">⚠️</span>
              <span>دیتای فعلی قدیمی است (بیش از ۱ ساعت). برای نتایج دقیق‌تر، از دکمه ریست (↺) استفاده کنید.</span>
            </div>

            <div class="dga-price-compare-bar">
              <div class="dga-price-compare-item">
                <span class="dga-pc-label" style="color: ${COLORS.textGray};">قیمت صرافی:</span>
                <span class="dga-pc-value" id="dga-price" style="color: ${COLORS.textWhite};">--</span>
              </div>
              <div class="dga-price-compare-item">
                <span class="dga-pc-label" title="قیمت فارکس (XAUUSD) از TradingView" style="color: ${COLORS.textGray};">قیمت فارکس:</span>
                <span class="dga-pc-value" id="dga-tv-price" style="color: ${COLORS.textWhite};">--</span>
              </div>
            </div>

            <div class="dga-top-bar">
              <div class="dga-progress-wrapper">
                <span class="dga-progress-label" style="color: ${COLORS.textGray};">کندل‌ها</span>
                <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-candle-progress"></div></div>
                <span class="dga-progress-text" id="dga-candle-progress-text" style="color: ${COLORS.textWhite};">0/200</span>
              </div>
            </div>

            <div class="dga-session-bar" id="dga-session-bar">
              <span id="dga-session-text">در حال بررسی سشن...</span>
            </div>

            <div class="dga-section-container">
              <div class="dga-section-header">
                <span class="dga-section-title" style="color: ${COLORS.gold}; font-size: 10px;">تحلیل سایت TradingView — برای فعال شدن روی دکمه زیر کلیک کنید</span>
              </div>
              
              <div class="dga-tv-launcher">
                <button class="dga-tv-launch-btn" id="dga-tv-launch-btn" style="background: linear-gradient(135deg, ${COLORS.goldDark}, ${COLORS.gold}); color: ${COLORS.bgMain}; font-weight: bold; font-size: 11px;">
                  دریافت اطلاعات نماد انس طلا در بازار فارکس
                </button>
              </div>

              <div class="dga-tv-summary-card-big" id="dga-tv-summary-card-big" style="position: relative;">
                <div class="dga-tv-summary-big-header">
                  <span class="dga-tv-summary-big-title" style="color: ${COLORS.textWhite};">🎯 خلاصه سیگنال هدف (تایم‌فریم ۱ دقیقه)</span>
                  <button class="dga-icon-btn" id="dga-tv-sound-btn" title="صدای TradingView" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold}; width: 20px; height: 20px; font-size: 10px;">🔔</button>
                </div>
                <div class="dga-tv-summary-big-signal" id="dga-tv-summary-big-signal">--</div>
                <div class="dga-tv-summary-big-counts">
                  <span class="sell" style="color: ${COLORS.red};">🔻 فروش: <b id="dga-tv-summary-big-sell">0</b></span>
                  <span class="neutral" style="color: ${COLORS.yellow};">⚪ خنثی: <b id="dga-tv-summary-big-neutral">0</b></span>
                  <span class="buy" style="color: ${COLORS.green};">🔺 خرید: <b id="dga-tv-summary-big-buy">0</b></span>
                </div>
              </div>

              <div class="dga-tv-cards-grid">
                <div class="dga-tv-card dga-tv-osc-card">
                  <div class="dga-tv-card-header">
                    <span class="dga-tv-card-title" style="color: ${COLORS.textGray};">📊 نوسانگیر</span>
                    <span class="dga-tv-badge" id="dga-tv-osc-badge">--</span>
                  </div>
                  <div class="dga-tv-card-counts">
                    <span class="sell" style="color: ${COLORS.red};">فروش: <b id="dga-tv-osc-sell">0</b></span>
                    <span class="neutral" style="color: ${COLORS.yellow};">خنثی: <b id="dga-tv-osc-neutral">0</b></span>
                    <span class="buy" style="color: ${COLORS.green};">خرید: <b id="dga-tv-osc-buy">0</b></span>
                  </div>
                </div>
                <div class="dga-tv-card dga-tv-ma-card">
                  <div class="dga-tv-card-header">
                    <span class="dga-tv-card-title" style="color: ${COLORS.textGray};">📈 میانگین متحرک</span>
                    <span class="dga-tv-badge" id="dga-tv-ma-badge">--</span>
                  </div>
                  <div class="dga-tv-card-counts">
                    <span class="sell" style="color: ${COLORS.red};">فروش: <b id="dga-tv-ma-sell">0</b></span>
                    <span class="neutral" style="color: ${COLORS.yellow};">خنثی: <b id="dga-tv-ma-neutral">0</b></span>
                    <span class="buy" style="color: ${COLORS.green};">خرید: <b id="dga-tv-ma-buy">0</b></span>
                  </div>
                </div>
              </div>
            </div>

            <div class="dga-section-container" style="margin-top: 10px;">
              <div class="dga-section-header">
                <span class="dga-section-title" style="color: ${COLORS.gold}; font-size: 10px;">تحلیل تیم Trademun (بر اساس کندل های یک دقیقه)</span>
              </div>

              <div class="dga-volatility-warning" id="dga-volatility-warning" style="display: none; color: ${COLORS.red};">
                <span>⚠️ نوسان بالا — با احتیاط معامله کن.</span>
              </div>

              <div class="dga-layers-grid">
                <div class="dga-layer-card" id="dga-layer1-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title" style="color: ${COLORS.textGray};">⚡ ۳ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="1">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer1-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer1-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer1-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer1-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer1-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer1-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer1-tp" class="dga-copyable">--</b></span>
                  </div>
                </div>
                
                <div class="dga-layer-card" id="dga-layer2-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title" style="color: ${COLORS.textGray};">🎯 ۱۵ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="2">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer2-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer2-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer2-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer2-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer2-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer2-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer2-tp" class="dga-copyable">--</b></span>
                  </div>
                </div>
                
                <div class="dga-layer-card" id="dga-layer3-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title" style="color: ${COLORS.textGray};">📊 ۵۰ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="3">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer3-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer3-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer3-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer3-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer3-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer3-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer3-tp" class="dga-copyable">--</b></span>
                  </div>
                </div>
                
                <div class="dga-layer-card" id="dga-layer4-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title" style="color: ${COLORS.textGray};">🏆 ۲۰۰ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="4">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer4-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer4-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer4-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer4-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer4-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer4-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer4-tp" class="dga-copyable">--</b></span>
                  </div>
                </div>
              </div>

              <div class="dga-consensus-card" id="dga-consensus-card">
                <div class="dga-consensus-header">
                  <span class="dga-consensus-title" style="color: ${COLORS.textWhite};">🎯 نتیجه نهایی Trademun</span>
                  <span class="dga-consensus-confidence" id="dga-consensus-confidence" style="color: ${COLORS.gold};">0%</span>
                </div>
                <div class="dga-consensus-text" id="dga-consensus-text" style="color: ${COLORS.textGray};">--</div>
              </div>
            </div>
        </div> 

      </div>

      <div class="dga-mini-summary" id="dga-mini-summary" style="display: none; position: relative;">
        <div id="mini-blur-overlay" style="
          position: absolute; top: 0; left: 0; width: 100%; height: 100%;
          background: ${COLORS.bgMain}; 
          display: none; flex-direction: column; align-items: center; justify-content: center;
          border-radius: 6px; z-index: 10;
        ">
          <span style="color: ${COLORS.red}; font-size: 11px; font-weight: bold;">اشتراک غیرفعال 🔒</span>
        </div>

        <div class="dga-mini-row">
          <div class="dga-mini-item">
            <span class="dga-mini-label" style="color: ${COLORS.textGray};">فارکس:</span>
            <span class="dga-mini-value" id="mini-val-tv">--</span>
          </div>
          <div class="dga-mini-item">
            <span class="dga-mini-label" style="color: ${COLORS.textGray};">قیمت:</span>
            <span class="dga-mini-value" id="mini-val-price">--</span>
          </div>
        </div>
        <div class="dga-mini-row">
          <div class="dga-mini-item">
            <span class="dga-mini-label" style="color: ${COLORS.textGray};">۳ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l1">--</span>
          </div>
          <div class="dga-mini-item">
            <span class="dga-mini-label" style="color: ${COLORS.textGray};">۱۵ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l2">--</span>
          </div>
        </div>
        <div class="dga-mini-row">
          <div class="dga-mini-item">
            <span class="dga-mini-label" style="color: ${COLORS.textGray};">۵۰ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l3">--</span>
          </div>
          <div class="dga-mini-item">
            <span class="dga-mini-label" style="color: ${COLORS.textGray};">۲۰۰ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l4">--</span>
          </div>
        </div>
      </div>
      
      <div class="dga-modal" id="dga-modal" style="display:none;">
        <div class="dga-modal-content">
          <div class="dga-modal-header">
            <h3 style="color: ${COLORS.gold};">راهنمای جامع نوسان‌گیر تریدمون</h3>
            <button id="dga-modal-close" style="color: ${COLORS.textGray};">×</button>
          </div>
          <div class="dga-modal-body">
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 12px; margin-bottom: 16px;">
              <h4 style="color: ${COLORS.red}; margin-top: 0; font-size: 13px;">⚠️ سلب مسئولیت و قوانین معاملاتی</h4>
              <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; margin: 0; text-align: justify;">
                سایت <b>تریدمون</b> صرفاً یک <b>تحلیل‌گر داده</b> و ارائه‌دهنده سیگنال‌های کمکی است. تمامی تحلیل‌ها بر اساس الگوریتم‌های ریاضی و داده‌های تاریخی انجام می‌شود و <b>هیچ‌گونه تضمینی برای سودآوری وجود ندارد</b>. تصمیم‌گیری نهایی برای ورود یا خروج از معامله، کاملاً بر عهده کاربر است و تریدمون هیچ مسئولیتی در قبال سود یا زیان احتمالی کاربران نمی‌پذیرد.
              </p>
            </div>

            <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">⏳ چرا باید صبر کنید؟ (مهم)</h4>
            <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; text-align: justify;">
              به دلیل عدم فعالیت رباتی و <b>محافظت از حساب شما در صرافی</b>، اکستنشن برای راه‌اندازی اولیه و اطمینان از صحت سیگنال‌ها، نیاز به جمع‌آوری حداقل <b>۱۵ کندل (۱۵ دقیقه)</b> دارد. 
              <br><br>
              🔹 <b>توصیه اکید:</b> لطفاً پس از باز کردن صفحه صرافی، حداقل <b>یک ساعت</b> به اکستنشن زمان دهید تا دیتای کافی جمع‌آوری شده و تحلیل‌های لایه‌های بالاتر (مانند ۵۰ و ۲۰۰ کندل) فعال شوند. سپس به سیگنال‌ها توجه کنید.
            </p>

            <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">🔌 اکستنشن چطور کار می‌کند؟</h4>
            <ul style="padding-right: 20px; margin: 0 0 12px 0; font-size: 11px; line-height: 1.8; color: ${COLORS.textGray}; text-align: justify;">
              <li>اکستنشن به صورت خودکار به WebSocket داخلی صرافی متصل می‌شود و قیمت‌های لحظه‌ای را بدون دستکاری در حساب شما دریافت می‌کند.</li>
              <li>داده‌ها در مرورگر شما (لوکال) به کندل تبدیل می‌شوند و تحلیل روی همین کندل‌ها انجام می‌شود.</li>
              <li>هیچ‌گونه سفارش خرید یا فروشی به صورت خودکار ثبت نمی‌شود.</li>
            </ul>

            <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">📊 امکانات آپشنال (درصد سود/زیان)</h4>
            <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; text-align: justify;">
              ما یک قابلیت اختیاری اضافه کردیم که درصد سود/زیان و قیمت لحظه‌ای هر معامله را در جدول معاملات صرافی نمایش می‌دهد. این اطلاعات در کنار هم قابل کپی هستند (برای کپی، روی قیمت کلیک کنید). اگر نمی‌خواهید این اطلاعات نمایش داده شوند، می‌توانید از طریق <b>پاپ‌آپ افزونه</b> (کلید «نمایش امکانات آپشنال») آن را غیرفعال کنید.
            </p>

            <div style="text-align: center; margin-top: 20px; border-top: 1px solid rgba(75, 85, 99, 0.3); padding-top: 12px;">
              <button id="dga-modal-accept" style="background: ${COLORS.gold}; color: ${COLORS.bgMain}; padding: 10px 24px; border-radius: 6px; border: none; font-weight: bold; font-size: 13px; cursor: pointer; width: 100%;">مطالعه کردم، ببند</button>
            </div>
          </div>
        </div>
      </div>

      <div class="dga-modal" id="dga-first-time-modal" style="display: none; z-index: 1000001;">
        <div class="dga-modal-content" style="text-align: center;">
          <div style="font-size: 50px; margin-bottom: 10px;">👋</div>
          <h3 style="color: ${COLORS.gold}; font-size: 16px; margin-bottom: 12px;">به نوسان‌گیر تریدمون خوش آمدید!</h3>
          <p style="font-size: 12px; color: ${COLORS.textGray}; line-height: 1.8; margin-bottom: 20px; text-align: justify;">
            برای شروع، لطفاً به این چند نکته توجه کنید:
            <br><br>
            🔹 <b>تایم جمع‌آوری:</b> برای عملکرد صحیح، حداقل <b>۱۵ کندل (۱۵ دقیقه)</b> صبر کنید.
            <br>
            🔹 <b>دکمه ریست:</b> بعد از هر چند ساعت که سیستم خاموش بوده، حتماً دکمه <b>ریست (↺)</b> را بزنید تا دیتای جدید جمع‌آوری شود.
            <br>
            🔹 <b>رفرش صفحه:</b> بعد از هر تغییر در افزونه، صفحه مرورگر را <b>رفرش (F5)</b> کنید.
            <br><br>
            <span style="color: ${COLORS.green};">برای اطلاعات بیشتر، از دکمه «راهنما» در بالای پنل استفاده کنید.</span>
          </p>
          <button id="dga-first-time-accept" style="background: ${COLORS.gold}; color: ${COLORS.bgMain}; padding: 10px 24px; border-radius: 6px; border: none; font-weight: bold; font-size: 13px; cursor: pointer;">
            متوجه شدم
          </button>
        </div>
      </div>
    `;
    
    document.body.appendChild(panel);
    panel.style.display = 'none';

    makeDraggable(panel, document.getElementById('dga-drag-handle'));
    setupToggles();
    setupHideButton(); 
    setupReset();
    setupSound();
    setupTVSound();
    setupHelp();
    setupModal();
    setupAlarmButtons();
    setupTVButton();
    setupCopyHandlers();
    restorePosition(panel);
    restoreMinimizedState(panel);

    const isFirstTimeModal = !localStorage.getItem('dga_first_time_modal');
    if (isFirstTimeModal) {
      const firstTimeModal = document.getElementById('dga-first-time-modal');
      if (firstTimeModal) {
        firstTimeModal.style.display = 'flex';
        document.getElementById('dga-first-time-accept').onclick = () => {
          firstTimeModal.style.display = 'none';
          localStorage.setItem('dga_first_time_modal', 'true');
        };
      }
    }

    setTimeout(() => {
      if (window.DGA_UI && window.DGA_UI.update) {
        window.DGA_UI.update({
          candlesCount: 0, price: 0, isFirstTime: false,
          session: { name: 'unknown', warning: false, message: 'در انتظار داده...' },
          layer1: null, layer2: null, layer3: null, layer4: null,
          consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
        });
      }
    }, 500);
  }

  // ═══════════════════════════════════════════════════════════
  // آلارم‌ها
  // ═══════════════════════════════════════════════════════════
  function playBeep(isStrong = false) {
    if (!audioCtx || !isSoundEnabled) return;
    try {
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      if (isStrong) {
        osc.frequency.value = 1000;
        gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + 0.3);
      } else {
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + 0.2);
      }
    } catch (e) {}
  }

  function flashCard(layer) {
    const card = document.getElementById(`dga-layer${layer}-card`);
    if (!card) return;
    card.style.animation = 'flash 0.5s ease-in-out 3';
    setTimeout(() => { card.style.animation = ''; }, 1500);
  }

  function flashTVCard() {
    const card = document.getElementById('dga-tv-summary-card-big');
    if (!card) return;
    card.style.animation = 'flash 0.5s ease-in-out 3';
    setTimeout(() => { card.style.animation = ''; }, 1500);
  }

  // ═══════════════════════════════════════════════════════════
  // آپدیت UI
  // ═══════════════════════════════════════════════════════════
  function updateUI(data) {
    if (!window.DGA_UI) window.DGA_UI = {};
    window.DGA_UI.lastData = data;

    const authWarning = document.getElementById('dga-auth-warning');
    const bodyContent = document.getElementById('dga-body-content');
    const miniLock = document.getElementById('dga-mini-lock-icon');
    const miniBlurOverlay = document.getElementById('mini-blur-overlay');
    const authIcon = document.getElementById('auth-icon');
    const authTitle = document.getElementById('auth-title');
    const authDesc = document.getElementById('auth-desc');
    const panel = document.getElementById('dga-panel');
    const staleWarning = document.getElementById('dga-stale-warning');

    // 👈 چک کردن وضعیت مخفی بودن قبل از هر نمایش
    if (localStorage.getItem('dga_panel_hidden') === 'true') {
      if (panel) panel.style.display = 'none';
      return;
    }

    if (panel && panel.style.display === 'none' && (isSubscriptionValid || isServerError)) {
      panel.style.display = 'block';
    }

    if (staleWarning) {
      staleWarning.style.display = (data.staleWarning && isSubscriptionValid) ? 'flex' : 'none';
    }

    if (!isSubscriptionValid) {
      if (authWarning) {
        authWarning.style.display = 'flex';
        if (isServerError) {
          if (authIcon) authIcon.innerText = '📡';
          if (authTitle) { authTitle.innerText = 'خطا در ارتباط با سرور'; authTitle.style.color = COLORS.yellow; }
          if (authDesc) authDesc.innerHTML = 'لطفاً اتصال اینترنت خود را بررسی کنید.<br><span style="color: #9ca3af;">(در حال تلاش مجدد...)</span>';
        } else {
          if (authIcon) authIcon.innerText = '🔒';
          if (authTitle) { authTitle.innerText = 'اشتراک شما فعال نیست'; authTitle.style.color = COLORS.red; }
          if (authDesc) authDesc.innerHTML = 'برای مشاهده تحلیل‌ها، از سایت تریدمون اشتراک تهیه کنید.<br><span style="color: #34d399; margin-top: 4px; display: inline-block;">(دیتا در پس‌زمینه در حال جمع‌آوری است)</span>';
        }
      }
      if (bodyContent) bodyContent.style.display = 'none';
      if (miniLock) miniLock.style.display = 'inline';
      if (miniBlurOverlay) {
        miniBlurOverlay.style.display = (!isSubscriptionValid) ? 'flex' : 'none';
      }
    } else {
      if (authWarning) authWarning.style.display = 'none';
      if (bodyContent) bodyContent.style.display = 'block';
      if (miniLock) miniLock.style.display = 'none';
      if (miniBlurOverlay) miniBlurOverlay.style.display = 'none';
      
      if (data.price) {
        const priceEl = document.getElementById('dga-price');
        if (priceEl) priceEl.innerText = data.price.toFixed(2);
      }
      
      const count = data.candlesCount || 0;
      const progressEl = document.getElementById('dga-candle-progress');
      if (progressEl) progressEl.style.width = Math.min(100, (count / 200) * 100) + '%';
      const progressTextEl = document.getElementById('dga-candle-progress-text');
      if (progressTextEl) progressTextEl.innerText = `${count}/200`;

      if (data.session) {
        const sessionBar = document.getElementById('dga-session-bar');
        const sessionText = document.getElementById('dga-session-text');
        if (sessionBar && sessionText) {
          sessionText.innerText = data.session.message;
          sessionBar.className = 'dga-session-bar' + (data.session.warning ? ' warning' : ' normal');
        }
      }

      if (data.tvData) {
        const tv = data.tvData;
        const tvPriceEl = document.getElementById('dga-tv-price');
        if (tvPriceEl && tv.price) tvPriceEl.innerText = tv.price;

        const oscBadge = document.getElementById('dga-tv-osc-badge');
        if (oscBadge && tv.oscillatorsSignal) {
          oscBadge.innerText = tv.oscillatorsSignal;
          oscBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.oscillatorsSignal);
        }
        if (tv.oscCounts) {
          document.getElementById('dga-tv-osc-sell').innerText = tv.oscCounts.sell || 0;
          document.getElementById('dga-tv-osc-neutral').innerText = tv.oscCounts.neutral || 0;
          document.getElementById('dga-tv-osc-buy').innerText = tv.oscCounts.buy || 0;
        }

        const maBadge = document.getElementById('dga-tv-ma-badge');
        if (maBadge && tv.movingAveragesSignal) {
          maBadge.innerText = tv.movingAveragesSignal;
          maBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.movingAveragesSignal);
        }
        if (tv.maCounts) {
          document.getElementById('dga-tv-ma-sell').innerText = tv.maCounts.sell || 0;
          document.getElementById('dga-tv-ma-neutral').innerText = tv.maCounts.neutral || 0;
          document.getElementById('dga-tv-ma-buy').innerText = tv.maCounts.buy || 0;
        }

        const bigSignal = document.getElementById('dga-tv-summary-big-signal');
        const bigCard = document.getElementById('dga-tv-summary-card-big');

        if (tv.summary && bigSignal) {
          const prevSignal = bigSignal.innerText;
          bigSignal.innerText = tv.summary;
          bigSignal.className = 'dga-tv-summary-big-signal ' + getBadgeClass(tv.summary);

          if (bigCard) {
            bigCard.classList.remove('summary-long', 'summary-short', 'summary-neutral');
            const tvSumLower = tv.summary.toLowerCase();
            if (tvSumLower.includes('buy')) bigCard.classList.add('summary-long');
            else if (tvSumLower.includes('sell')) bigCard.classList.add('summary-short');
            else bigCard.classList.add('summary-neutral');
          }

          const tvSumLower = tv.summary.toLowerCase();
          if (tvSumLower.includes('strong buy') || tvSumLower.includes('strong sell')) {
            if (isTVSoundEnabled && prevSignal !== tv.summary) {
              playBeep(false);
              if (bigCard) {
                bigCard.style.animation = 'flash 0.5s ease-in-out 3';
                setTimeout(() => { bigCard.style.animation = ''; }, 1500);
              }
            }
          }
        }
        if (tv.summaryCounts) {
          const bigSell = document.getElementById('dga-tv-summary-big-sell');
          const bigNeutral = document.getElementById('dga-tv-summary-big-neutral');
          const bigBuy = document.getElementById('dga-tv-summary-big-buy');
          if (bigSell) bigSell.innerText = tv.summaryCounts.sell || 0;
          if (bigNeutral) bigNeutral.innerText = tv.summaryCounts.neutral || 0;
          if (bigBuy) bigBuy.innerText = tv.summaryCounts.buy || 0;
        }
      } else {
        const ids = ['osc', 'ma'];
        ids.forEach(id => {
          const badge = document.getElementById(`dga-tv-${id}-badge`);
          if (badge) {
            badge.innerText = 'نامشخص';
            badge.className = 'dga-tv-badge dga-tv-neutral';
          }
        });
        const bigSignal = document.getElementById('dga-tv-summary-big-signal');
        if (bigSignal) {
          bigSignal.innerText = '--';
          bigSignal.className = 'dga-tv-summary-big-signal';
        }
      }

      const volWarning = document.getElementById('dga-volatility-warning');
      if (volWarning) volWarning.style.display = data.volatilityWarning ? 'flex' : 'none';

      const layers = [data.layer1, data.layer2, data.layer3, data.layer4];
      layers.forEach((layer, idx) => {
        const num = idx + 1;
        const card = document.getElementById(`dga-layer${num}-card`);
        if (!card) return;
        if (layer) {
          document.getElementById(`dga-layer${num}-badge`).innerText = layer.strength;
          document.getElementById(`dga-layer${num}-signal`).innerText = layer.signal;
          document.getElementById(`dga-layer${num}-confidence`).style.width = layer.confidence + '%';
          document.getElementById(`dga-layer${num}-confidence-text`).innerText = layer.confidence + '%';
          // 👈 دلایل فنی حذف شد
          card.className = `dga-layer-card dga-layer${num}-active`;
          if (layer.direction === 'long') card.classList.add('dga-layer-long');
          else if (layer.direction === 'short') card.classList.add('dga-layer-short');
          
          const badge = document.getElementById(`dga-layer${num}-badge`);
          if (layer.strength === 'قوی') badge.style.background = 'rgba(16, 185, 129, 0.3)';
          else if (layer.strength === 'متوسط') badge.style.background = 'rgba(234, 179, 8, 0.3)';
          else badge.style.background = 'rgba(107, 114, 128, 0.3)';

          const slTpDiv = document.getElementById(`dga-layer${num}-sl-tp`);
          if (layer.sl && layer.tp) {
            slTpDiv.style.display = 'flex';
            document.getElementById(`dga-layer${num}-sl`).innerText = layer.sl;
            document.getElementById(`dga-layer${num}-tp`).innerText = layer.tp;
          } else {
            slTpDiv.style.display = 'none';
          }
        }
      });

      if (data.consensus) {
        const card = document.getElementById('dga-consensus-card');
        const textEl = document.getElementById('dga-consensus-text');
        const confEl = document.getElementById('dga-consensus-confidence');
        if (card && textEl && confEl) {
          card.className = 'dga-consensus-card';
          if (data.consensus.direction === 'long') card.classList.add('dga-consensus-long');
          else if (data.consensus.direction === 'short') card.classList.add('dga-consensus-short');
          textEl.innerText = data.consensus.text;
          confEl.innerText = data.consensus.confidence + '%';
        }
      }

      updateMiniSummary(data);
      
      checkFiveCardAlarm(data);
    }
  }

  let lastFiveCardAlarmTime = 0;
  function checkFiveCardAlarm(data) {
    if (!data.layer1 || !data.layer2 || !data.layer3 || !data.layer4 || !data.tvData) return;
    
    const tvSignal = data.tvData.summary ? data.tvData.summary.toLowerCase() : '';
    const layers = [data.layer1, data.layer2, data.layer3, data.layer4];
    
    let allLong = tvSignal.includes('buy');
    let allShort = tvSignal.includes('sell');
    let sumConfidence = 0;
    
    for (const layer of layers) {
      if (layer.direction === 'long') { if (!allLong) allLong = false; }
      else if (layer.direction === 'short') { if (!allShort) allShort = false; }
      else { allLong = false; allShort = false; break; }
      sumConfidence += layer.confidence;
    }
    
    const avgConfidence = sumConfidence / 4;
    const tvConfidence = tvSignal.includes('strong') ? 90 : 60;
    
    const isConsensus = (allLong || allShort) && avgConfidence >= 85 && tvConfidence >= 60;
    
    if (isConsensus) {
      const now = Date.now();
      if (now - lastFiveCardAlarmTime > 60000) { 
        lastFiveCardAlarmTime = now;
        if (isSoundEnabled) {
          playBeep(true); 
        }
        [1, 2, 3, 4].forEach(num => flashCard(num));
        flashTVCard();
      }
    }
  }

  function updateMiniSummary(data) {
    if (!isSubscriptionValid) return;

    const setMini = (valId, direction, text) => {
      const valEl = document.getElementById(valId);
      if (!valEl) return;
      valEl.innerText = text || '--';
      let color = COLORS.yellow;
      if (direction === 'long') color = COLORS.green;
      else if (direction === 'short') color = COLORS.red;
      valEl.style.color = color;
    };

    setMini('mini-val-price', 'neutral', data.price ? data.price.toFixed(2) : '--');

    if (data.tvData && data.tvData.summary) {
      const tvSum = data.tvData.summary;
      const lower = tvSum.toLowerCase();
      let tvDir = 'neutral';
      if (lower.includes('buy')) tvDir = 'long';
      else if (lower.includes('sell')) tvDir = 'short';
      setMini('mini-val-tv', tvDir, tvSum);
    } else {
      setMini('mini-val-tv', 'neutral', '--');
    }

    setMini('mini-val-l1', data.layer1 ? data.layer1.direction : 'neutral', data.layer1 ? data.layer1.signal : '--');
    setMini('mini-val-l2', data.layer2 ? data.layer2.direction : 'neutral', data.layer2 ? data.layer2.signal : '--');
    setMini('mini-val-l3', data.layer3 ? data.layer3.direction : 'neutral', data.layer3 ? data.layer3.signal : '--');
    setMini('mini-val-l4', data.layer4 ? data.layer4.direction : 'neutral', data.layer4 ? data.layer4.signal : '--');
  }

  function getBadgeClass(signal) {
    if (!signal) return 'dga-tv-neutral';
    if (signal.includes('Strong Buy')) return 'dga-tv-strong-buy';
    if (signal.includes('Buy')) return 'dga-tv-buy';
    if (signal.includes('Strong Sell')) return 'dga-tv-strong-sell';
    if (signal.includes('Sell')) return 'dga-tv-sell';
    return 'dga-tv-neutral';
  }

  window.DGA_UI = { 
    update: updateUI, 
    playBeep, 
    flashCard, 
    createPanel, 
    lastData: null,
    setAuthStatus: (isValid, serverError = false) => { 
      isSubscriptionValid = isValid; 
      isServerError = serverError;
      if (window.DGA_UI.lastData && !localStorage.getItem('dga_panel_hidden')) {
        window.DGA_UI.update(window.DGA_UI.lastData);
      }
    },

    showPanel: () => {
      localStorage.removeItem('dga_panel_hidden');
      if (!document.getElementById('dga-panel')) {
        createPanel();
      } else {
        document.getElementById('dga-panel').style.display = 'block';
      }
      chrome.runtime.sendMessage({ action: 'PANEL_SHOWN' }, () => {});
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createPanel);
  } else {
    createPanel();
  }
})();