// ui.js (نسخه نهایی فاز ۱۴ - با هشدار دیتای قدیمی)
(function() {
  'use strict';

  const isAlpha = window.location.hostname.includes('alphagoldx');
  const themeColor = isAlpha ? '#0ea5e9' : '#a855f7';
  const themeColorDark = isAlpha ? '#0369a1' : '#7e22ce';
  const logoUrl = chrome.runtime.getURL('icons/icon128.png');

  let audioCtx = null;
  let isSubscriptionValid = false; 
  let isServerError = false; 

  function initAudio() {
    if (!audioCtx) {
      try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
    }
  }
  document.addEventListener('click', initAudio, { once: true });

  // ═══════════════════════════════════════════════════════════
  // توابع کمکی
  // ═══════════════════════════════════════════════════════════
  function makeDraggable(elmnt, handle) {
    let isDragging = false, offsetX, offsetY;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
      isDragging = true;
      offsetX = e.clientX - elmnt.getBoundingClientRect().left;
      offsetY = e.clientY - elmnt.getBoundingClientRect().top;
      handle.style.cursor = 'grabbing';
    });
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      let newX = e.clientX - offsetX, newY = e.clientY - offsetY;
      const maxX = window.innerWidth - elmnt.offsetWidth;
      const maxY = window.innerHeight - elmnt.offsetHeight;
      newX = Math.max(0, Math.min(newX, maxX));
      newY = Math.max(0, Math.min(newY, maxY));
      elmnt.style.left = newX + 'px';
      elmnt.style.top = newY + 'px';
      elmnt.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        handle.style.cursor = 'grab';
        savePosition(elmnt);
      }
    });
  }

  function savePosition(el) {
    localStorage.setItem('dga_panel_pos', JSON.stringify({ top: el.style.top, left: el.style.left }));
  }

  function restorePosition(el) {
    const saved = localStorage.getItem('dga_panel_pos');
    if (saved) {
      try {
        const pos = JSON.parse(saved);
        if (pos.top) el.style.top = pos.top;
        if (pos.left) el.style.left = pos.left;
        el.style.right = 'auto';
      } catch(e) {}
    }
  }

  function restoreMinimizedState(panel) {
    const isMinimized = localStorage.getItem('dga_panel_minimized') === 'true';
    const body = document.getElementById('dga-body');
    const toggleBtn = document.getElementById('dga-toggle-btn');
    const helpBtn = document.getElementById('dga-help-btn');
    const miniSummary = document.getElementById('dga-mini-summary');
    
    if (isMinimized) {
      body.style.display = 'none';
      if (helpBtn) helpBtn.style.display = 'none';
      if (miniSummary) miniSummary.style.display = 'flex';
      panel.style.minHeight = 'unset';
      panel.style.height = 'auto';
      toggleBtn.innerText = '+';
    } else {
      if (miniSummary) miniSummary.style.display = 'none';
    }
  }

  function setupToggles() {
    const toggleBtn = document.getElementById('dga-toggle-btn');
    const body = document.getElementById('dga-body');
    const helpBtn = document.getElementById('dga-help-btn');
    const miniSummary = document.getElementById('dga-mini-summary');
    const panel = document.getElementById('dga-panel');
    
    toggleBtn.onclick = () => {
      const isCurrentlyMinimized = localStorage.getItem('dga_panel_minimized') === 'true';
      const newState = !isCurrentlyMinimized;
      
      if (newState) {
        body.style.display = 'none';
        if (helpBtn) helpBtn.style.display = 'none';
        if (miniSummary) miniSummary.style.display = 'flex';
        panel.style.minHeight = 'unset';
        panel.style.height = 'auto';
        toggleBtn.innerText = '+';
        localStorage.setItem('dga_panel_minimized', 'true');
      } else {
        body.style.display = 'block';
        if (helpBtn) helpBtn.style.display = 'flex';
        if (miniSummary) miniSummary.style.display = 'none';
        panel.style.minHeight = '300px';
        panel.style.height = '';
        toggleBtn.innerText = '−';
        localStorage.setItem('dga_panel_minimized', 'false');
      }
    };
  }

  function setupReset() {
    document.getElementById('dga-reset-btn').onclick = (e) => {
      e.stopPropagation();
      if (confirm('پاک کردن کندل‌ها؟')) {
        const priceEl = document.getElementById('dga-price');
        if (priceEl) priceEl.innerText = 'در حال ریست...';
        const lastPrice = (window.DGA_UI && window.DGA_UI.lastData) ? window.DGA_UI.lastData.price : 0;
        window.postMessage({ type: 'DGA_RESET_DATA', lastPrice: lastPrice }, '*');
        setTimeout(() => {
          if (priceEl) priceEl.innerText = 'ریست شد ✓';
          setTimeout(() => { if (priceEl) priceEl.innerText = '--'; }, 2000);
        }, 1500);
      }
    };
  }

  function setupSound() {
    const soundBtn = document.getElementById('dga-sound-btn');
    const isEnabled = localStorage.getItem('dga_sound_enabled') !== 'false';
    updateSoundBtnStyle(soundBtn, isEnabled);
    
    soundBtn.onclick = (e) => {
      e.stopPropagation();
      const current = localStorage.getItem('dga_sound_enabled') !== 'false';
      const newState = !current;
      localStorage.setItem('dga_sound_enabled', newState ? 'true' : 'false');
      localStorage.setItem('dga_alarm_tv', newState ? 'true' : 'false');
      updateSoundBtnStyle(soundBtn, newState);
    };
  }

  function updateSoundBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; }
  }

  function setupHelp() {
    document.getElementById('dga-help-btn').onclick = () => {
      document.getElementById('dga-modal').style.display = 'flex';
    };
  }

  function setupHelpBar() {
    const helpBarClose = document.getElementById('dga-help-bar-close');
    if (helpBarClose) {
      helpBarClose.onclick = () => {
        document.getElementById('dga-help-bar').style.display = 'none';
        localStorage.setItem('dga_help_bar_closed', 'true');
      };
    }
  }

  function setupModal() {
    document.getElementById('dga-modal-close').onclick = () => {
      document.getElementById('dga-modal').style.display = 'none';
    };
  }

  function setupHideButton() {
    const hideBtn = document.getElementById('dga-hide-btn');
    if (!hideBtn) return;
    hideBtn.onclick = (e) => {
      e.stopPropagation();
      document.getElementById('dga-panel').style.display = 'none';
      localStorage.setItem('dga_panel_hidden', 'true');
      chrome.runtime.sendMessage({ action: 'PANEL_HIDDEN' }, () => {});
    };
  }

  function setupAlarmButtons() {
    document.querySelectorAll('.dga-alarm-btn').forEach(btn => {
      const layer = btn.getAttribute('data-layer');
      const isEnabled = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
      updateAlarmBtnStyle(btn, isEnabled);
      btn.onclick = (e) => {
        e.stopPropagation();
        const current = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
        localStorage.setItem(`dga_alarm_layer_${layer}`, current ? 'false' : 'true');
        updateAlarmBtnStyle(btn, !current);
      };
    });
  }

  function updateAlarmBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; }
  }

  function setupTVButton() {
    const btn = document.getElementById('dga-tv-launch-btn');
    if (btn) {
      btn.onclick = () => {
        window.open('https://www.tradingview.com/symbols/XAUUSD/technicals/?exchange=FOREXCOM', '_blank');
      };
    }
  }

  function setupCopyHandlers() {
    document.querySelectorAll('.dga-copyable').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = el.innerText;
        if (!text || text === '--') return;
        navigator.clipboard.writeText(text).then(() => {
          const originalText = el.innerText;
          el.innerText = 'کپی شد!';
          el.style.color = '#34d399';
          setTimeout(() => { el.innerText = originalText; el.style.color = ''; }, 1000);
        }).catch(() => {});
      });
    });
  }

  function checkFirstTime() {
    const isFirst = !localStorage.getItem('dga_first_time');
    const helpBar = document.getElementById('dga-help-bar');
    if (helpBar) {
      if (isFirst) {
        helpBar.style.display = 'flex';
        localStorage.setItem('dga_first_time', 'true');
      } else if (localStorage.getItem('dga_help_bar_closed') !== 'true') {
        helpBar.style.display = 'flex';
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ساخت پنل
  // ═══════════════════════════════════════════════════════════
  function createPanel() {
    if (document.getElementById('dga-panel')) return;
    if (localStorage.getItem('dga_panel_hidden') === 'true') return;

    const panel = document.createElement('div');
    panel.id = 'dga-panel';
    panel.className = 'dga-panel';
    panel.style.setProperty('--theme-color', themeColor);
    panel.style.setProperty('--theme-color-dark', themeColorDark);
    
    panel.style.backgroundImage = `url('${logoUrl}')`;
    panel.style.backgroundRepeat = 'no-repeat';
    panel.style.backgroundPosition = 'center center';
    panel.style.backgroundSize = '40%';
    panel.style.backgroundColor = 'rgba(17, 24, 39, 0.98)';
    panel.style.backgroundBlendMode = 'overlay';
    
    panel.innerHTML = `
      <div class="dga-header" id="dga-drag-handle">
        <div class="dga-title">نوسان‌گیر لحظه‌ای تریدمون <span id="dga-mini-lock-icon" style="display:none; color:#ef4444; font-size:10px;">🔒</span></div>
        <div class="dga-header-actions">
          <button class="dga-icon-btn" id="dga-help-btn" title="راهنما">؟</button>
          <button class="dga-icon-btn" id="dga-sound-btn" title="صدا">🔊</button>
          <button class="dga-icon-btn" id="dga-reset-btn" title="ریست">↺</button>
          <button class="dga-toggle-btn" id="dga-toggle-btn">−</button>
        </div>
      </div>
      
      <div class="dga-help-bar" id="dga-help-bar" style="display: none;">
        <span>💡 چهار لایه: میکرو (۳)، کوتاه (۱۵)، میان (۵۰)، بلند (۲۰۰) کندل.</span>
        <button id="dga-help-bar-close">×</button>
      </div>

      <div class="dga-body" id="dga-body" style="position: relative;">
        
        <!-- 🔒 لایه اخطار عدم اشتراک -->
        <div id="dga-auth-warning" style="
          display: none; flex-direction: column; align-items: center; justify-content: center;
          text-align: center; padding: 20px; box-sizing: border-box;
          background: linear-gradient(145deg, rgba(17, 24, 39, 0.98), rgba(31, 41, 55, 0.98));
          border-radius: 8px; margin: 10px 0; border: 1px solid rgba(239, 68, 68, 0.3);
        ">
          <div id="auth-icon" style="font-size: 40px; margin-bottom: 10px;">🔒</div>
          <div id="auth-title" style="color: #ef4444; font-weight: bold; margin-bottom: 8px; font-size: 14px;">اشتراک شما فعال نیست</div>
          <div id="auth-desc" style="color: #9ca3af; font-size: 11px; margin-bottom: 16px; line-height: 1.6;">
            برای مشاهده تحلیل‌ها، از سایت تریدمون اشتراک تهیه کنید.<br>
            <span style="color: #34d399; margin-top: 4px; display: inline-block;">(دیتا در پس‌زمینه در حال جمع‌آوری است)</span>
          </div>
          <a href="https://trademun.ir/dashboard" target="_blank" style="background: #d6ad60; color: #101827; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 12px;">رفتن به داشبورد</a>
        </div>

        <!-- محتوای اصلی -->
        <div id="dga-body-content">
            
            <!-- 👈 هشدار دیتای قدیمی -->
            <div id="dga-stale-warning" style="
              display: none; align-items: center; justify-content: center; gap: 6px;
              background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4);
              color: #fbbf24; border-radius: 6px; padding: 6px 10px; margin-bottom: 6px;
              font-size: 10px; text-align: center; line-height: 1.4;
            ">
              <span style="font-size: 14px;">⚠️</span>
              <span>دیتای فعلی قدیمی است (بیش از ۱ ساعت). برای نتایج دقیق‌تر، از دکمه ریست (↺) استفاده کنید.</span>
            </div>

            <!-- 🟢 نوار مقایسه قیمت -->
            <div class="dga-price-compare-bar">
              <div class="dga-price-compare-item">
                <span class="dga-pc-label">قیمت صرافی:</span>
                <span class="dga-pc-value" id="dga-price">--</span>
              </div>
              <div class="dga-price-compare-item">
                <span class="dga-pc-label" title="قیمت فارکس (XAUUSD) از TradingView">قیمت فارکس:</span>
                <span class="dga-pc-value" id="dga-tv-price">--</span>
              </div>
            </div>

            <!-- نوار کندل و سشن -->
            <div class="dga-top-bar">
              <div class="dga-progress-wrapper">
                <span class="dga-progress-label">کندل‌ها</span>
                <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-candle-progress"></div></div>
                <span class="dga-progress-text" id="dga-candle-progress-text">0/200</span>
              </div>
            </div>

            <div class="dga-session-bar" id="dga-session-bar">
              <span id="dga-session-text">در حال بررسی سشن...</span>
            </div>

            <!-- 🔴 بخش اول: تحلیل TradingView -->
            <div class="dga-section-container">
              <div class="dga-section-header">
                <span class="dga-section-title">تحلیل سایت TradingView برای نماد انس طلا در صرافی فارکس</span>
              </div>
              
              <div class="dga-tv-launcher">
                <button class="dga-tv-launch-btn" id="dga-tv-launch-btn" style="background: linear-gradient(135deg, var(--theme-color), var(--theme-color-dark));">
                  📈 باز کردن تحلیل زنده TradingView
                </button>
              </div>

              <!-- کارت خلاصه سیگنال هدف -->
              <div class="dga-tv-summary-card-big" id="dga-tv-summary-card-big">
                <div class="dga-tv-summary-big-header">
                  <span class="dga-tv-summary-big-title">🎯 خلاصه سیگنال هدف (با توجه به تایم فریم یک دقیقه)</span>
                </div>
                <div class="dga-tv-summary-big-signal" id="dga-tv-summary-big-signal">--</div>
                <div class="dga-tv-summary-big-counts">
                  <span class="sell">🔻 فروش: <b id="dga-tv-summary-big-sell">0</b></span>
                  <span class="neutral">⚪ خنثی: <b id="dga-tv-summary-big-neutral">0</b></span>
                  <span class="buy">🔺 خرید: <b id="dga-tv-summary-big-buy">0</b></span>
                </div>
              </div>

              <!-- کارت‌های نوسانگیر و میانگین‌ها -->
              <div class="dga-tv-cards-grid">
                <div class="dga-tv-card dga-tv-osc-card">
                  <div class="dga-tv-card-header">
                    <span class="dga-tv-card-title">📊 نوسانگیر</span>
                    <span class="dga-tv-badge" id="dga-tv-osc-badge">--</span>
                  </div>
                  <div class="dga-tv-card-counts">
                    <span class="sell">فروش: <b id="dga-tv-osc-sell">0</b></span>
                    <span class="neutral">خنثی: <b id="dga-tv-osc-neutral">0</b></span>
                    <span class="buy">خرید: <b id="dga-tv-osc-buy">0</b></span>
                  </div>
                </div>
                <div class="dga-tv-card dga-tv-ma-card">
                  <div class="dga-tv-card-header">
                    <span class="dga-tv-card-title">📈 میانگین متحرک</span>
                    <span class="dga-tv-badge" id="dga-tv-ma-badge">--</span>
                  </div>
                  <div class="dga-tv-card-counts">
                    <span class="sell">فروش: <b id="dga-tv-ma-sell">0</b></span>
                    <span class="neutral">خنثی: <b id="dga-tv-ma-neutral">0</b></span>
                    <span class="buy">خرید: <b id="dga-tv-ma-buy">0</b></span>
                  </div>
                </div>
              </div>
            </div>

            <!-- 🔵 بخش دوم: تحلیل تیم Trademun -->
            <div class="dga-section-container" style="margin-top: 10px;">
              <div class="dga-section-header">
                <span class="dga-section-title">تحلیل تیم Trademun (بر اساس کندل های یک دقیقه)</span>
              </div>

              <div class="dga-volatility-warning" id="dga-volatility-warning" style="display: none;">
                <span>⚠️ نوسان بالا — با احتیاط معامله کن.</span>
              </div>

              <!-- ۴ کارت لایه -->
              <div class="dga-layers-grid">
                <div class="dga-layer-card" id="dga-layer1-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">⚡ ۳ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="1">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer1-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer1-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer1-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer1-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer1-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer1-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer1-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-layer1-reason">--</div>
                </div>
                
                <div class="dga-layer-card" id="dga-layer2-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">🎯 ۱۵ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="2">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer2-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer2-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer2-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer2-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer2-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer2-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer2-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-layer2-reason">--</div>
                </div>
                
                <div class="dga-layer-card" id="dga-layer3-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">📊 ۵۰ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="3">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer3-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer3-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer3-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer3-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer3-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer3-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer3-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-layer3-reason">--</div>
                </div>
                
                <div class="dga-layer-card" id="dga-layer4-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">🏆 ۲۰۰ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="4">🔔</button>
                      <span class="dga-layer-badge" id="dga-layer4-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-layer4-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer4-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-layer4-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-layer4-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-layer4-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-layer4-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-layer4-reason">--</div>
                </div>
              </div>

              <div class="dga-consensus-card" id="dga-consensus-card">
                <div class="dga-consensus-header">
                  <span class="dga-consensus-title">🎯 نتیجه نهایی Trademun</span>
                  <span class="dga-consensus-confidence" id="dga-consensus-confidence">0%</span>
                </div>
                <div class="dga-consensus-text" id="dga-consensus-text">--</div>
              </div>
            </div>

            <div class="dga-footer">
              <span>ATR <b id="dga-atr">--</b></span>
              <span>RSI <b id="dga-rsi">--</b></span>
            </div>
        </div> <!-- پایان dga-body-content -->

      </div>

      <!-- 👈 خلاصه مینیمایز -->
      <div class="dga-mini-summary" id="dga-mini-summary" style="display: none; position: relative;">
        
        <!-- لایه مات (اگر اشتراک قطع باشد) -->
        <div id="mini-blur-overlay" style="
          position: absolute; top: 0; left: 0; width: 100%; height: 100%;
          background: #0d1b2d; /* رنگ یکدست، بدون شفافیت */
          display: none; flex-direction: column; align-items: center; justify-content: center;
          border-radius: 6px; z-index: 10;
        ">
          <span style="color: #ef4444; font-size: 11px; font-weight: bold;">اشتراک غیرفعال 🔒</span>
        </div>

        <!-- خطوط مینی‌ساماری (وقتی اشتراک فعاله دیده میشن) -->
        <div class="dga-mini-row">
          <div class="dga-mini-item">
            <span class="dga-mini-label">فارکس:</span>
            <span class="dga-mini-value" id="mini-val-tv">--</span>
          </div>
          <div class="dga-mini-item">
            <span class="dga-mini-label">قیمت:</span>
            <span class="dga-mini-value" id="mini-val-price">--</span>
          </div>
        </div>
        <div class="dga-mini-row">
          <div class="dga-mini-item">
            <span class="dga-mini-label">۳ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l1">--</span>
          </div>
          <div class="dga-mini-item">
            <span class="dga-mini-label">۱۵ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l2">--</span>
          </div>
        </div>
        <div class="dga-mini-row">
          <div class="dga-mini-item">
            <span class="dga-mini-label">۵۰ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l3">--</span>
          </div>
          <div class="dga-mini-item">
            <span class="dga-mini-label">۲۰۰ کندل:</span>
            <span class="dga-mini-value" id="mini-val-l4">--</span>
          </div>
        </div>
      </div>
      
      <!-- مودال راهنما -->
      <div class="dga-modal" id="dga-modal" style="display:none;">
        <div class="dga-modal-content">
          <div class="dga-modal-header">
            <h3>راهنمای جامع نوسان‌گیر تریدمون</h3>
            <button id="dga-modal-close">×</button>
          </div>
          <div class="dga-modal-body">
            
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 12px; margin-bottom: 16px;">
              <h4 style="color: #f87171; margin-top: 0; font-size: 13px;">⚠️ سلب مسئولیت و قوانین معاملاتی</h4>
              <p style="font-size: 11px; color: #d1d5db; line-height: 1.8; margin: 0; text-align: justify;">
                سایت <b>تریدمون</b> صرفاً یک <b>تحلیل‌گر داده</b> و ارائه‌دهنده سیگنال‌های کمکی است. تمامی تحلیل‌ها بر اساس الگوریتم‌های ریاضی و داده‌های تاریخی انجام می‌شود و <b>هیچ‌گونه تضمینی برای سودآوری وجود ندارد</b>. تصمیم‌گیری نهایی برای ورود یا خروج از معامله، کاملاً بر عهده کاربر است و تریدمون هیچ مسئولیتی در قبال سود یا زیان احتمالی کاربران نمی‌پذیرد.
              </p>
            </div>

            <h4 style="color: #d6ad60; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">⏳ چرا باید صبر کنید؟ (مهم)</h4>
            <p style="font-size: 11px; color: #d1d5db; line-height: 1.8; text-align: justify;">
              به دلیل عدم فعالیت رباتی و <b>محافظت از حساب شما در صرافی</b>، اکستنشن برای راه‌اندازی اولیه و اطمینان از صحت سیگنال‌ها، نیاز به جمع‌آوری حداقل <b>۱۵ کندل (۱۵ دقیقه)</b> دارد. 
              <br><br>
              🔹 <b>توصیه اکید:</b> لطفاً پس از باز کردن صفحه صرافی، حداقل <b>یک ساعت</b> به اکستنشن زمان دهید تا دیتای کافی جمع‌آوری شده و تحلیل‌های لایه‌های بالاتر (مانند ۵۰ و ۲۰۰ کندل) فعال شوند. سپس به سیگنال‌ها توجه کنید.
            </p>

            <h4 style="color: #0ea5e9; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">🔌 اکستنشن چطور کار می‌کند؟</h4>
            <ul style="padding-right: 20px; margin: 0 0 12px 0; font-size: 11px; line-height: 1.8; color: #d1d5db; text-align: justify;">
              <li>اکستنشن به صورت خودکار به WebSocket داخلی صرافی متصل می‌شود و قیمت‌های لحظه‌ای را بدون دستکاری در حساب شما دریافت می‌کند.</li>
              <li>داده‌ها در مرورگر شما (لوکال) به کندل تبدیل می‌شوند و تحلیل روی همین کندل‌ها انجام می‌شود.</li>
              <li>هیچ‌گونه سفارش خرید یا فروشی به صورت خودکار ثبت نمی‌شود.</li>
            </ul>
            
            <div style="text-align: center; margin-top: 20px; border-top: 1px solid rgba(75, 85, 99, 0.3); padding-top: 12px;">
              <a href="https://trademun.ir/dashboard" target="_blank" style="display: inline-block; background: #d6ad60; color: #101827; padding: 8px 24px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 12px; margin-bottom: 8px;">رفتن به داشبورد تریدمون</a>
              <p style="font-size: 10px; color: #6b7280; margin: 0;">© ۱۴۰۵ تریدمون | trademun.ir</p>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(panel);
    panel.style.display = 'none';

    makeDraggable(panel, document.getElementById('dga-drag-handle'));
    setupToggles();
    setupReset();
    setupSound();
    setupHelp();
    setupHelpBar();
    setupModal();
    setupHideButton(); 
    setupAlarmButtons();
    setupTVButton();
    setupCopyHandlers();
    restorePosition(panel);
    restoreMinimizedState(panel);
    checkFirstTime();

    setTimeout(() => {
      if (window.DGA_UI && window.DGA_UI.update) {
        window.DGA_UI.update({
          candlesCount: 0, price: 0, isFirstTime: false,
          session: { name: 'unknown', warning: false, message: 'در انتظار داده...' },
          layer1: null, layer2: null, layer3: null, layer4: null,
          consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
        });
      }
    }, 500);
  }

  // ═══════════════════════════════════════════════════════════
  // آپدیت UI
  // ═══════════════════════════════════════════════════════════
  function updateUI(data) {
    if (!window.DGA_UI) window.DGA_UI = {};
    window.DGA_UI.lastData = data;

    const authWarning = document.getElementById('dga-auth-warning');
    const bodyContent = document.getElementById('dga-body-content');
    const miniLock = document.getElementById('dga-mini-lock-icon');
    const miniBlurOverlay = document.getElementById('mini-blur-overlay');
    const authIcon = document.getElementById('auth-icon');
    const authTitle = document.getElementById('auth-title');
    const authDesc = document.getElementById('auth-desc');
    const panel = document.getElementById('dga-panel');
    const staleWarning = document.getElementById('dga-stale-warning');

    if (panel && panel.style.display === 'none' && (isSubscriptionValid || isServerError)) {
      panel.style.display = 'block';
    }

    // 👈 مدیریت نمایش هشدار دیتای قدیمی
    if (staleWarning) {
      staleWarning.style.display = (data.staleWarning && isSubscriptionValid) ? 'flex' : 'none';
    }

    if (!isSubscriptionValid) {
      if (authWarning) {
        authWarning.style.display = 'flex';
        if (isServerError) {
          if (authIcon) authIcon.innerText = '📡';
          if (authTitle) { authTitle.innerText = 'خطا در ارتباط با سرور'; authTitle.style.color = '#f59e0b'; }
          if (authDesc) authDesc.innerHTML = 'لطفاً اتصال اینترنت خود را بررسی کنید.<br><span style="color: #9ca3af;">(در حال تلاش مجدد...)</span>';
        } else {
          if (authIcon) authIcon.innerText = '🔒';
          if (authTitle) { authTitle.innerText = 'اشتراک شما فعال نیست'; authTitle.style.color = '#ef4444'; }
          if (authDesc) authDesc.innerHTML = 'برای مشاهده تحلیل‌ها، از سایت تریدمون اشتراک تهیه کنید.<br><span style="color: #34d399; margin-top: 4px; display: inline-block;">(دیتا در پس‌زمینه در حال جمع‌آوری است)</span>';
        }
      }
      if (bodyContent) bodyContent.style.display = 'none';
      if (miniLock) miniLock.style.display = 'inline';
      if (miniBlurOverlay) {
        miniBlurOverlay.style.display = (!isSubscriptionValid) ? 'flex' : 'none';
      }
    } else {
      if (authWarning) authWarning.style.display = 'none';
      if (bodyContent) bodyContent.style.display = 'block';
      if (miniLock) miniLock.style.display = 'none';
      if (miniBlurOverlay) miniBlurOverlay.style.display = 'none';
      
      // ادامه آپدیت‌های بصری
      if (data.price) {
        document.getElementById('dga-price').innerText = data.price.toFixed(2);
      }
      
      const count = data.candlesCount || 0;
      document.getElementById('dga-candle-progress').style.width = Math.min(100, (count / 200) * 100) + '%';
      document.getElementById('dga-candle-progress-text').innerText = `${count}/200`;

      if (data.session) {
        const sessionBar = document.getElementById('dga-session-bar');
        const sessionText = document.getElementById('dga-session-text');
        if (sessionBar && sessionText) {
          sessionText.innerText = data.session.message;
          sessionBar.className = 'dga-session-bar' + (data.session.warning ? ' warning' : ' normal');
        }
      }

      // بخش TradingView
      if (data.tvData) {
        const tv = data.tvData;
        const tvPriceEl = document.getElementById('dga-tv-price');
        if (tvPriceEl && tv.price) tvPriceEl.innerText = tv.price;

        const oscBadge = document.getElementById('dga-tv-osc-badge');
        if (oscBadge && tv.oscillatorsSignal) {
          oscBadge.innerText = tv.oscillatorsSignal;
          oscBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.oscillatorsSignal);
        }
        if (tv.oscCounts) {
          document.getElementById('dga-tv-osc-sell').innerText = tv.oscCounts.sell || 0;
          document.getElementById('dga-tv-osc-neutral').innerText = tv.oscCounts.neutral || 0;
          document.getElementById('dga-tv-osc-buy').innerText = tv.oscCounts.buy || 0;
        }

        const maBadge = document.getElementById('dga-tv-ma-badge');
        if (maBadge && tv.movingAveragesSignal) {
          maBadge.innerText = tv.movingAveragesSignal;
          maBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.movingAveragesSignal);
        }
        if (tv.maCounts) {
          document.getElementById('dga-tv-ma-sell').innerText = tv.maCounts.sell || 0;
          document.getElementById('dga-tv-ma-neutral').innerText = tv.maCounts.neutral || 0;
          document.getElementById('dga-tv-ma-buy').innerText = tv.maCounts.buy || 0;
        }

        const bigSignal = document.getElementById('dga-tv-summary-big-signal');
        const bigCard = document.getElementById('dga-tv-summary-card-big');

        if (tv.summary && bigSignal) {
          const prevSignal = bigSignal.innerText;
          bigSignal.innerText = tv.summary;
          bigSignal.className = 'dga-tv-summary-big-signal ' + getBadgeClass(tv.summary);

          if (bigCard) {
            bigCard.classList.remove('summary-long', 'summary-short', 'summary-neutral');
            const tvSumLower = tv.summary.toLowerCase();
            if (tvSumLower.includes('buy')) bigCard.classList.add('summary-long');
            else if (tvSumLower.includes('sell')) bigCard.classList.add('summary-short');
            else bigCard.classList.add('summary-neutral');
          }

          const tvSumLower = tv.summary.toLowerCase();
          if (tvSumLower.includes('strong buy') || tvSumLower.includes('strong sell')) {
            const isEnabled = localStorage.getItem('dga_sound_enabled') !== 'false';
            if (isEnabled && prevSignal !== tv.summary) {
              if (window.DGA_UI) {
                if (window.DGA_UI.playBeep) window.DGA_UI.playBeep();
                if (bigCard) {
                  bigCard.style.animation = 'flash 0.5s ease-in-out 3';
                  setTimeout(() => { bigCard.style.animation = ''; }, 1500);
                }
              }
            }
          }
        }
        if (tv.summaryCounts) {
          const bigSell = document.getElementById('dga-tv-summary-big-sell');
          const bigNeutral = document.getElementById('dga-tv-summary-big-neutral');
          const bigBuy = document.getElementById('dga-tv-summary-big-buy');
          if (bigSell) bigSell.innerText = tv.summaryCounts.sell || 0;
          if (bigNeutral) bigNeutral.innerText = tv.summaryCounts.neutral || 0;
          if (bigBuy) bigBuy.innerText = tv.summaryCounts.buy || 0;
        }
      } else {
        const ids = ['osc', 'ma'];
        ids.forEach(id => {
          const badge = document.getElementById(`dga-tv-${id}-badge`);
          if (badge) {
            badge.innerText = 'نامشخص';
            badge.className = 'dga-tv-badge dga-tv-neutral';
          }
        });
        const bigSignal = document.getElementById('dga-tv-summary-big-signal');
        if (bigSignal) {
          bigSignal.innerText = '--';
          bigSignal.className = 'dga-tv-summary-big-signal';
        }
      }

      const volWarning = document.getElementById('dga-volatility-warning');
      if (volWarning) volWarning.style.display = data.volatilityWarning ? 'flex' : 'none';

      const layers = [data.layer1, data.layer2, data.layer3, data.layer4];
      layers.forEach((layer, idx) => {
        const num = idx + 1;
        const card = document.getElementById(`dga-layer${num}-card`);
        if (!card) return;
        if (layer) {
          document.getElementById(`dga-layer${num}-badge`).innerText = layer.strength;
          document.getElementById(`dga-layer${num}-signal`).innerText = layer.signal;
          document.getElementById(`dga-layer${num}-confidence`).style.width = layer.confidence + '%';
          document.getElementById(`dga-layer${num}-confidence-text`).innerText = layer.confidence + '%';
          document.getElementById(`dga-layer${num}-reason`).innerText = layer.reason || '--';
          card.className = `dga-layer-card dga-layer${num}-active`;
          if (layer.direction === 'long') card.classList.add('dga-layer-long');
          else if (layer.direction === 'short') card.classList.add('dga-layer-short');
          
          const badge = document.getElementById(`dga-layer${num}-badge`);
          if (layer.strength === 'قوی') badge.style.background = 'rgba(16, 185, 129, 0.3)';
          else if (layer.strength === 'متوسط') badge.style.background = 'rgba(245, 158, 11, 0.3)';
          else badge.style.background = 'rgba(107, 114, 128, 0.3)';

          const slTpDiv = document.getElementById(`dga-layer${num}-sl-tp`);
          if (layer.sl && layer.tp) {
            slTpDiv.style.display = 'flex';
            document.getElementById(`dga-layer${num}-sl`).innerText = layer.sl;
            document.getElementById(`dga-layer${num}-tp`).innerText = layer.tp;
          } else {
            slTpDiv.style.display = 'none';
          }
        }
      });

      if (data.consensus) {
        const card = document.getElementById('dga-consensus-card');
        const textEl = document.getElementById('dga-consensus-text');
        const confEl = document.getElementById('dga-consensus-confidence');
        if (card && textEl && confEl) {
          card.className = 'dga-consensus-card';
          if (data.consensus.direction === 'long') card.classList.add('dga-consensus-long');
          else if (data.consensus.direction === 'short') card.classList.add('dga-consensus-short');
          textEl.innerText = data.consensus.text;
          confEl.innerText = data.consensus.confidence + '%';
        }
      }

      const ref = data.layer4 || data.layer3;
      if (ref) {
        document.getElementById('dga-atr').innerText = ref.atr || '--';
        document.getElementById('dga-rsi').innerText = ref.rsi || '--';
      }

      updateMiniSummary(data);
    }
  }

  function updateMiniSummary(data) {
    if (!isSubscriptionValid) return;

    const setMini = (valId, direction, text) => {
      const valEl = document.getElementById(valId);
      if (!valEl) return;
      valEl.innerText = text || '--';
      valEl.className = 'dga-mini-value ' + (direction === 'long' ? 'long' : direction === 'short' ? 'short' : 'neutral');
    };

    setMini('mini-val-price', 'neutral', data.price ? data.price.toFixed(2) : '--');

    if (data.tvData && data.tvData.summary) {
      const tvSum = data.tvData.summary;
      const lower = tvSum.toLowerCase();
      let tvDir = 'neutral';
      if (lower.includes('buy')) tvDir = 'long';
      else if (lower.includes('sell')) tvDir = 'short';
      setMini('mini-val-tv', tvDir, tvSum);
    } else {
      setMini('mini-val-tv', 'neutral', '--');
    }

    setMini('mini-val-l1', data.layer1 ? data.layer1.direction : 'neutral', data.layer1 ? data.layer1.signal : '--');
    setMini('mini-val-l2', data.layer2 ? data.layer2.direction : 'neutral', data.layer2 ? data.layer2.signal : '--');
    setMini('mini-val-l3', data.layer3 ? data.layer3.direction : 'neutral', data.layer3 ? data.layer3.signal : '--');
    setMini('mini-val-l4', data.layer4 ? data.layer4.direction : 'neutral', data.layer4 ? data.layer4.signal : '--');
  }

  function getBadgeClass(signal) {
    if (!signal) return 'dga-tv-neutral';
    if (signal.includes('Strong Buy')) return 'dga-tv-strong-buy';
    if (signal.includes('Buy')) return 'dga-tv-buy';
    if (signal.includes('Strong Sell')) return 'dga-tv-strong-sell';
    if (signal.includes('Sell')) return 'dga-tv-sell';
    return 'dga-tv-neutral';
  }

  function playBeep() {
    if (!audioCtx) return;
    try {
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.2);
    } catch (e) {}
  }

  function flashCard(layer) {
    const card = document.getElementById(`dga-layer${layer}-card`);
    if (!card) return;
    card.style.animation = 'flash 0.5s ease-in-out 3';
    setTimeout(() => { card.style.animation = ''; }, 1500);
  }

  window.DGA_UI = { 
    update: updateUI, 
    playBeep, 
    flashCard, 
    createPanel, 
    lastData: null,
    setAuthStatus: (isValid, serverError = false) => { 
      isSubscriptionValid = isValid; 
      isServerError = serverError;
      if (window.DGA_UI.lastData && !localStorage.getItem('dga_panel_hidden')) {
        window.DGA_UI.update(window.DGA_UI.lastData);
      }
    },

    showPanel: () => {
      localStorage.removeItem('dga_panel_hidden');
      if (!document.getElementById('dga-panel')) {
        createPanel();
      } else {
        document.getElementById('dga-panel').style.display = 'block';
      }
      // 👈 به background اطلاع بده که پنل نمایش داده شد
      chrome.runtime.sendMessage({ action: 'PANEL_SHOWN' }, () => {});
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createPanel);
  } else {
    createPanel();
  }
})();