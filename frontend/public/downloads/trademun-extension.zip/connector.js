// connector.js
(function() {
  'use strict';
  console.log('[Trademun Connector] Loaded on site');

  // 👈 تشخیص خودکار محیط (لوکال یا سرور)
  const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
  const apiUrl = isLocal ? 'http://127.0.0.1:8000' : 'https://api.trademun.ir';

  // 👈 ۱. به صفحه اعلام کن که اکستنشن آماده است
  window.postMessage({ type: 'TRADEMUN_EXTENSION_READY' }, '*');

  // 👈 ۲. گوش دادن به پیام از سمت صفحه (برای دریافت توکن)
  window.addEventListener('message', function(event) {
    // اطمینان از اینکه پیام از منبع معتبر است (همون صفحه)
    if (event.source !== window) return;

    // دریافت توکن از صفحه اتصال
    if (event.data && event.data.type === 'TRADEMUN_EXTENSION_TOKEN') {
      const extToken = event.data.token;
      if (!extToken) return;

      console.log('[Trademun Connector] Received token, saving...');
      
      // ذخیره توکن در حافظه اکستنشن
      chrome.runtime.sendMessage({ action: 'SAVE_EXTENSION_TOKEN', token: extToken }, (res) => {
        if (res && res.success) {
          console.log('[Trademun Connector] Token saved successfully');
          window.postMessage({ type: 'TRADEMUN_TOKEN_SAVED' }, '*');
        } else {
          console.error('[Trademun Connector] Failed to save token');
        }
      });
    }
  });

  // 👈 ۳. پاسخ به درخواست چک کردن نصب بودن اکستنشن
  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'CHECK_TRADEMUN_EXTENSION') {
      window.postMessage({ type: 'TRADEMUN_EXTENSION_READY' }, '*');
    }
  });

})();