// analyzer.js
(function() {
  'use strict';
  const RISK_PROFILES = {
    "aggressive": { "min_confidence": 40, "min_votes_required": 2, "sl_mult": 1.3, "tp_mult": 2.5 },
    "conservative": { "min_confidence": 55, "min_votes_required": 3, "sl_mult": 1.6, "tp_mult": 3.0 }
  };
  function getRegimeWeights(regime) {
    if (regime === "trend") return { momentum: 1.2, trend: 1.8, volatility: 0.9, volume: 1.1, structure: 1.0 };
    else if (regime === "transitional") return { momentum: 1.3, trend: 1.3, volatility: 1.0, volume: 1.3, structure: 1.2 };
    else return { momentum: 1.4, trend: 0.9, volatility: 1.1, volume: 1.4, structure: 1.3 };
  }
  function classifyRegime(adx, bbWidthPct, volumeRatio, emaSlopePct, diDiff) {
    if (!adx || adx <= 0) return "range";
    let base = "range"; if (adx >= 30) base = "trend"; else if (adx >= 22) base = "transitional";
    if (emaSlopePct !== null && Number.isFinite(emaSlopePct)) { if (base === "trend" && Math.abs(emaSlopePct) < 0.05) base = "transitional"; else if (base === "range" && Math.abs(emaSlopePct) > 0.1) base = "transitional"; }
    if (diDiff !== undefined && diDiff !== null) { if (base === "trend" && Math.abs(diDiff) < 5) base = "transitional"; }
    if (bbWidthPct !== undefined && bbWidthPct !== null && bbWidthPct > 0) { if (bbWidthPct < 0.5 && base === "trend") base = "transitional"; }
    if (volumeRatio !== undefined && volumeRatio !== null && volumeRatio > 2.0) { if (base === "range" && adx >= 18) base = "transitional"; }
    return base;
  }
  function analyzeMomentum(ind, adx) {
    let signals = []; const isTrending = adx >= 25; const rsi = ind.rsi || 50;
    if (isTrending) { if (rsi >= 70) signals.push([1.0, 1.2]); else if (rsi >= 60) signals.push([0.6, 1.0]); else if (rsi <= 30) signals.push([-1.0, 1.2]); else if (rsi <= 40) signals.push([-0.6, 1.0]); else signals.push([0.0, 0.5]); }
    else { if (rsi < 35) signals.push([0.8, 1.0]); else if (rsi > 65) signals.push([-0.8, 1.0]); else if (rsi < 42) signals.push([0.3, 0.6]); else if (rsi > 58) signals.push([-0.3, 0.6]); else signals.push([0.0, 0.5]); }
    const stochK = ind.stochK || 50; const stochD = ind.stochD || 50;
    if (isTrending) { if (stochK > stochD && stochK > 50) signals.push([0.7, 1.0]); else if (stochK < stochD && stochK < 50) signals.push([-0.7, 1.0]); else if (stochK > 80) signals.push([0.5, 0.8]); else if (stochK < 20) signals.push([-0.5, 0.8]); else signals.push([0.0, 0.5]); }
    else { if (stochK < 20 && stochD < 20) signals.push([1.0, 1.0]); else if (stochK > 80 && stochD > 80) signals.push([-1.0, 1.0]); else if (stochK > stochD && stochK < 50) signals.push([0.3, 0.7]); else if (stochK < stochD && stochK > 50) signals.push([-0.3, 0.7]); else signals.push([0.0, 0.5]); }
    const willr = ind.willr || -50;
    if (isTrending) { if (willr > -20) signals.push([0.7, 0.9]); else if (willr < -80) signals.push([-0.7, 0.9]); else signals.push([0.0, 0.5]); }
    else { if (willr < -80) signals.push([1.0, 0.9]); else if (willr > -20) signals.push([-1.0, 0.9]); else signals.push([0.0, 0.5]); }
    const cci = ind.cci || 0;
    if (isTrending) { if (cci > 100) signals.push([0.7, 0.9]); else if (cci < -100) signals.push([-0.7, 0.9]); else signals.push([0.0, 0.5]); }
    else { if (cci < -100) signals.push([0.8, 0.8]); else if (cci > 100) signals.push([-0.8, 0.8]); else signals.push([0.0, 0.5]); }
    const roc = ind.roc || 0;
    if (roc > 2) signals.push([0.6, 0.7]); else if (roc < -2) signals.push([-0.6, 0.7]); else if (roc > 0.5) signals.push([0.3, 0.5]); else if (roc < -0.5) signals.push([-0.3, 0.5]); else signals.push([0.0, 0.5]);
    const totalW = signals.reduce((acc, s) => acc + s[1], 0); const score = totalW > 0 ? signals.reduce((acc, s) => acc + (s[0] * s[1]), 0) / totalW : 0;
    return { score: score, vote: score > 0.25 ? 1 : (score < -0.25 ? -1 : 0), details: { rsi, stochK, stochD, willr, cci, roc } };
  }
  function analyzeTrend(ind, price) {
    let signals = []; const ema20 = ind.ema20 || 0; const ema50 = ind.ema50 || 0; const ema200 = ind.ema200 || 0;
    if (ema200 > 0) { if (price > ema200) signals.push([1.0, 1.2]); else signals.push([-1.0, 1.2]); }
    if (ema20 > 0 && ema50 > 0 && ema200 > 0) { if (ema20 > ema50 && ema50 > ema200) signals.push([0.8, 1.0]); else if (ema20 < ema50 && ema50 < ema200) signals.push([-0.8, 1.0]); }
    const macdHist = ind.macdHist || 0; const prevMacdHist = ind.prevMacdHist || 0;
    if (prevMacdHist <= 0 && macdHist > 0) signals.push([1.5, 1.3]); else if (prevMacdHist >= 0 && macdHist < 0) signals.push([-1.5, 1.3]); else if (macdHist > 0) signals.push([0.5, 0.9]); else if (macdHist < 0) signals.push([-0.5, 0.9]); else signals.push([0.0, 0.5]);
    const adx = ind.adx || 20; const dmp = ind.dmp || 20; const dmn = ind.dmn || 20;
    if (dmp > dmn && adx > 20) signals.push([0.9, 1.1]); else if (dmn > dmp && adx > 20) signals.push([-0.9, 1.1]);
    if (ind.supertrendDir > 0) signals.push([0.9, 1.1]); else if (ind.supertrendDir < 0) signals.push([-0.9, 1.1]);
    if (ind.tenkan > 0 && ind.kijun > 0) { if (ind.tenkan > ind.kijun && price > ind.kijun) signals.push([0.8, 0.9]); else if (ind.tenkan < ind.kijun && price < ind.kijun) signals.push([-0.8, 0.9]); }
    const totalW = signals.reduce((acc, s) => acc + s[1], 0); const score = totalW > 0 ? signals.reduce((acc, s) => acc + (s[0] * s[1]), 0) / totalW : 0;
    return { score: score, vote: score > 0.30 ? 1 : (score < -0.30 ? -1 : 0), details: { ema200, ema50, ema20, macdHist, adx, dmp, dmn, supertrendDir: ind.supertrendDir } };
  }
  function analyzeVolatility(ind, price) {
    let signals = []; const bbUpper = ind.bbUpper || 0; const bbLower = ind.bbLower || 0; const bbMid = ind.bbMid || 0;
    if (bbUpper > 0 && bbLower > 0) { if (price <= bbLower * 1.005) signals.push([0.8, 1.1]); else if (price >= bbUpper * 0.995) signals.push([-0.8, 1.1]); else if (price < bbMid) signals.push([0.2, 0.6]); else signals.push([-0.2, 0.6]); }
    const totalW = signals.reduce((acc, s) => acc + s[1], 0); const score = totalW > 0 ? signals.reduce((acc, s) => acc + (s[0] * s[1]), 0) / totalW : 0;
    return { score: score, vote: score > 0.30 ? 1 : (score < -0.30 ? -1 : 0), details: { bbUpper, bbLower, atr: ind.atr } };
  }
  function analyzeVolume(state, ind) { return { score: 0.0, vote: 0, details: { hasVolume: false } }; }
  function analyzeStructure(ohlcv, price) {
    if (!Array.isArray(ohlcv) || ohlcv.length < 11) { return { score: 0, vote: 0, details: { valid: false } }; }
    const previous = ohlcv.slice(-11, -1); const highs = previous.map(c => c.high); const lows = previous.map(c => c.low);
    if (!Number.isFinite(price) || highs.some(v => !Number.isFinite(v)) || lows.some(v => !Number.isFinite(v))) { return { score: 0, vote: 0, details: { valid: false } }; }
    const highest = Math.max(...highs); const lowest = Math.min(...lows); let score = 0;
    if (price > highest) score = 1; else if (price < lowest) score = -1;
    else { const range = highest - lowest; if (range > 0) { const position = (price - lowest) / range; if (position < 0.15) score = 0.4; else if (position > 0.85) score = -0.4; } }
    return { score, vote: score > 0.3 ? 1 : score < -0.3 ? -1 : 0, details: { highest, lowest, valid: true } };
  }
  function applyTrendOverride(direction, trendScore, momentumScore) {
    const STRONG = 0.65; const MEDIUM = 0.45;
    if (trendScore >= STRONG && direction === "short") { if (momentumScore >= 0.30) return { direction: "neutral", penalty: 0, reason: "🚫 SHORT بلاک شد — روند قوی صعودی" }; return { direction: direction, penalty: 60, reason: "⚠️ SHORT خلاف روند قوی" }; }
    if (trendScore <= -STRONG && direction === "long") { if (momentumScore <= -0.30) return { direction: "neutral", penalty: 0, reason: "🚫 LONG بلاک شد — روند قوی نزولی" }; return { direction: direction, penalty: 60, reason: "⚠️ LONG خلاف روند قوی" }; }
    if (trendScore >= MEDIUM && direction === "short") return { direction: direction, penalty: 25, reason: "⚠️ روند صعودی متوسط ولی SHORT" };
    if (trendScore <= -MEDIUM && direction === "long") return { direction: direction, penalty: 25, reason: "⚠️ روند نزولی متوسط ولی LONG" };
    return { direction: direction, penalty: 0, reason: "" };
  }
  function computeConfidence(votesLong, votesShort, consensus, finalScore, adx, trendScore, momentumScore, overridePenalty) {
    if (consensus === "neutral") return 0;
    let base = consensus === "strong" ? 45 : (consensus === "normal" ? 32 : 18);
    let quality = Math.min(15, Math.abs(finalScore) * 20);
    if (adx > 40) quality += 8; else if (adx > 30) quality += 5; else if (adx > 25) quality += 2; else if (adx < 18) quality -= 5;
    if (finalScore > 0) { if (trendScore > 0.3 && momentumScore > 0.3) quality += 12; else if (trendScore > 0.3 || momentumScore > 0.3) quality += 4; }
    else if (finalScore < 0) { if (trendScore < -0.3 && momentumScore < -0.3) quality += 12; else if (trendScore < -0.3 || momentumScore < -0.3) quality += 4; }
    quality = Math.max(0, Math.min(35, quality));
    let majority = finalScore > 0 ? votesLong : votesShort;
    let agreement = majority >= 4 ? 15 : (majority === 3 ? 10 : (majority === 2 ? 5 : 0));
    let conf = base + quality + agreement;
    if (overridePenalty > 0) conf = conf * (1 - overridePenalty / 100);
    return Math.max(0, Math.min(100, Math.round(conf)));
  }
  window.DGA_Analyzer = {
    analyze: function(state, timeframe, profile = "aggressive") {
      const ohlcv = state.ohlcv; if (!ohlcv || ohlcv.length < 50) return null;
      const closes = ohlcv.map(c => c.close); const highs = ohlcv.map(c => c.high); const lows = ohlcv.map(c => c.low);
      const price = closes[closes.length - 1]; const prevPrice = closes[closes.length - 2];
      const Ind = window.DGA_Indicators; const rsiArr = Ind.RSI(closes, 14); const adxObj = Ind.ADX(highs, lows, closes, 14); const bbObj = Ind.BBands(closes, 20, 2); const macdObj = Ind.MACD(closes, 12, 26, 9); const stochObj = Ind.Stochastic(highs, lows, closes, 14, 3);
      const ind = { rsi: rsiArr[rsiArr.length - 1], adx: adxObj.adx[adxObj.adx.length - 1] || 20, dmp: adxObj.plusDI[adxObj.plusDI.length - 1] || 20, dmn: adxObj.minusDI[adxObj.minusDI.length - 1] || 20, bbUpper: bbObj.upper[bbObj.upper.length - 1], bbLower: bbObj.lower[bbObj.lower.length - 1], bbMid: bbObj.mid[bbObj.mid.length - 1], bbWidth: bbObj.width[bbObj.width.length - 1], atr: Ind.ATR(highs, lows, closes, 14).pop(), macdHist: macdObj.hist[macdObj.hist.length - 1] || 0, prevMacdHist: macdObj.hist[macdObj.hist.length - 2] || 0, stochK: stochObj.k[stochObj.k.length - 1], stochD: stochObj.d[stochObj.d.length - 1], willr: Ind.WilliamsR(highs, lows, closes, 14).pop(), cci: Ind.CCI(highs, lows, closes, 20).pop(), roc: Ind.ROC(closes, 10).pop(), ema200: Ind.EMA(closes, 200).pop(), ema50: Ind.EMA(closes, 50).pop(), ema20: Ind.EMA(closes, 20).pop(), supertrendDir: Ind.Supertrend(highs, lows, closes, 10, 3).direction };
      const ema200Arr = Ind.EMA(closes, 200); const ema200Prev = ema200Arr.length >= 2 ? ema200Arr[ema200Arr.length - 2] : null;
      const emaSlopePct = (Number.isFinite(ind.ema200) && Number.isFinite(ema200Prev) && ema200Prev > 0) ? ((ind.ema200 - ema200Prev) / ema200Prev) * 100 : null;
      const diDiff = ind.dmp - ind.dmn; const regime = classifyRegime(ind.adx, ind.bbWidth, 1.0, emaSlopePct, diDiff);
      const groups = { momentum: analyzeMomentum(ind, ind.adx), trend: analyzeTrend(ind, price), volatility: analyzeVolatility(ind, price), volume: analyzeVolume(state, ind), structure: analyzeStructure(ohlcv, price) };
      const weights = getRegimeWeights(regime); let weightedSum = 0, totalWeight = 0; let votesLong = 0, votesShort = 0, votesNeutral = 0;
      for (let key in groups) { const g = groups[key]; const w = weights[key] || 1.0; weightedSum += g.score * w; totalWeight += w; if (g.vote > 0) votesLong++; else if (g.vote < 0) votesShort++; else votesNeutral++; }
      let finalScore = totalWeight > 0 ? weightedSum / totalWeight : 0; if (regime === "trend") finalScore *= 1.2; else if (regime === "range") finalScore *= 0.85;
      const prof = RISK_PROFILES[profile] || RISK_PROFILES["aggressive"]; let direction = "neutral", consensus = "neutral";
      if (votesLong >= prof.min_votes_required && votesLong > votesShort) { direction = "long"; consensus = votesLong >= 4 ? "strong" : "normal"; }
      else if (votesShort >= prof.min_votes_required && votesShort > votesLong) { direction = "short"; consensus = votesShort >= 4 ? "strong" : "normal"; }
      const override = applyTrendOverride(direction, groups.trend.score, groups.momentum.score); direction = override.direction; if (direction === "neutral") consensus = "neutral";
      let confidence = computeConfidence(votesLong, votesShort, consensus, finalScore, ind.adx, groups.trend.score, groups.momentum.score, override.penalty);
      if (confidence < prof.min_confidence) direction = "neutral";
      let sl = null, tp = null, rr = null;
      const tfMap = { '1m': { sl: 1.0, tp: 2.5 }, '5m': { sl: 1.2, tp: 2.5 }, '15m': { sl: 1.4, tp: 2.5 }, '30m': { sl: 1.5, tp: 2.5 }, '1h': { sl: 1.6, tp: 2.5 }, '4h': { sl: 1.8, tp: 3.0 }, '1d': { sl: 2.0, tp: 3.0 } };
      const mult = tfMap[timeframe] || tfMap['1h'];
      if (direction !== "neutral" && ind.atr > 0) { const slDist = ind.atr * prof.sl_mult * mult.sl; const tpDist = ind.atr * prof.tp_mult * mult.tp; if (direction === "long") { sl = price - slDist; tp = price + tpDist; } else { sl = price + slDist; tp = price - tpDist; } const feePct = 0; const grossRR = Math.abs(tp - price) / Math.abs(price - sl); rr = grossRR - (feePct / 100) * (price / Math.abs(price - sl)); if (rr < 1.0) { direction = "neutral"; confidence = 0; } }
      let signalFa = "خنثی (WAIT)"; if (direction === "long") signalFa = "خرید (BUY)"; else if (direction === "short") signalFa = "فروش (SELL)";
      return { signal: signalFa, direction: direction, confidence: confidence, regime: regime, price: price, sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, rr: rr ? rr.toFixed(2) : null, adx: ind.adx.toFixed(1), rsi: ind.rsi.toFixed(1), groups: groups, overrideReason: override.reason, votes: { long: votesLong, short: votesShort, neutral: votesNeutral } };
    }
  };
})();