const apiUrl = 'https://api.trademun.ir';

function formatDate(dateStr) {
  if (!dateStr) return "نامحدود";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "نامشخص";
    return d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch (e) {
    return "نامشخص";
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const states = {
    loading: document.getElementById('state-loading'),
    connected: document.getElementById('state-connected'),
    disconnected: document.getElementById('state-disconnected'),
  };
  const btns = {
    activate: document.getElementById('btn-activate'),
    deactivate: document.getElementById('btn-deactivate'),
    refresh: document.getElementById('btn-refresh'),
  };
  const toggleContainer = document.getElementById('toggle-panel-container');
  const togglePanel = document.getElementById('toggle-panel');
  const exchangeShortcuts = document.getElementById('exchange-shortcuts');
  const disconnectedTitle = document.getElementById('disconnected-title');
  const userInfo = document.getElementById('user-info');
  const errorReason = document.getElementById('error-reason');

  function showState(stateName) {
    Object.values(states).forEach(el => el.classList.add('hidden'));
    states[stateName].classList.remove('hidden');
    Object.values(btns).forEach(btn => { if(btn) btn.classList.add('hidden'); });
    toggleContainer.classList.add('hidden');
    exchangeShortcuts.classList.add('hidden');
  }

  async function checkStatus() {
    showState('loading');
    
    // ۱. چک کردن اینکه کاربر توی صفحه صرافی هست یا نه
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      const isExchangePage = activeTab && activeTab.url && 
        (activeTab.url.includes('alphagoldx') || activeTab.url.includes('daryagold'));
      
      if (!isExchangePage) {
        showState('disconnected');
        disconnectedTitle.textContent = 'صفحه پشتیبانی نمی‌شود';
        errorReason.innerHTML = 'این اکستنشن فقط در صفحات <b>دریا گلد</b> و <b>آلفا گلد</b> فعال است.<br>لطفاً به صفحه معاملات این صرافی‌ها بروید.';
        exchangeShortcuts.classList.remove('hidden');
        return;
      }

      // ۲. بررسی توکن
      chrome.storage.local.get(['extToken', 'panelHidden'], async (result) => {
        const token = result.extToken;
        const panelHidden = result.panelHidden === true;
        
        if (!token) {
          showState('disconnected');
          disconnectedTitle.textContent = 'اتصال قطع است';
          errorReason.textContent = 'لطفاً به حساب تریدمون متصل شوید.';
          btns.activate.classList.remove('hidden');
          exchangeShortcuts.classList.remove('hidden'); // میانبرها رو هم نشون بده
          return;
        }

        try {
          const res = await fetch(`${apiUrl}/extension/verify`, {
            method: 'GET',
            headers: { 'X-Extension-Token': token }
          });
          const data = await res.json();

          if (data.valid) {
            showState('connected');
            disconnectedTitle.textContent = 'اتصال قطع است'; // ریست عنوان
            
            const planFa = { "free": "رایگان", "1_month": "یک ماهه", "3_months": "سه ماهه", "6_months": "شش ماهه", "12_months": "یک ساله" }[data.plan] || data.plan;
            let expText = formatDate(data.expires_at);
            
            userInfo.innerHTML = `
              <b>${data.user_name}</b><br>
              <span style="font-size:10px; opacity:0.8;">پلن: ${planFa} | انقضا: ${expText}</span>
            `;
            
            toggleContainer.classList.remove('hidden');
            togglePanel.checked = !panelHidden;
            btns.deactivate.classList.remove('hidden');

          } else {
            showState('disconnected');
            disconnectedTitle.textContent = 'اتصال قطع است';
            
            if (data.reason && data.reason.startsWith('expired_at:')) {
              const expDateStr = data.reason.split(':')[1];
              errorReason.innerHTML = `اشتراک شما در تاریخ <b class="date">${formatDate(expDateStr)}</b> به پایان رسیده است.<br>لطفاً از سایت تمدید کنید.`;
            } else if (data.reason === 'no_active_subscription') {
              errorReason.textContent = 'اشتراک فعالی برای این حساب یافت نشد.';
            } else if (data.reason === 'invalid_or_expired_token') {
              errorReason.textContent = 'اتصال منقضی شده است. لطفاً دوباره متصل شوید.';
            } else {
              errorReason.textContent = 'خطا در اتصال. لطفاً دوباره تلاش کنید.';
            }
            
            btns.activate.classList.remove('hidden');
            exchangeShortcuts.classList.remove('hidden');
            if (data.reason === 'invalid_or_expired_token') {
              chrome.storage.local.remove('extToken');
            }
          }
        } catch (err) {
          showState('disconnected');
          disconnectedTitle.textContent = 'خطای شبکه';
          errorReason.textContent = 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید.';
          btns.refresh.classList.remove('hidden');
        }
      });
    });
  }

  // دکمه اتصال
  btns.activate.addEventListener('click', () => {
    const connectUrl = 'http://localhost:3000/extension/connect';
    chrome.tabs.create({ url: connectUrl });
    window.close(); 
  });

  // دکمه قطع اتصال
  btns.deactivate.addEventListener('click', () => {
    chrome.storage.local.remove('extToken', () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
            chrome.tabs.sendMessage(tab.id, { action: 'SUBSCRIPTION_STATUS', valid: false, serverError: false }).catch(() => {});
          }
        });
      });
      checkStatus();
    });
  });

  if(btns.refresh) btns.refresh.addEventListener('click', checkStatus);

  // 👈 مدیریت کلید سوییچ (بدون صدا زدن checkStatus)
  togglePanel.addEventListener('change', (e) => {
    const isVisible = e.target.checked;
    chrome.storage.local.set({ panelHidden: !isVisible }, () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
            if (isVisible) {
              chrome.tabs.sendMessage(tab.id, { action: 'SHOW_PANEL' }).catch(() => {});
            } else {
              chrome.tabs.sendMessage(tab.id, { action: 'HIDE_PANEL' }).catch(() => {});
            }
          }
        });
      });
    });
  });

  checkStatus();
});