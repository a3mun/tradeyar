// tv-injector.js (نسخه نهایی - حفظ دیتا در زمان رفرش برای جلوگیری از صفر شدن)
(function() {
  'use strict';
  console.log('%c[Goldmun] TV Injector Loaded (Zero-Flicker Version)', 'color: cyan; font-weight: bold;');

  let isRefreshing = false;
  let counter = 0;
  let lastSavedData = '';
  
  // 👈 ذخیره آخرین دیتای معتبر برای جلوگیری از صفر شدن در زمان رفرش
  let lastValidSignals = {
    oscSignal: null, oscCounts: { sell: 0, neutral: 0, buy: 0 },
    sumSignal: null, sumCounts: { sell: 0, neutral: 0, buy: 0 },
    maSignal: null, maCounts: { sell: 0, neutral: 0, buy: 0 }
  };

  function keepTabAwake() {
    requestAnimationFrame(() => {
      if (document.hidden) document.title = document.title;
    });
  }

  function getActiveTf() {
    try {
      const buttons = document.querySelectorAll('button');
      for (let btn of buttons) {
        if (btn.classList.contains('selected-RKKTRhZ6') || btn.getAttribute('aria-selected') === 'true') {
          const txt = btn.innerText.trim();
          if (txt.includes('minute') || txt.includes('hour') || txt.includes('day')) return txt;
        }
      }
    } catch (e) {}
    return '1 minute';
  }

  function clickTimeframe(tfName) {
    try {
      const buttons = document.querySelectorAll('button');
      for (let btn of buttons) {
        if (btn.innerText && btn.innerText.trim() === tfName) {
          if (!btn.classList.contains('selected-RKKTRhZ6') && btn.getAttribute('aria-selected') !== 'true') {
            btn.click();
          }
          return;
        }
      }
    } catch (e) {}
  }

  function extractData() {
    // قیمت رو همیشه بخون
    const priceElement = document.querySelector('.js-symbol-last');
    let price = null;
    if (priceElement) price = priceElement.innerText.trim().replace(/,/g, '');

    // 👈 اگه در حال رفرش هستیم، از دیتای قبلی استفاده کن (نه null)
    let oscSignal = lastValidSignals.oscSignal;
    let oscCounts = lastValidSignals.oscCounts;
    let sumSignal = lastValidSignals.sumSignal;
    let sumCounts = lastValidSignals.sumCounts;
    let maSignal = lastValidSignals.maSignal;
    let maCounts = lastValidSignals.maCounts;

    // فقط اگه در حال رفرش نیستیم، دیتای جدید رو بخون
    if (!isRefreshing) {
      function getGaugeData(titleText) {
        let data = { signal: null, counts: { sell: 0, neutral: 0, buy: 0 } };
        const titleEls = Array.from(document.querySelectorAll('div, span')).filter(el => 
          el.innerText && el.innerText.trim() === titleText && el.children.length === 0
        );
        if (titleEls.length === 0) return data;
        
        for (let titleEl of titleEls) {
          let current = titleEl.parentElement;
          let depth = 0;
          while (current && depth < 5) {
            const hasNumbers = current.querySelectorAll('.counterNumber-M0B5hpp0').length >= 3 || 
                               (current.innerText.includes('Sell') && current.innerText.includes('Neutral') && current.innerText.includes('Buy'));
            if (hasNumbers) {
              const signalWords = ['Strong Buy', 'Strong Sell', 'Strong buy', 'Strong sell', 'Buy', 'Sell', 'Neutral'];
              const signalNodes = current.querySelectorAll('*');
              for (let node of signalNodes) {
                if (!node.children.length && node.innerText) {
                  const txt = node.innerText.trim();
                  if (signalWords.includes(txt)) { data.signal = txt; break; }
                }
              }
              let foundNumbers = [];
              const nodes = current.querySelectorAll('*');
              for (let node of nodes) {
                if (!node.children.length && node.innerText) {
                  const txt = node.innerText.trim();
                  if (/^\d+$/.test(txt)) { foundNumbers.push(parseInt(txt)); }
                }
              }
              if (foundNumbers.length >= 3) {
                data.counts.sell = foundNumbers[0];
                data.counts.neutral = foundNumbers[1];
                data.counts.buy = foundNumbers[2];
              }
              return data;
            }
            current = current.parentElement;
            depth++;
          }
        }
        return data;
      }

      const oscData = getGaugeData('Oscillators');
      const sumData = getGaugeData('Summary');
      const maData = getGaugeData('Moving Averages');

      // اگه دیتای جدید معتبر بود، جایگزین کن
      if (oscData.signal) lastValidSignals.oscSignal = oscData.signal;
      if (sumData.signal) lastValidSignals.sumSignal = sumData.signal;
      if (maData.signal) lastValidSignals.maSignal = maData.signal;
      
      if (oscData.counts.sell > 0 || oscData.counts.neutral > 0 || oscData.counts.buy > 0) lastValidSignals.oscCounts = oscData.counts;
      if (sumData.counts.sell > 0 || sumData.counts.neutral > 0 || sumData.counts.buy > 0) lastValidSignals.sumCounts = sumData.counts;
      if (maData.counts.sell > 0 || maData.counts.neutral > 0 || maData.counts.buy > 0) lastValidSignals.maCounts = maData.counts;

      oscSignal = lastValidSignals.oscSignal;
      oscCounts = lastValidSignals.oscCounts;
      sumSignal = lastValidSignals.sumSignal;
      sumCounts = lastValidSignals.sumCounts;
      maSignal = lastValidSignals.maSignal;
      maCounts = lastValidSignals.maCounts;
    }

    const tvData = {
      price: price,
      oscillatorsSignal: oscSignal,
      oscCounts: oscCounts,
      summary: sumSignal,
      summaryCounts: sumCounts,
      movingAveragesSignal: maSignal,
      maCounts: maCounts,
      timestamp: Date.now()
    };

    const dataString = JSON.stringify(tvData);
    if (dataString !== lastSavedData) {
      lastSavedData = dataString;
      chrome.storage.local.set({ tv_data: tvData });
    }
  }

  function setupObserver() {
    const targetNode = document.querySelector('.js-symbol-last') || document.body;
    const observer = new MutationObserver(() => {
      extractData();
    });
    observer.observe(targetNode, { childList: true, subtree: true, characterData: true });
  }

  setInterval(() => {
    keepTabAwake();
    const activeTf = getActiveTf();

    if (activeTf !== '1 minute' && !isRefreshing) {
      clickTimeframe('1 minute');
      return;
    }

    counter++;

    if (counter >= 7 && !isRefreshing) {
      counter = 0; 
      isRefreshing = true;
      
      clickTimeframe('5 minutes');
      
      setTimeout(() => {
        clickTimeframe('1 minute');
        setTimeout(() => {
          isRefreshing = false;
        }, 1500);
      }, 1000);
    }
  }, 1000);

  setTimeout(() => {
    clickTimeframe('1 minute');
    setupObserver();
    setInterval(extractData, 500);
    setTimeout(extractData, 1000);
  }, 1500);
})();