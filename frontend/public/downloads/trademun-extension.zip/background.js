// background.js
const apiUrl = 'https://api.trademun.ir';
// ═══════════════════════════════════════════════════════════
// ۱. تزریق اسکریپت و مدیریت پیام‌ها
// ═══════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  
  if (request.action === "inject_early") {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      files: ["inject.js"],
      world: "MAIN"
    }).catch(err => console.error("[Goldmun] Injection failed:", err));
  }

  if (request.action === "SAVE_EXTENSION_TOKEN") {
    chrome.storage.local.set({ extToken: request.token, panelHidden: false }, () => {
      verifyTokenStatus();
      sendResponse({ success: true });
    });
    return true; 
  }

  if (request.action === 'PANEL_HIDDEN') {
    chrome.storage.local.set({ panelHidden: true });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'PANEL_SHOWN') {
    chrome.storage.local.set({ panelHidden: false });
    sendResponse({ success: true });
    return true;
  }

  // 👈 قطع فوری اتصال (از پاپ‌آپ)
  if (request.action === 'FORCE_DISCONNECT') {
    chrome.storage.local.remove('extToken');
    chrome.storage.local.set({ panelHidden: false });
    notifyContentScripts(false, false);
    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'GET_SUBSCRIPTION_STATUS') {
    chrome.storage.local.get(['extToken'], async (result) => {
      const token = result.extToken;
      if (!token) {
        sendResponse({ valid: false, serverError: false });
        return;
      }
      try {
        const res = await fetch(`${apiUrl}/extension/verify`, {
          method: 'GET',
          headers: { 'X-Extension-Token': token }
        });
        const data = await res.json();
        sendResponse({ valid: data.valid, serverError: false });
      } catch (err) {
        sendResponse({ valid: false, serverError: true });
      }
    });
    return true; 
  }
});

// ═══════════════════════════════════════════════════════════
// ۲. تزریق هنگام باز شدن تب صرافی
// ═══════════════════════════════════════════════════════════
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["inject.js"],
      world: "MAIN"
    }).catch(err => {});
  }
});

// ═══════════════════════════════════════════════════════════
// ۳. بررسی دوره‌ای (Alarms)
// ═══════════════════════════════════════════════════════════
chrome.alarms.create('checkSubscription', { periodInMinutes: 1440 }); // ۲۴ ساعت

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkSubscription') {
    verifyTokenStatus();
  }
});

chrome.runtime.onStartup.addListener(() => {
  verifyTokenStatus();
});

async function verifyTokenStatus() {
  chrome.storage.local.get(['extToken'], async (result) => {
    const token = result.extToken;
    if (!token) {
      notifyContentScripts(false, false);
      return;
    }

    try {
      const res = await fetch(`${apiUrl}/extension/verify`, {
        method: 'GET',
        headers: { 'X-Extension-Token': token }
      });
      const data = await res.json();
      
      if (data.valid) {
        notifyContentScripts(true, false);
      } else {
        notifyContentScripts(false, false);
      }
    } catch (err) {
      console.error('[Goldmun] Network error verifying token:', err);
      notifyContentScripts(false, true); 
    }
  });
}

function notifyContentScripts(isValid, isServerError = false) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
        chrome.tabs.sendMessage(tab.id, { 
          action: 'SUBSCRIPTION_STATUS', 
          valid: isValid,
          serverError: isServerError 
        }).catch(() => {});
      }
    });
  });
}