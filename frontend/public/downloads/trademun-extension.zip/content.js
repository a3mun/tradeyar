// content.js (نسخه نهایی فاز ۱۵.۳ - رفع باگ آلفا گلد با هماهنگی کامل)
(function() {
  'use strict';

  const state = {
    ohlcv: [],
    price: 0,
    currentTF: '1m',
    isFirstTime: !localStorage.getItem('dga_onboarded'),
    higherTFData: {},
    lastAlarmTime: {},
    layerResetTimes: { 1: 0, 2: 0, 3: 0, 4: 0 }
  };

  let isAnalysisLocked = false; 
  let isDataStaleWarning = false; 
  let hasShownStaleModal = false;
  

  console.log('%c[Goldmun] Content Script Loaded. 🎯', 'color: cyan; font-weight: bold;');

  chrome.runtime.sendMessage({ action: "inject_early" });


  function isOptionalEnabled() {
    return localStorage.getItem('dga_optional_enabled') !== 'false';
  }

  function ensurePanelExists() {
    if (document.getElementById('dga-panel')) return;
    // 👈 مستقیم از localStorage بخون
    if (localStorage.getItem('dga_panel_hidden') === 'true') return;
    if (window.DGA_UI && window.DGA_UI.createPanel) {
      window.DGA_UI.createPanel();
    }
  }
  
  const initInterval = setInterval(() => {
    if (document.body) {
      ensurePanelExists();
      clearInterval(initInterval);
    }
  }, 300);

  if (document.body) {
    ensurePanelExists();
    clearInterval(initInterval);
  }

  function readCandlesFromStorage() {
    try {
      state.currentTF = '1m'; 

      const gapFlag = localStorage.getItem('goldmun_gap_detected');
      if (gapFlag === 'true') {
        if (!hasShownStaleModal) {
          showStaleDataModal(60); 
          hasShownStaleModal = true;
          isAnalysisLocked = true;
        }
        localStorage.removeItem('goldmun_gap_detected');
      }

      const path = window.location.pathname;
      const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
      const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';
      
      const currentKey = `goldmun_candles_${host}_${symbol}_1m`;
      const stored = localStorage.getItem(currentKey);
      
      if (!stored) {
        state.ohlcv = [];
        if (window.DGA_UI) window.DGA_UI.update({ 
          candlesCount: 0, price: 0, isFirstTime: state.isFirstTime,
          layer1: null, layer2: null, layer3: null, layer4: null, consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
        });
        return;
      }
      
      const candles = JSON.parse(stored);
      if (candles.length > 0) {
        const lastCandle = candles[candles.length - 1];
        const now = Date.now();
        const gapMinutes = Math.floor((now - lastCandle.time) / 60000);

        if (gapMinutes > 60 && !isAnalysisLocked && !isDataStaleWarning) {
          if (!hasShownStaleModal) {
            showStaleDataModal(gapMinutes);
            hasShownStaleModal = true;
            isAnalysisLocked = true; 
          }
        } 
        else if (gapMinutes <= 60) {
          if (isAnalysisLocked) isAnalysisLocked = false;
          if (isDataStaleWarning) isDataStaleWarning = false;
          hasShownStaleModal = false;
        }

        state.ohlcv = candles;
        state.price = candles[candles.length - 1].close;
      }
    } catch (e) {
      console.error('[Goldmun] Read Error:', e);
    }
  }

  function showStaleDataModal(gapMinutes) {
    if (document.getElementById('dga-stale-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'dga-stale-modal';
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.85); z-index: 1000000;
      display: flex; align-items: center; justify-content: center;
      font-family: Vazirmatn, Tahoma, sans-serif; direction: rtl;
    `;

    modal.innerHTML = `
      <div style="background: #1f2937; border: 2px solid #f59e0b; border-radius: 12px; padding: 20px; max-width: 420px; text-align: center; color: #f9fafb; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
        <div style="font-size: 40px; margin-bottom: 10px;">⏳</div>
        <h3 style="color: #fbbf24; margin-bottom: 10px; font-size: 16px;">وقفه در دریافت دیتا!</h3>
        <p style="font-size: 12px; color: #d1d5db; line-height: 1.7; margin-bottom: 15px;">
          آخرین کندل <b>${gapMinutes} دقیقه</b> پیش ثبت شده است (بیش از ۱ ساعت). 
          <br>
          شما می‌توانید انتخاب کنید که دیتای قدیمی پاک شود یا با دیتای فعلی ادامه دهید.
        </p>
        <div style="display: flex; flex-direction: column; gap: 10px;">
          <button id="dga-stale-reset" style="background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; width: 100%;">
            ریست کن و از صفر شروع کن
          </button>
          <button id="dga-stale-continue" style="background: #4b5563; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; width: 100%;">
            ادامه بده (با دیتای فعلی)
          </button>
        </div>
        <p style="font-size: 10px; color: #9ca3af; margin-top: 12px;">
          با انتخاب «ادامه»، تحلیل‌ها با دیتای قدیمی انجام می‌شود و ممکن است دقیق نباشد.
        </p>
      </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('dga-stale-reset').onclick = () => {
      state.ohlcv = [];
      state.layerResetTimes = { 1: 0, 2: 0, 3: 0, 4: 0 };
      isAnalysisLocked = false;
      isDataStaleWarning = false;
      hasShownStaleModal = false;
      modal.remove();
      
      const path = window.location.pathname;
      const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
      const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith(`goldmun_candles_${host}_${symbol}_`)) {
          localStorage.removeItem(key);
        }
      });

      window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
    };

    document.getElementById('dga-stale-continue').onclick = () => {
      isAnalysisLocked = false;
      isDataStaleWarning = true; 
      hasShownStaleModal = true;
      modal.remove();
      console.log('[Goldmun] Continuing with stale data.');
    };
  }

  setInterval(readCandlesFromStorage, 1000);
  setInterval(runAnalysis, 1000);

  function getTradingSession() {
    const hour = new Date().getHours();
    if (hour >= 2 && hour < 10) {
      return { name: 'آسیا', warning: true, message: '⚠️ سشن آسیا — نقدینگی کم، با احتیاط معامله کن.' };
    }
    if (hour >= 10 && hour < 18) {
      return { name: 'لندن', warning: false, message: '✅ سشن لندن — نقدینگی مناسب.' };
    }
    return { name: 'نیویورک', warning: false, message: '✅ سشن نیویورک — نقدینگی بالا.' };
  }

  async function getTVDataFromStorage() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['tv_data'], (result) => {
        if (result.tv_data && Date.now() - result.tv_data.timestamp < 30000) {
          resolve(result.tv_data);
        } else {
          resolve(null);
        }
      });
    });
  }

  async function runAnalysis() {
    const count = state.ohlcv.length;
    if (count < 1) return;
    
    // 👈 مستقیم از localStorage بخون
    if (localStorage.getItem('dga_panel_hidden') === 'true') return;
  
    if (isAnalysisLocked) {
      if (window.DGA_UI && window.DGA_UI.update) {
        window.DGA_UI.update({
          candlesCount: count,
          price: state.price,
          isFirstTime: state.isFirstTime,
          session: getTradingSession(),
          layer1: null, layer2: null, layer3: null, layer4: null,
          consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
        });
      }
      return;
    }

    try {
      const session = getTradingSession();
      const closes = state.ohlcv.map(c => c.close);
      const highs = state.ohlcv.map(c => c.high);
      const lows = state.ohlcv.map(c => c.low);
      const price = closes[closes.length - 1];

      const atr = calcATR(highs, lows, closes, 14) || 0;
      const atrPct = price > 0 ? (atr / price) * 100 : 0;
      const volatilityWarning = atrPct > 0.5;

      const tvData = await getTVDataFromStorage();

      const countNewCandles = (resetTime) => {
        if (resetTime === 0) return count; 
        return state.ohlcv.filter(c => c.time >= resetTime).length;
      };

      const newCount1 = count; 
      const newCount2 = countNewCandles(state.layerResetTimes[2]);
      const newCount3 = countNewCandles(state.layerResetTimes[3]);
      const newCount4 = countNewCandles(state.layerResetTimes[4]);

      // لایه ۱
      let layer1 = null;
      if (newCount1 >= 3) {
        const rsi = calcRSI(closes, 3) || 50;
        const stoch = calcStochastic(highs, lows, closes, 3) || 50;
        const atr3 = calcATR(highs, lows, closes, 3) || 0;
        let score = 0;
        if (rsi > 52) score += 1.0; else if (rsi < 48) score -= 1.0;
        if (stoch > 55) score += 0.4; else if (stoch < 45) score -= 0.4;
        let trend = 'neutral', confidence = 0;
        if (score >= 1.0) trend = 'long'; else if (score <= -1.0) trend = 'short';
        confidence = Math.round((Math.abs(score) / 1.4) * 100);
        if (trend === 'neutral') confidence = Math.round(confidence * 0.3);
        confidence = Math.min(80, Math.max(1, confidence || 1));
        
        let sl = null, tp = null;
        if (trend !== 'neutral' && atr3 > 0) {
          if (trend === 'long') { sl = price - atr3 * 1.5; tp = price + atr3 * 3.0; }
          else { sl = price + atr3 * 1.5; tp = price - atr3 * 3.0; }
        }
        
        layer1 = {
          signal: trend === 'long' ? 'خرید' : (trend === 'short' ? 'فروش' : 'خنثی'),
          direction: trend, confidence, strength: confidence >= 70 ? 'قوی' : (confidence >= 40 ? 'متوسط' : 'ضعیف'),
          recommendation: '⚡ حرکت آنی', reason: `RSI=${rsi.toFixed(0)} | Stoch=${stoch.toFixed(0)}`,
          sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, layer: 1
        };
      }

      // لایه ۲
      let layer2 = null;
      if (newCount2 >= 15) {
        const rsi = calcRSI(closes, 14) || 50;
        const stoch = calcStochastic(highs, lows, closes, 14) || 50;
        const willr = calcWilliamsR(highs, lows, closes, 14) || -50;
        const atr15 = calcATR(highs, lows, closes, 14) || 0;
        let score = 0;
        if (rsi > 53) score += 1.0; else if (rsi < 47) score -= 1.0;
        if (stoch > 55) score += 0.4; else if (stoch < 45) score -= 0.4;
        if (willr > -40) score += 0.3; else if (willr < -60) score -= 0.3;
        let trend = 'neutral', confidence = 0;
        if (score >= 1.2) trend = 'long'; else if (score <= -1.2) trend = 'short';
        confidence = Math.round((Math.abs(score) / 1.7) * 100);
        if (trend === 'neutral') confidence = Math.round(confidence * 0.3);
        confidence = Math.min(85, Math.max(1, confidence || 1));
        
        let sl = null, tp = null;
        if (trend !== 'neutral' && atr15 > 0) {
          if (trend === 'long') { sl = price - atr15 * 1.5; tp = price + atr15 * 3.0; }
          else { sl = price + atr15 * 1.5; tp = price - atr15 * 3.0; }
        }
        
        layer2 = {
          signal: trend === 'long' ? 'خرید' : (trend === 'short' ? 'فروش' : 'خنثی'),
          direction: trend, confidence, strength: confidence >= 70 ? 'قوی' : (confidence >= 40 ? 'متوسط' : 'ضعیف'),
          recommendation: '🎯 کوتاه‌مدت', reason: `RSI=${rsi.toFixed(0)} | Stoch=${stoch.toFixed(0)}`,
          sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, layer: 2
        };
      }

      // لایه ۳
      let layer3 = null;
      if (newCount3 >= 50) {
        const ema20 = calcEMA(closes, 20).pop() || price;
        const ema50 = calcEMA(closes, 50).pop() || price;
        const rsi = calcRSI(closes, 14) || 50;
        const atr50 = calcATR(highs, lows, closes, 14) || 0;
        const bb = calcBB(closes, 20, 2);
        const macd = calcMACD(closes, 12, 26, 9);
        const cci = calcCCI(highs, lows, closes, 20) || 0;
        let signals = [];
        if (price > ema50) signals.push(1); else signals.push(-1);
        if (ema20 > ema50) signals.push(1); else signals.push(-1);
        if (macd.hist > 0) signals.push(1); else signals.push(-1);
        if (rsi > 50) signals.push(1); else signals.push(-1);
        if (price < bb.lower) signals.push(1); else if (price > bb.upper) signals.push(-1); else signals.push(0);
        if (cci > 100) signals.push(1); else if (cci < -100) signals.push(-1); else signals.push(0);
        const sum = signals.reduce((a, b) => a + b, 0);
        let trend = 'neutral';
        if (sum >= 3) trend = 'long'; else if (sum <= -3) trend = 'short';
        let confidence = Math.round((Math.abs(sum) / 6) * 100);
        if (trend === 'neutral') confidence = Math.round(confidence * 0.3);
        confidence = Math.min(90, Math.max(1, confidence || 1));
        
        let sl = null, tp = null;
        if (trend !== 'neutral' && atr50 > 0) {
          if (trend === 'long') { sl = price - atr50 * 1.5; tp = price + atr50 * 3.0; }
          else { sl = price + atr50 * 1.5; tp = price - atr50 * 3.0; }
        }
        
        layer3 = {
          signal: trend === 'long' ? 'خرید' : (trend === 'short' ? 'فروش' : 'خنثی'),
          direction: trend, confidence, strength: confidence >= 70 ? 'قوی' : (confidence >= 40 ? 'متوسط' : 'ضعیف'),
          recommendation: '📊 میان‌مدت', reason: `EMA=${ema20 > ema50 ? 'صعودی' : 'نزولی'} | MACD=${macd.hist > 0 ? 'صعودی' : 'نزولی'}`,
          sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, layer: 3
        };
      }

      // لایه ۴
      let layer4 = null;
      if (newCount4 >= 200) {
        const res = window.DGA_Analyzer.analyze(state, state.currentTF, 'aggressive');
        if (res) {
          let signalFa = 'خنثی';
          if (res.direction === 'long') signalFa = 'خرید';
          else if (res.direction === 'short') signalFa = 'فروش';
          
          let recFa = '⏳ صبر کن';
          if (res.direction === 'long' || res.direction === 'short') recFa = '🏆 بلندمدت — تحلیل جامع';

          layer4 = {
            signal: signalFa, direction: res.direction, confidence: res.confidence,
            strength: res.confidence >= 70 ? 'قوی' : (res.confidence >= 40 ? 'متوسط' : 'ضعیف'),
            recommendation: recFa, reason: res.overrideReason || `ADX: ${res.adx} | Regime: ${res.regime}`,
            sl: res.sl, tp: res.tp, rsi: res.rsi, atr: res.groups?.volatility?.details?.atr?.toFixed(2) || '--',
            layer: 4
          };
        }
      }

      // فیلتر لایه ۴
      if (layer4 && layer4.direction !== 'neutral') {
        [layer1, layer2, layer3].forEach(layer => {
          if (layer && layer.direction !== 'neutral' && layer.direction !== layer4.direction) {
            layer.direction = 'neutral';
            layer.signal = 'خنثی';
            layer.reason += ' | ⚠️ خلاف روند بلندمدت';
            layer.confidence = Math.round(layer.confidence * 0.5);
          }
        });
      }

      // رأی‌گیری
      const weights = { 1: 1.0, 2: 1.5, 3: 2.0, 4: 3.0 }; 
      let totalWeight = 0;
      let weightedScore = 0;
      let longVotes = 0, shortVotes = 0, neutralVotes = 0;

      [1, 2, 3, 4].forEach(num => {
        const layer = (num === 1 ? layer1 : num === 2 ? layer2 : num === 3 ? layer3 : layer4);
        if (!layer) return;
        const w = weights[num] || 1.0;
        totalWeight += w;
        if (layer.direction === 'long') { weightedScore += w * layer.confidence / 100; longVotes++; }
        else if (layer.direction === 'short') { weightedScore -= w * layer.confidence / 100; shortVotes++; }
        else neutralVotes++;
      });

      const tmScore = totalWeight > 0 ? weightedScore / totalWeight : 0;
      let tmDirection = 'neutral';
      if (tmScore > 0.05) tmDirection = 'long';
      else if (tmScore < -0.05) tmDirection = 'short';

      // ترکیب
      let finalDirection = tmDirection;
      let finalConfidence = Math.round(Math.abs(tmScore) * 100);
      let tvBonusText = '';
      let isTVStrong = false;

      if (tvData && tvData.summary) {
        const tvSumLower = tvData.summary.toLowerCase();
        
        if (tvSumLower.includes('buy')) {
          if (tvSumLower.includes('strong')) isTVStrong = true;
          
          if (tmDirection === 'long') {
            finalConfidence = isTVStrong ? Math.min(100, finalConfidence + 30) : Math.min(100, finalConfidence + 15);
          } else if (tmDirection === 'short') {
            finalConfidence = Math.round(finalConfidence * 0.5);
            tvBonusText = ' | ⚠️ تناقض با TradingView';
          } else {
            finalDirection = 'long';
            finalConfidence = isTVStrong ? 70 : 50;
            tvBonusText = ' | (سیگنال فارکس)';
          }
        } 
        else if (tvSumLower.includes('sell')) {
          if (tvSumLower.includes('strong')) isTVStrong = true;

          if (tmDirection === 'short') {
            finalConfidence = isTVStrong ? Math.min(100, finalConfidence + 30) : Math.min(100, finalConfidence + 15);
          } else if (tmDirection === 'long') {
            finalConfidence = Math.round(finalConfidence * 0.5);
            tvBonusText = ' | ⚠️ تناقض با TradingView';
          } else {
            finalDirection = 'short';
            finalConfidence = isTVStrong ? 70 : 50;
            tvBonusText = ' | (سیگنال فارکس)';
          }
        } 
        else {
          if (tmDirection !== 'neutral') tvBonusText = ' | رنج در فارکس';
        }
      }

      // متن نهایی
      let consensusText = '';
      if (finalDirection === 'long') {
        if (finalConfidence >= 70) consensusText = '✅ سیگنال قوی خرید (هماهنگی Trademun و فارکس).';
        else if (finalConfidence >= 40) consensusText = '🟢 سیگنال خرید — با احتیاط وارد شو.';
        else consensusText = '🟡 سیگنال خرید ضعیف — صبر کن.';
      } else if (finalDirection === 'short') {
        if (finalConfidence >= 70) consensusText = '🔴 سیگنال قوی فروش (هماهنگی Trademun و فارکس).';
        else if (finalConfidence >= 40) consensusText = '🟠 سیگنال فروش — با احتیاط وارد شو.';
        else consensusText = '🟡 سیگنال فروش ضعیف — صبر کن.';
      } else {
        consensusText = '⚪ نتیجه خنثی — بازار رنج، صبر کن.';
      }
      consensusText += tvBonusText;

      const consensus = {
        direction: finalDirection,
        confidence: finalConfidence,
        text: consensusText,
        longVotes, shortVotes, neutralVotes
      };

      if (window.DGA_UI && window.DGA_UI.update) {
        window.DGA_UI.update({
          candlesCount: count,
          price: state.price,
          isFirstTime: state.isFirstTime,
          session: session,
          layer1: layer1,
          layer2: layer2,
          layer3: layer3,
          layer4: layer4,
          consensus: consensus,
          volatilityWarning: volatilityWarning,
          tvData: tvData,
          staleWarning: isDataStaleWarning
        });
      }

      // آلارم‌ها
      [layer1, layer2, layer3, layer4].forEach(layer => {
        if (layer && layer.confidence >= 90) {
          const layerNum = layer.layer;
          const isEnabled = localStorage.getItem(`dga_alarm_layer_${layerNum}`) !== 'false';
          const soundEnabled = localStorage.getItem('dga_sound_enabled') !== 'false';
          if (isEnabled && soundEnabled) {
            if (state.lastAlarmTime[layerNum] !== layer.direction) {
              state.lastAlarmTime[layerNum] = layer.direction;
              if (window.DGA_UI) {
                if (window.DGA_UI.playBeep) window.DGA_UI.playBeep();
                if (window.DGA_UI.flashCard) window.DGA_UI.flashCard(layerNum);
              }
            }
          }
        }
      });
      
    } catch (err) {
      console.error('[Goldmun] Analysis Error:', err);
    }
  }

  // ابزارها
  function calcEMA(data, period) {
    const ema = []; const k = 2 / (period + 1); let prev = null;
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) { ema.push(null); continue; }
      if (prev === null) { let sum = 0; for (let j = 0; j < period; j++) sum += data[i - j]; prev = sum / period; }
      else { prev = (data[i] - prev) * k + prev; }
      ema.push(prev);
    }
    return ema;
  }
  function calcMACD(closes, fast = 12, slow = 26, signal = 9) {
    const emaFast = calcEMA(closes, fast); const emaSlow = calcEMA(closes, slow);
    const macdLine = []; for (let i = 0; i < closes.length; i++) { if (emaFast[i] !== null && emaSlow[i] !== null) macdLine.push(emaFast[i] - emaSlow[i]); else macdLine.push(null); }
    const validMacd = macdLine.filter(v => v !== null); const signalLine = calcEMA(validMacd, signal);
    const alignedSignal = []; let idx = 0;
    for (let i = 0; i < macdLine.length; i++) { if (macdLine[i] !== null) { alignedSignal.push(signalLine[idx] !== undefined ? signalLine[idx] : null); idx++; } else alignedSignal.push(null); }
    const hist = []; for (let i = 0; i < macdLine.length; i++) { if (macdLine[i] !== null && alignedSignal[i] !== null) hist.push(macdLine[i] - alignedSignal[i]); else hist.push(null); }
    return { macd: macdLine, signal: alignedSignal, hist: hist[hist.length - 1] || 0 };
  }
  function calcRSI(closes, period = 14) {
    if (!Array.isArray(closes) || closes.length < period + 1) return null;
    let gain = 0, loss = 0;
    for (let i = 1; i <= period; i++) { const diff = closes[i] - closes[i - 1]; gain += Math.max(diff, 0); loss += Math.max(-diff, 0); }
    let avgGain = gain / period, avgLoss = loss / period;
    for (let i = period + 1; i < closes.length; i++) { const diff = closes[i] - closes[i - 1]; avgGain = (avgGain * (period - 1) + Math.max(diff, 0)) / period; avgLoss = (avgLoss * (period - 1) + Math.max(-diff, 0)) / period; }
    if (avgGain === 0 && avgLoss === 0) return 50; if (avgLoss === 0) return 100; if (avgGain === 0) return 0;
    const rs = avgGain / avgLoss; return 100 - 100 / (1 + rs);
  }
  function calcATR(highs, lows, closes, period = 14) {
    const n = closes.length; if (n < period + 1 || highs.length !== n || lows.length !== n) return null;
    const tr = []; for (let i = 1; i < n; i++) { if (!Number.isFinite(highs[i]) || !Number.isFinite(lows[i]) || !Number.isFinite(closes[i - 1])) return null; tr.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]))); }
    if (tr.length < period) return null; let atr = tr.slice(0, period).reduce((sum, v) => sum + v, 0) / period;
    for (let i = period; i < tr.length; i++) { atr = (atr * (period - 1) + tr[i]) / period; }
    return Number.isFinite(atr) ? atr : null;
  }
  function calcStochastic(highs, lows, closes, period = 14) {
    if (closes.length < period) return 50; let highest = -Infinity; let lowest = Infinity;
    for (let i = closes.length - period; i < closes.length; i++) { highest = Math.max(highest, highs[i]); lowest = Math.min(lowest, lows[i]); }
    const denom = highest - lowest; if (denom === 0) return 50; return ((closes[closes.length - 1] - lowest) / denom) * 100;
  }
  function calcWilliamsR(highs, lows, closes, period = 14) {
    if (closes.length < period) return -50; let highest = -Infinity; let lowest = Infinity;
    for (let i = closes.length - period; i < closes.length; i++) { highest = Math.max(highest, highs[i]); lowest = Math.min(lowest, lows[i]); }
    const denom = highest - lowest; if (denom === 0) return -50; return ((highest - closes[closes.length - 1]) / denom) * -100;
  }
  function calcBB(closes, period = 20, stdDev = 2) {
    if (closes.length < period) return { upper: 0, lower: 0, mid: 0 };
    const slice = closes.slice(-period); const mid = slice.reduce((a, b) => a + b, 0) / period;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mid, 2), 0) / period; const std = Math.sqrt(variance);
    return { upper: mid + stdDev * std, lower: mid - stdDev * std, mid };
  }
  function calcCCI(highs, lows, closes, period = 20) {
    if (closes.length < period) return 0; const sliceH = highs.slice(-period); const sliceL = lows.slice(-period); const sliceC = closes.slice(-period);
    const tp = []; for (let i = 0; i < period; i++) { tp.push((sliceH[i] + sliceL[i] + sliceC[i]) / 3); }
    const sma = tp.reduce((a, b) => a + b, 0) / period; let meanDev = 0;
    for (let i = 0; i < period; i++) { meanDev += Math.abs(tp[i] - sma); } meanDev /= period;
    if (meanDev === 0) return 0; return (tp[tp.length - 1] - sma) / (0.015 * meanDev);
  }

  let previousSubStatus = null; 

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'SUBSCRIPTION_STATUS') {
      console.log('[Goldmun] Subscription status:', request.valid, 'ServerError:', request.serverError);
      
      if (previousSubStatus === false && request.valid === true) {
        localStorage.setItem('dga_show_welcome_guide', 'true');
      }
      previousSubStatus = request.valid;

      if (window.DGA_UI && window.DGA_UI.setAuthStatus) {
        window.DGA_UI.setAuthStatus(request.valid, request.serverError);
        if (window.DGA_UI.lastData) {
          window.DGA_UI.update(window.DGA_UI.lastData);
        }
      }
    }
    
    if (request.action === 'SHOW_PANEL') {
      localStorage.removeItem('dga_panel_hidden'); // 👈 فقط localStorage
      if (window.DGA_UI && window.DGA_UI.showPanel) {
        window.DGA_UI.showPanel();
        if (window.DGA_UI.lastData) window.DGA_UI.update(window.DGA_UI.lastData);
      }
    }

    if (request.action === 'HIDE_PANEL') {
      const panel = document.getElementById('dga-panel');
      if (panel) {
        panel.style.display = 'none';
      }
      localStorage.setItem('dga_panel_hidden', 'true'); // 👈 فقط localStorage
      chrome.runtime.sendMessage({ action: 'PANEL_HIDDEN' }, () => {});
    }
    

    if (request.action === 'TOGGLE_OPTIONAL') {
      const enabled = request.enabled;
      localStorage.setItem('dga_optional_enabled', enabled ? 'true' : 'false');
      if (!enabled) {
        document.querySelectorAll('.dga-pnl-container').forEach(el => el.remove());
      }
    }

    if (request.action === 'RESET_CANDLES') {
      const path = window.location.pathname;
      const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
      const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith(`goldmun_candles_${host}_${symbol}_`)) {
          localStorage.removeItem(key);
        }
      });
      window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
      if (window.DGA_UI && window.DGA_UI.update) {
        window.DGA_UI.update({ 
          candlesCount: 0, price: 0, isFirstTime: false,
          session: { name: 'unknown', warning: false, message: 'در انتظار داده...' },
          layer1: null, layer2: null, layer3: null, layer4: null, consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
        });
      }
    }
  });

  chrome.runtime.sendMessage({ action: 'GET_SUBSCRIPTION_STATUS' }, (response) => {
    if (response && response.valid !== undefined) {
      previousSubStatus = response.valid;
      if (window.DGA_UI && window.DGA_UI.setAuthStatus) {
        window.DGA_UI.setAuthStatus(response.valid, response.serverError || false);
        if (window.DGA_UI.lastData) window.DGA_UI.update(window.DGA_UI.lastData);
      }
    }
  });

  window.addEventListener('message', function(event) {
    if (event.data && event.data.type === 'DGA_TF_CHANGE') {
      state.currentTF = event.data.tf; state.ohlcv = []; state.higherTFData = {}; state.lastAlarmTime = {};
      readCandlesFromStorage();
    }
    if (event.data && event.data.type === 'DGA_RESET_DATA') { }
    if (event.data && event.data.type === 'DGA_DATA_CLEARED') {
      state.ohlcv = []; state.price = 0; state.lastAlarmTime = {};
      if (window.DGA_UI) window.DGA_UI.update({ candlesCount: 0, price: 0, layer1: null, layer2: null, layer3: null, layer4: null, consensus: null, volatilityWarning: false, tvData: null, staleWarning: false });
    }
  });

  if (state.isFirstTime) { localStorage.setItem('dga_onboarded', 'true'); }

  let lastPrices = {}; 

  function injectPnLPercentage() {
    if (!isOptionalEnabled()) return; 

    try {
      const isAlpha = window.location.hostname.includes('alphagoldx');
      let baseMargin = 1000000;
      let livePrice = '--';
      let livePriceNum = 0;

      if (isAlpha) {
        const priceDivs = document.querySelectorAll('.bg-mainColor3');
        for (let div of priceDivs) {
          if (div.innerText && div.innerText.includes('انس')) {
            const match = div.innerText.match(/انس\s*:\s*([\d.]+)/);
            if (match) { 
              livePrice = match[1]; 
              livePriceNum = parseFloat(livePrice);
              break; 
            }
          }
        }
      } else {
        const priceEl = document.querySelector('.text-indigo-700.tabular-nums, .dark\\:text-cyan-400.tabular-nums');
        if (priceEl) {
          livePrice = priceEl.innerText.trim();
          livePriceNum = parseFloat(livePrice.replace(/,/g, ''));
        } else {
          const allDivs = document.querySelectorAll('div');
          for (let div of allDivs) {
            if (div.innerText && div.innerText.includes('قیمت لحظه‌ای بازار')) {
              const parent = div.closest('.mb-4');
              if (parent) {
                const priceSpan = parent.querySelector('.text-indigo-700, .dark\\:text-cyan-400');
                if (priceSpan) { 
                  livePrice = priceSpan.innerText.trim(); 
                  livePriceNum = parseFloat(livePrice.replace(/,/g, ''));
                  break; 
                }
              }
            }
          }
        }
      }

      if (isAlpha) {
        const marginElements = document.querySelectorAll('span, div');
        for (let el of marginElements) {
          if (el.innerText && el.innerText.includes('وجه تضمین:')) {
            const parent = el.parentElement;
            if (parent) {
              const match = parent.innerText.match(/وجه تضمین:\s*([\d,]+)/);
              if (match) { baseMargin = parseFloat(match[1].replace(/,/g, '')); break; }
            }
          }
        }
      } else {
        const profileButtons = document.querySelectorAll('.grid.grid-cols-2.gap-2.p-1 button');
        for (let btn of profileButtons) {
          if (btn.innerText.includes('نیم واحدی') && (btn.classList.contains('bg-white') || btn.classList.contains('dark:bg-gray-800'))) {
            baseMargin = 500000; break;
          }
        }
      }

      const rows = document.querySelectorAll('tbody tr');
      
      rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length < 6) return;

        let units = 0, pnlValue = 0, pnlCell = null, rowId = '';

        if (isAlpha) {
          const pnlSpan = row.querySelector('td:nth-child(5) span');
          if (!pnlSpan) return;
          pnlCell = row.querySelector('td:nth-child(5)');
          rowId = row.getAttribute('value') || pnlCell.innerText;
          
          const amountText = cells[1] ? cells[1].innerText.trim() : '';
          units = parseFloat(amountText) || 0;
          const pnlText = pnlSpan.innerText.replace(/,/g, '').replace(/[^\d.-]/g, '');
          pnlValue = parseFloat(pnlText);
        } else {
          pnlCell = cells[4];
          if (!pnlCell) return;
          const pnlSpan = pnlCell.querySelector('span[dir="ltr"]');
          if (!pnlSpan) return;
          
          const typeText = cells[0] ? cells[0].innerText.trim() : '';
          const amountText = cells[1] ? cells[1].innerText.trim() : '';
          const timeText = cells[3] ? cells[3].innerText.trim() : '';
          rowId = `${typeText}_${amountText}_${timeText}`;
          
          units = parseFloat(amountText) || 0;
          const pnlText = pnlSpan.innerText.replace(/,/g, '').replace(/[^\d.-]/g, '');
          pnlValue = parseFloat(pnlText);
        }

        if (units <= 0 || isNaN(pnlValue)) return;

        const totalMargin = baseMargin * units;
        if (totalMargin === 0) return;
        const pnlPercentage = (pnlValue / totalMargin) * 100;

        let container = pnlCell.querySelector('.dga-pnl-container');
        if (!container) {
          container = document.createElement('div');
          container.className = 'dga-pnl-container';
          if (isAlpha) {
            const span = pnlCell.querySelector('span');
            if (span) span.after(container); else pnlCell.appendChild(container);
          } else {
            pnlCell.appendChild(container);
          }
        }

        let priceEl = container.querySelector('.dga-live-price');
        if (!priceEl) {
          priceEl = document.createElement('span');
          priceEl.className = 'dga-live-price tabular-nums text-xs mt-1 font-sans';
          priceEl.title = 'برای کپی قیمت لحظه‌ای کلیک کنید';
          container.appendChild(priceEl);
          
          priceEl.onclick = (e) => {
            e.stopPropagation();
            const text = priceEl.innerText;
            navigator.clipboard.writeText(text).then(() => {
              const orig = priceEl.innerText;
              priceEl.innerText = 'کپی شد!';
              priceEl.style.color = '#34d399';
              setTimeout(() => { 
                priceEl.innerText = orig; 
                if (lastPrices[rowId] && livePriceNum > lastPrices[rowId]) priceEl.style.color = '#34d399';
                else if (lastPrices[rowId] && livePriceNum < lastPrices[rowId]) priceEl.style.color = '#f87171';
                else priceEl.style.color = '#9ca3af';
              }, 1500);
            }).catch(() => {});
          };
        }
        
        if (!isNaN(livePriceNum) && livePriceNum > 0) {
          if (lastPrices[rowId] !== undefined) {
            if (livePriceNum > lastPrices[rowId]) {
              priceEl.style.color = '#34d399';
            } else if (livePriceNum < lastPrices[rowId]) {
              priceEl.style.color = '#f87171';
            } else {
              priceEl.style.color = '#9ca3af';
            }
          } else {
            priceEl.style.color = '#9ca3af';
          }
          lastPrices[rowId] = livePriceNum;
        }
        
        priceEl.innerText = livePrice;

        let badge = container.querySelector('.dga-pnl-badge');
        if (!badge) {
          badge = document.createElement('span');
          badge.className = 'dga-pnl-badge tabular-nums font-sans';
          container.prepend(badge);
        }

        let bgColor, textColor, sign;
        if (pnlPercentage > 0) { bgColor = 'rgba(16, 185, 129, 0.15)'; textColor = '#34d399'; sign = '+'; }
        else if (pnlPercentage < 0) { bgColor = 'rgba(239, 68, 68, 0.15)'; textColor = '#f87171'; sign = ''; }
        else { bgColor = 'rgba(156, 163, 175, 0.15)'; textColor = '#9ca3af'; sign = ''; }

        badge.style.cssText = `
          display: inline-block; padding: 2px 6px; border-radius: 4px;
          font-size: 10px; font-weight: 700; background: ${bgColor}; color: ${textColor};
          direction: ltr;
        `;
        badge.innerText = `${sign}${pnlPercentage.toFixed(2)}%`;
      });
    } catch (e) {
      console.error('[Goldmun] PnL Injection Error:', e);
    }
  }

  setInterval(injectPnLPercentage, 1000);  

})();