// connector.js
(function() {
  'use strict';
  window.postMessage({ type: 'TRADEMUN_EXTENSION_READY' }, '*');

  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'TRADEMUN_EXTENSION_TOKEN') {
      const extToken = event.data.token;
      if (!extToken) return;
      chrome.runtime.sendMessage({ action: 'SAVE_EXTENSION_TOKEN', token: extToken }, (res) => {
        if (res && res.success) {
          window.postMessage({ type: 'TRADEMUN_TOKEN_SAVED' }, '*');
        }
      });
    }
  });

  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'CHECK_TRADEMUN_EXTENSION') {
      window.postMessage({ type: 'TRADEMUN_EXTENSION_READY' }, '*');
    }
  });
})();