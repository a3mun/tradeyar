// background.js
const apiUrl = 'https://api.trademun.ir';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  
  if (request.action === "inject_early") {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      files: ["inject.js"],
      world: "MAIN"
    }).catch(err => console.error("[Goldmun] Injection failed:", err));
  }

  if (request.action === "SAVE_EXTENSION_TOKEN") {
    chrome.storage.local.set({ extToken: request.token, panelHidden: false }, () => {
      verifyTokenStatus();
      sendResponse({ success: true });
    });
    return true; 
  }

  if (request.action === 'PANEL_HIDDEN') {
    chrome.storage.local.set({ panelHidden: true });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'PANEL_SHOWN') {
    chrome.storage.local.set({ panelHidden: false });
    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'FORCE_DISCONNECT') {
    chrome.storage.local.remove('extToken');
    chrome.storage.local.set({ panelHidden: false });
    notifyContentScripts(false, false);
    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'GET_SUBSCRIPTION_STATUS') {
    chrome.storage.local.get(['extToken'], async (result) => {
      const token = result.extToken;
      if (!token) {
        sendResponse({ valid: false, serverError: false });
        return;
      }
      try {
        const res = await fetch(`${apiUrl}/extension/verify`, {
          method: 'GET',
          headers: { 'X-Extension-Token': token }
        });
        const data = await res.json();
        sendResponse({ valid: data.valid, serverError: false });
      } catch (err) {
        sendResponse({ valid: false, serverError: true });
      }
    });
    return true; 
  }

  // 👈 نظارت بر پنجره احراز هویت و رفرش کردن تب‌ها بعد از بسته شدن

  // 👈 نظارت بر پنجره احراز هویت (با ذخیره ID برای رویداد onRemoved)
  if (request.action === 'WATCH_AUTH_WINDOW') {
    const windowId = request.windowId;
    // 👈 آیدی پنجره را در storage ذخیره می‌کنیم تا رویداد onRemoved آن را بشناسد
    chrome.storage.local.set({ dga_auth_window_id: windowId });
    sendResponse({ success: true });
    return true;
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["inject.js"],
      world: "MAIN"
    }).catch(err => {});
  }
});

chrome.alarms.create('checkSubscription', { periodInMinutes: 1440 }); 

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkSubscription') {
    verifyTokenStatus();
  }
});

chrome.runtime.onStartup.addListener(() => {
  verifyTokenStatus();
});

async function verifyTokenStatus() {
  chrome.storage.local.get(['extToken'], async (result) => {
    const token = result.extToken;
    if (!token) {
      chrome.storage.local.set({ dga_subscription_valid: false });
      notifyContentScripts(false, false);
      return;
    }

    try {
      const res = await fetch(`${apiUrl}/extension/verify`, {
        method: 'GET',
        headers: { 'X-Extension-Token': token }
      });
      const data = await res.json();
      
      // 👈 ذخیره وضعیت در storage
      chrome.storage.local.set({ dga_subscription_valid: data.valid });
      
      if (data.valid) {
        notifyContentScripts(true, false);
      } else {
        notifyContentScripts(false, false);
      }
    } catch (err) {
      console.error('[Goldmun] Network error verifying token:', err);
      notifyContentScripts(false, true); 
    }
  });
}

function notifyContentScripts(isValid, isServerError = false) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
        chrome.tabs.sendMessage(tab.id, { 
          action: 'SUBSCRIPTION_STATUS', 
          valid: isValid,
          serverError: isServerError 
        }).catch(() => {});
      }
    });
  });
}

// 👈 شنونده بسته شدن پنجره احراز هویت (سطح مرورگر)
chrome.windows.onRemoved.addListener((closedWindowId) => {
  chrome.storage.local.get(['dga_auth_window_id'], (result) => {
    if (result.dga_auth_window_id === closedWindowId) {
      // پنجره احراز هویت بسته شد
      chrome.storage.local.remove('dga_auth_window_id');
      
      // 👈 کمی صبر می‌کنیم تا توکن ذخیره شود و بعد تب‌های صرافی را رفرش می‌کنیم
      setTimeout(() => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
              chrome.tabs.reload(tab.id);
            }
          });
        });
      }, 1000);
    }
  });
});