// background.js
const apiUrl = 'https://api.trademun.ir';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['dga_initialized'], (result) => {
    if (result.dga_initialized) return;
    chrome.storage.local.set({
      dga_initialized: true,
      panelHidden: true,        
      inlineEnabled: false,     
      optionalEnabled: false,   
      dga_subscription_valid: false,
      user_info: null
    });
  });
});

chrome.runtime.onStartup.addListener(() => verifyTokenStatus());
chrome.alarms.create('checkSubscription', { periodInMinutes: 1440 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkSubscription') {
    verifyTokenStatus(true); // 👈 true یعنی چک روزانه (در صورت خطا، پنل‌ها حذف می‌شوند)
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "inject_early" && sender.tab && sender.tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      files: ["inject.js"],
      world: "MAIN"
    }).catch(err => console.error("[Goldmun] Injection failed:", err));
    return;
  }

  if (request.action === "SAVE_EXTENSION_TOKEN") {
    chrome.storage.local.set({ extToken: request.token }, () => {
      verifyTokenStatus();
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'FORCE_RECHECK') {
    verifyTokenStatus().then((res) => {
      sendResponse(res);
    });
    return true;
  }

  if (request.action === 'FORCE_DISCONNECT') {
    chrome.storage.local.remove('extToken');
    chrome.storage.local.set({ 
      panelHidden: true, 
      inlineEnabled: false, 
      dga_subscription_valid: false,
      user_info: null
    }, () => {
      notifyContentScripts(false, false);
      // 👈 رفرش کردن تب‌های صرافی برای پاک شدن فوری پنل‌ها
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
            chrome.tabs.reload(tab.id);
          }
        });
      });
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'WATCH_AUTH_WINDOW') {
    chrome.storage.local.set({ dga_auth_window_id: request.windowId });
    sendResponse({ success: true });
    return true;
  }
  return false;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["inject.js"],
      world: "MAIN"
    }).catch(() => {});
  }
});

async function verifyTokenStatus(isDailyCheck = false) {
  const result = await chrome.storage.local.get(['extToken']);
  const token = result.extToken;
  
  if (!token) {
    await chrome.storage.local.set({ dga_subscription_valid: false, user_info: null });
    notifyContentScripts(false, false);
    return { valid: false, reason: 'no_token' };
  }

  try {
    // 👈 طبق آپدیت جدید سرور، توکن به صورت پارامتر در URL ارسال می‌شود
    const res = await fetch(`${apiUrl}/extension/verify?raw_token=${encodeURIComponent(token)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    
    const data = await res.json();
    
    if (res.ok && data.valid) {
      await chrome.storage.local.set({ 
        dga_subscription_valid: true,
        user_info: {
          name: data.user_name,
          plan: data.plan,
          expires_at: data.expires_at
        }
      });
      notifyContentScripts(true, false);
      return { valid: true, user_info: data };
    } else {
      await chrome.storage.local.set({ dga_subscription_valid: false, user_info: null });
      notifyContentScripts(false, false);
      if (isDailyCheck) {
        // 👈 اگر چک روزانه بود و نامعتبر شد، تب‌ها را رفرش کن
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
              chrome.tabs.reload(tab.id);
            }
          });
        });
      }
      return { valid: false, reason: data.reason || data.detail || 'invalid' };
    }
  } catch (err) {
    console.error('[Goldmun] Network error verifying token:', err);
    notifyContentScripts(false, true);
    return { valid: false, reason: 'network_error' };
  }
}

function notifyContentScripts(isValid, isServerError = false) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
        chrome.tabs.sendMessage(tab.id, {
          action: 'SUBSCRIPTION_STATUS',
          valid: isValid,
          serverError: isServerError
        }).catch(() => {});
      }
    });
  });
}

chrome.windows.onRemoved.addListener((closedWindowId) => {
  chrome.storage.local.get(['dga_auth_window_id'], (result) => {
    if (result.dga_auth_window_id === closedWindowId) {
      chrome.storage.local.remove('dga_auth_window_id');
      setTimeout(() => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
              chrome.tabs.reload(tab.id);
            }
          });
        });
      }, 1500);
    }
  });
});