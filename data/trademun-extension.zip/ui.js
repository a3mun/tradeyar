// ui.js (نسخه نهایی - بازگشت به استایل اولیه)
(function() {
  'use strict';

  console.log('UI.JS LOADED SUCCESSFULLY');

  const isAlpha = window.location.hostname.includes('alphagoldx');
  const exchangeName = isAlpha ? 'آلفا گلد' : 'دریا گلد';

  const COLORS = {
    bgMain: '#07111f',
    gold: '#d6ad60',
    textWhite: '#f3f5f8',
    textGray: '#94a3b8',
    green: '#10b981',
    red: '#ef4444',
    yellow: '#eab308',
    cardBg: 'rgba(13, 27, 45, 0.7)'
  };

  let audioCtx = null;
  let isSubscriptionValid = false;
  let isSoundEnabled = localStorage.getItem('dga_sound_enabled') !== 'false';
  let isTVSoundEnabled = localStorage.getItem('dga_tv_sound_enabled') !== 'false';
  let isPanelVisible = false;

  function initAudio() {
    if (!audioCtx) {
      try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
    }
  }
  document.addEventListener('click', initAudio, { once: true });

  function makeDraggable(elmnt, handle) {
    let isDragging = false, offsetX, offsetY;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
      isDragging = true;
      offsetX = e.clientX - elmnt.getBoundingClientRect().left;
      offsetY = e.clientY - elmnt.getBoundingClientRect().top;
      handle.style.cursor = 'grabbing';
    });
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      let newX = e.clientX - offsetX, newY = e.clientY - offsetY;
      const maxX = window.innerWidth - elmnt.offsetWidth;
      const maxY = window.innerHeight - elmnt.offsetHeight;
      newX = Math.max(0, Math.min(newX, maxX));
      newY = Math.max(0, Math.min(newY, maxY));
      elmnt.style.left = newX + 'px';
      elmnt.style.top = newY + 'px';
      elmnt.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        handle.style.cursor = 'grab';
        savePosition(elmnt);
      }
    });
  }

  function savePosition(el) {
    localStorage.setItem('dga_panel_pos', JSON.stringify({ top: el.style.top, left: el.style.left }));
  }

  function restorePosition(el) {
    const saved = localStorage.getItem('dga_panel_pos');
    if (saved) {
      try {
        const pos = JSON.parse(saved);
        if (pos.top) el.style.top = pos.top;
        if (pos.left) el.style.left = pos.left;
        el.style.right = 'auto';
      } catch(e) {}
    }
  }

  function restoreMinimizedState(panel) {
    const isMinimized = localStorage.getItem('dga_panel_minimized') === 'true';
    const body = document.getElementById('dga-body');
    const toggleBtn = document.getElementById('dga-toggle-btn');
    const helpBtn = document.getElementById('dga-help-btn');
    const resetBtn = document.getElementById('dga-reset-btn');
    const miniSummary = document.getElementById('dga-mini-summary');

    if (isMinimized) {
      body.style.display = 'none';
      if (helpBtn) helpBtn.style.visibility = 'hidden';
      if (resetBtn) resetBtn.style.visibility = 'hidden';
      if (miniSummary) miniSummary.style.display = 'flex';
      panel.style.minHeight = 'unset';
      panel.style.height = 'auto';
      if (toggleBtn) toggleBtn.innerText = '+';
    } else {
      if (miniSummary) miniSummary.style.display = 'none';
      if (helpBtn) helpBtn.style.visibility = 'visible';
      if (resetBtn) resetBtn.style.visibility = 'visible';
    }
  }

  function setupToggles() {
    const toggleBtn = document.getElementById('dga-toggle-btn');
    const body = document.getElementById('dga-body');
    const helpBtn = document.getElementById('dga-help-btn');
    const resetBtn = document.getElementById('dga-reset-btn');
    const miniSummary = document.getElementById('dga-mini-summary');
    const panel = document.getElementById('dga-panel');

    if (!toggleBtn) return;

    toggleBtn.onclick = () => {
      const isCurrentlyMinimized = localStorage.getItem('dga_panel_minimized') === 'true';
      const newState = !isCurrentlyMinimized;

      if (newState) {
        body.style.display = 'none';
        if (helpBtn) helpBtn.style.visibility = 'hidden';
        if (resetBtn) resetBtn.style.visibility = 'hidden';
        if (miniSummary) miniSummary.style.display = 'flex';
        panel.style.minHeight = 'unset';
        panel.style.height = 'auto';
        toggleBtn.innerText = '+';
        localStorage.setItem('dga_panel_minimized', 'true');
      } else {
        body.style.display = 'block';
        if (helpBtn) helpBtn.style.visibility = 'visible';
        if (resetBtn) resetBtn.style.visibility = 'visible';
        if (miniSummary) miniSummary.style.display = 'none';
        panel.style.minHeight = '300px';
        panel.style.height = '';
        toggleBtn.innerText = '−';
        localStorage.setItem('dga_panel_minimized', 'false');
      }
    };
  }

  function setupReset() {
    const resetBtn = document.getElementById('dga-reset-btn');
    if (!resetBtn) return;
    resetBtn.onclick = (e) => {
      e.stopPropagation();
      if (confirm('⚠️ آیا از پاک کردن تمام کندل‌ها مطمئن هستید؟')) {
        window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
      }
    };
  }

  function setupSound() {
    const soundBtn = document.getElementById('dga-sound-btn');
    if (!soundBtn) return;
    updateSoundBtnStyle(soundBtn, isSoundEnabled);
    soundBtn.onclick = (e) => {
      e.stopPropagation();
      isSoundEnabled = !isSoundEnabled;
      localStorage.setItem('dga_sound_enabled', isSoundEnabled ? 'true' : 'false');
      updateSoundBtnStyle(soundBtn, isSoundEnabled);
    };
  }

  function updateSoundBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; btn.innerText = '🔊'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; btn.innerText = '🔇'; }
  }

  function setupTVSound() {
    const tvSoundBtn = document.getElementById('dga-tv-sound-btn');
    if (!tvSoundBtn) return;
    updateTVSoundBtnStyle(tvSoundBtn, isTVSoundEnabled);
    tvSoundBtn.onclick = (e) => {
      e.stopPropagation();
      isTVSoundEnabled = !isTVSoundEnabled;
      localStorage.setItem('dga_tv_sound_enabled', isTVSoundEnabled ? 'true' : 'false');
      updateTVSoundBtnStyle(tvSoundBtn, isTVSoundEnabled);
    };
  }

  function updateTVSoundBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; btn.innerText = '🔔'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; btn.innerText = '🔕'; }
  }

  function setupHelp() {
    const helpBtn = document.getElementById('dga-help-btn');
    if (helpBtn) {
      helpBtn.onclick = () => {
        const modal = document.getElementById('dga-modal');
        if (modal) modal.style.display = 'flex';
      };
    }
  }

  function setupModal() {
    const modalClose = document.getElementById('dga-modal-close');
    if (modalClose) {
      modalClose.onclick = () => {
        document.getElementById('dga-modal').style.display = 'none';
      };
    }
    const modalAccept = document.getElementById('dga-modal-accept');
    if (modalAccept) {
      modalAccept.onclick = () => {
        document.getElementById('dga-modal').style.display = 'none';
      };
    }
  }

  function setupAlarmButtons() {
    document.querySelectorAll('.dga-alarm-btn').forEach(btn => {
      const layer = btn.getAttribute('data-layer');
      const isEnabled = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
      updateAlarmBtnStyle(btn, isEnabled);
      btn.onclick = (e) => {
        e.stopPropagation();
        const current = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
        localStorage.setItem(`dga_alarm_layer_${layer}`, current ? 'false' : 'true');
        updateAlarmBtnStyle(btn, !current);
      };
    });
  }

  function updateAlarmBtnStyle(btn, isEnabled) {
    if (isEnabled) { btn.style.opacity = '1'; btn.style.textDecoration = 'none'; }
    else { btn.style.opacity = '0.4'; btn.style.textDecoration = 'line-through'; }
  }

  function setupTVButton() {
    const btn = document.getElementById('dga-tv-launch-btn');
    if (btn) {
      btn.onclick = () => {
        window.open('https://www.tradingview.com/symbols/XAUUSD/technicals/?exchange=FOREXCOM', '_blank');
      };
    }
  }

  function setupCopyHandlers() {
    document.querySelectorAll('.dga-copyable').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = el.innerText;
        if (!text || text === '--') return;
        navigator.clipboard.writeText(text).then(() => {
          const originalText = el.innerText;
          el.innerText = 'کپی شد!';
          el.style.color = COLORS.green;
          setTimeout(() => { el.innerText = originalText; el.style.color = ''; }, 1000);
        }).catch(() => {});
      });
    });
  }

  function createPanel() {
    if (document.getElementById('dga-panel')) return;

    chrome.storage.local.get(['dga_subscription_valid', 'panelHidden'], (result) => {
      if (result.dga_subscription_valid !== true) return;
      if (result.panelHidden === true) return;

      isSubscriptionValid = true;
      isPanelVisible = true;

      const panel = document.createElement('div');
      panel.id = 'dga-panel';
      panel.className = 'dga-panel';
      panel.style.backgroundColor = COLORS.cardBg;
      
      panel.innerHTML = `
        <div class="dga-header" id="dga-drag-handle">
          <div class="dga-title" style="color: ${COLORS.textWhite};">نوسان‌گیر تریدمون (${exchangeName})</div>
          <div class="dga-header-actions">
            <button class="dga-icon-btn" id="dga-help-btn" title="راهنما" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold};">؟</button>
            <button class="dga-icon-btn" id="dga-sound-btn" title="صدا" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold};">🔊</button>
            <button class="dga-icon-btn" id="dga-reset-btn" title="ریست" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold};">↺</button>
            <button class="dga-toggle-btn" id="dga-toggle-btn" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold}; font-weight: bold;">−</button>
          </div>
        </div>
        
        <div class="dga-body" id="dga-body" style="position: relative;">
          <div class="dga-price-compare-bar">
            <div class="dga-price-compare-item">
              <span class="dga-pc-label" style="color: ${COLORS.textGray};">قیمت صرافی:</span>
              <span class="dga-pc-value" id="dga-price" style="color: ${COLORS.textWhite};">--</span>
            </div>
            <div class="dga-price-compare-item">
              <span class="dga-pc-label" style="color: ${COLORS.textGray};">قیمت فارکس:</span>
              <span class="dga-pc-value" id="dga-tv-price" style="color: ${COLORS.textWhite};">--</span>
            </div>
          </div>

          <div class="dga-top-bar">
            <div class="dga-progress-wrapper">
              <span class="dga-progress-label" style="color: ${COLORS.textGray};">کندل‌ها</span>
              <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-candle-progress"></div></div>
              <span class="dga-progress-text" id="dga-candle-progress-text" style="color: ${COLORS.textWhite};">0/200</span>
            </div>
          </div>

          <div class="dga-session-bar" id="dga-session-bar">
            <span id="dga-session-text">در حال بررسی سشن...</span>
          </div>

          <div class="dga-section-container">
            <div class="dga-section-header">
              <span class="dga-section-title" style="color: ${COLORS.gold}; font-size: 10px;">تحلیل TradingView</span>
            </div>
            
            <div class="dga-tv-launcher">
              <button class="dga-tv-launch-btn" id="dga-tv-launch-btn" style="background: linear-gradient(135deg, #c89a49, #d6ad60); color: ${COLORS.bgMain}; font-weight: bold; font-size: 11px;">
                دریافت اطلاعات نماد انس طلا در بازار فارکس
              </button>
            </div>

            <div class="dga-tv-summary-card-big" id="dga-tv-summary-card-big" style="position: relative;">
              <div class="dga-tv-summary-big-header">
                <span class="dga-tv-summary-big-title" style="color: ${COLORS.textWhite};">🎯 خلاصه سیگنال هدف</span>
                <button class="dga-icon-btn" id="dga-tv-sound-btn" title="صدای TradingView" style="background: rgba(214, 173, 96, 0.1); color: ${COLORS.gold}; width: 20px; height: 20px; font-size: 10px;">🔔</button>
              </div>
              <div class="dga-tv-summary-big-signal" id="dga-tv-summary-big-signal">--</div>
              <div class="dga-tv-summary-big-counts">
                <span class="sell" style="color: ${COLORS.red};">🔻 فروش: <b id="dga-tv-summary-big-sell">0</b></span>
                <span class="neutral" style="color: ${COLORS.yellow};">⚪ خنثی: <b id="dga-tv-summary-big-neutral">0</b></span>
                <span class="buy" style="color: ${COLORS.green};">🔺 خرید: <b id="dga-tv-summary-big-buy">0</b></span>
              </div>
            </div>

            <div class="dga-tv-cards-grid">
              <div class="dga-tv-card dga-tv-osc-card">
                <div class="dga-tv-card-header">
                  <span class="dga-tv-card-title" style="color: ${COLORS.textGray};">📊 نوسانگیر</span>
                  <span class="dga-tv-badge" id="dga-tv-osc-badge">--</span>
                </div>
                <div class="dga-tv-card-counts">
                  <span class="sell" style="color: ${COLORS.red};">فروش: <b id="dga-tv-osc-sell">0</b></span>
                  <span class="neutral" style="color: ${COLORS.yellow};">خنثی: <b id="dga-tv-osc-neutral">0</b></span>
                  <span class="buy" style="color: ${COLORS.green};">خرید: <b id="dga-tv-osc-buy">0</b></span>
                </div>
              </div>
              <div class="dga-tv-card dga-tv-ma-card">
                <div class="dga-tv-card-header">
                  <span class="dga-tv-card-title" style="color: ${COLORS.textGray};">📈 میانگین متحرک</span>
                  <span class="dga-tv-badge" id="dga-tv-ma-badge">--</span>
                </div>
                <div class="dga-tv-card-counts">
                  <span class="sell" style="color: ${COLORS.red};">فروش: <b id="dga-tv-ma-sell">0</b></span>
                  <span class="neutral" style="color: ${COLORS.yellow};">خنثی: <b id="dga-tv-ma-neutral">0</b></span>
                  <span class="buy" style="color: ${COLORS.green};">خرید: <b id="dga-tv-ma-buy">0</b></span>
                </div>
              </div>
            </div>
          </div>

          <div class="dga-section-container" style="margin-top: 10px;">
            <div class="dga-section-header">
              <span class="dga-section-title" style="color: ${COLORS.gold}; font-size: 10px;">تحلیل تیم Trademun</span>
            </div>

            <div class="dga-layers-grid">
              <div class="dga-layer-card" id="dga-layer1-card">
                <div class="dga-layer-header">
                  <span class="dga-layer-title" style="color: ${COLORS.textGray};">⚡ ۳ کندل</span>
                  <div class="dga-layer-header-actions">
                    <button class="dga-alarm-btn" data-layer="1">🔔</button>
                    <span class="dga-layer-badge" id="dga-layer1-badge">--</span>
                  </div>
                </div>
                <span class="dga-layer-signal" id="dga-layer1-signal">--</span>
                <div class="dga-layer-confidence">
                  <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer1-confidence"></div></div>
                  <span class="dga-progress-text" id="dga-layer1-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                </div>
                <div class="dga-layer-sl-tp" id="dga-layer1-sl-tp" style="display: none;">
                  <span>SL: <b id="dga-layer1-sl" class="dga-copyable">--</b></span>
                  <span>TP: <b id="dga-layer1-tp" class="dga-copyable">--</b></span>
                </div>
              </div>
              
              <div class="dga-layer-card" id="dga-layer2-card">
                <div class="dga-layer-header">
                  <span class="dga-layer-title" style="color: ${COLORS.textGray};">🎯 ۱۵ کندل</span>
                  <div class="dga-layer-header-actions">
                    <button class="dga-alarm-btn" data-layer="2">🔔</button>
                    <span class="dga-layer-badge" id="dga-layer2-badge">--</span>
                  </div>
                </div>
                <span class="dga-layer-signal" id="dga-layer2-signal">--</span>
                <div class="dga-layer-confidence">
                  <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer2-confidence"></div></div>
                  <span class="dga-progress-text" id="dga-layer2-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                </div>
                <div class="dga-layer-sl-tp" id="dga-layer2-sl-tp" style="display: none;">
                  <span>SL: <b id="dga-layer2-sl" class="dga-copyable">--</b></span>
                  <span>TP: <b id="dga-layer2-tp" class="dga-copyable">--</b></span>
                </div>
              </div>
              
              <div class="dga-layer-card" id="dga-layer3-card">
                <div class="dga-layer-header">
                  <span class="dga-layer-title" style="color: ${COLORS.textGray};">📊 ۵۰ کندل</span>
                  <div class="dga-layer-header-actions">
                    <button class="dga-alarm-btn" data-layer="3">🔔</button>
                    <span class="dga-layer-badge" id="dga-layer3-badge">--</span>
                  </div>
                </div>
                <span class="dga-layer-signal" id="dga-layer3-signal">--</span>
                <div class="dga-layer-confidence">
                  <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer3-confidence"></div></div>
                  <span class="dga-progress-text" id="dga-layer3-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                </div>
                <div class="dga-layer-sl-tp" id="dga-layer3-sl-tp" style="display: none;">
                  <span>SL: <b id="dga-layer3-sl" class="dga-copyable">--</b></span>
                  <span>TP: <b id="dga-layer3-tp" class="dga-copyable">--</b></span>
                </div>
              </div>
              
              <div class="dga-layer-card" id="dga-layer4-card">
                <div class="dga-layer-header">
                  <span class="dga-layer-title" style="color: ${COLORS.textGray};">🏆 ۲۰۰ کندل</span>
                  <div class="dga-layer-header-actions">
                    <button class="dga-alarm-btn" data-layer="4">🔔</button>
                    <span class="dga-layer-badge" id="dga-layer4-badge">--</span>
                  </div>
                </div>
                <span class="dga-layer-signal" id="dga-layer4-signal">--</span>
                <div class="dga-layer-confidence">
                  <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-layer4-confidence"></div></div>
                  <span class="dga-progress-text" id="dga-layer4-confidence-text" style="color: ${COLORS.textWhite};">0%</span>
                </div>
                <div class="dga-layer-sl-tp" id="dga-layer4-sl-tp" style="display: none;">
                  <span>SL: <b id="dga-layer4-sl" class="dga-copyable">--</b></span>
                  <span>TP: <b id="dga-layer4-tp" class="dga-copyable">--</b></span>
                </div>
              </div>
            </div>

            <div class="dga-consensus-card" id="dga-consensus-card">
              <div class="dga-consensus-header">
                <span class="dga-consensus-title" style="color: ${COLORS.textWhite};">🎯 نتیجه نهایی</span>
                <span class="dga-consensus-confidence" id="dga-consensus-confidence" style="color: ${COLORS.gold};">0%</span>
              </div>
              <div class="dga-consensus-text" id="dga-consensus-text" style="color: ${COLORS.textGray};">--</div>
            </div>
          </div>
        </div>

        <div class="dga-mini-summary" id="dga-mini-summary" style="display: none;">
          <div class="dga-mini-row">
            <div class="dga-mini-item">
              <span class="dga-mini-label" style="color: ${COLORS.textGray};">فارکس:</span>
              <span class="dga-mini-value" id="mini-val-tv">--</span>
            </div>
            <div class="dga-mini-item">
              <span class="dga-mini-label" style="color: ${COLORS.textGray};">قیمت:</span>
              <span class="dga-mini-value" id="mini-val-price">--</span>
            </div>
          </div>
          <div class="dga-mini-row">
            <div class="dga-mini-item">
              <span class="dga-mini-label" style="color: ${COLORS.textGray};">۳ کندل:</span>
              <span class="dga-mini-value" id="mini-val-l1">--</span>
            </div>
            <div class="dga-mini-item">
              <span class="dga-mini-label" style="color: ${COLORS.textGray};">۱۵ کندل:</span>
              <span class="dga-mini-value" id="mini-val-l2">--</span>
            </div>
          </div>
          <div class="dga-mini-row">
            <div class="dga-mini-item">
              <span class="dga-mini-label" style="color: ${COLORS.textGray};">۵۰ کندل:</span>
              <span class="dga-mini-value" id="mini-val-l3">--</span>
            </div>
            <div class="dga-mini-item">
              <span class="dga-mini-label" style="color: ${COLORS.textGray};">۲۰۰ کندل:</span>
              <span class="dga-mini-value" id="mini-val-l4">--</span>
            </div>
          </div>
        </div>
        
        <div class="dga-modal" id="dga-modal" style="display:none;">
          <div class="dga-modal-content">
            <div class="dga-modal-header">
              <h3 style="color: ${COLORS.gold};">راهنمای جامع نوسان‌گیر تریدمون</h3>
              <button id="dga-modal-close" style="color: ${COLORS.textGray};">×</button>
            </div>
            <div class="dga-modal-body">
              <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 12px; margin-bottom: 16px;">
                <h4 style="color: ${COLORS.red}; margin-top: 0; font-size: 13px;">⚠️ سلب مسئولیت و قوانین معاملاتی</h4>
                <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; margin: 0; text-align: justify;">
                  سایت <b>تریدمون</b> صرفاً یک <b>تحلیل‌گر داده</b> و ارائه‌دهنده سیگنال‌های کمکی است. تمامی تحلیل‌ها بر اساس الگوریتم‌های ریاضی و داده‌های تاریخی انجام می‌شود و <b>هیچ‌گونه تضمینی برای سودآوری وجود ندارد</b>. تصمیم‌گیری نهایی برای ورود یا خروج از معامله، کاملاً بر عهده کاربر است و تریدمون هیچ مسئولیتی در قبال سود یا زیان احتمالی کاربران نمی‌پذیرد.
                </p>
              </div>

              <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">⏳ چرا باید صبر کنید؟ (مهم)</h4>
              <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; text-align: justify;">
                به دلیل عدم فعالیت رباتی و <b>محافظت از حساب شما در صرافی</b>، اکستنشن برای راه‌اندازی اولیه و اطمینان از صحت سیگنال‌ها، نیاز به جمع‌آوری حداقل <b>۱۵ کندل (۱۵ دقیقه)</b> دارد. 
                <br><br>
                🔹 <b>توصیه اکید:</b> لطفاً پس از باز کردن صفحه صرافی، حداقل <b>یک ساعت</b> به اکستنشن زمان دهید تا دیتای کافی جمع‌آوری شده و تحلیل‌های لایه‌های بالاتر (مانند ۵۰ و ۲۰۰ کندل) فعال شوند.
              </p>

              <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">🔌 اکستنشن چطور کار می‌کند؟</h4>
              <ul style="padding-right: 20px; margin: 0 0 12px 0; font-size: 11px; line-height: 1.8; color: ${COLORS.textGray}; text-align: justify;">
                <li>اکستنشن به صورت خودکار به WebSocket داخلی صرافی متصل می‌شود و قیمت‌های لحظه‌ای را بدون دستکاری در حساب شما دریافت می‌کند.</li>
                <li>داده‌ها در مرورگر شما (لوکال) به کندل تبدیل می‌شوند و تحلیل روی همین کندل‌ها انجام می‌شود.</li>
                <li>هیچ‌گونه سفارش خرید یا فروشی به صورت خودکار ثبت نمی‌شود.</li>
              </ul>

              <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">📊 نمایش درصد سود/زیان </h4>
              <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; text-align: justify;">
                ما یک قابلیت اختیاری اضافه کردیم که درصد سود/زیان و قیمت لحظه‌ای هر معامله را در جدول معاملات صرافی نمایش می‌دهد. این اطلاعات در کنار هم قابل کپی هستند (برای کپی، روی قیمت کلیک کنید). اگر نمی‌خواهید این اطلاعات نمایش داده شوند، می‌توانید از طریق <b>پاپ‌آپ افزونه</b> (کلید «نمایش امکانات آپشنال») آن را غیرفعال کنید.
              </p>

              <h4 style="color: ${COLORS.gold}; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">🖥️ پنل شناور و پنل ثابت</h4>
              <p style="font-size: 11px; color: ${COLORS.textGray}; line-height: 1.8; text-align: justify;">
                اکستنشن دو حالت نمایش داره:
                <br>
                🔹 <b>پنل شناور (Floating):</b> که قابل جابه‌جایی با موس هست و همیشه روی صفحه می‌مونه.
                <br>
                🔹 <b>پنل ثابت (Inline):</b> که در بدنه سایت و دقیقاً کنار چارت (در آلفا گلد) یا جای کارت سفارش‌ها (در دریا گلد) قرار می‌گیره.
              </p>

              <div style="text-align: center; margin-top: 20px; border-top: 1px solid rgba(75, 85, 99, 0.3); padding-top: 12px;">
                <button id="dga-modal-accept" style="background: ${COLORS.gold}; color: ${COLORS.bgMain}; padding: 10px 24px; border-radius: 6px; border: none; font-weight: bold; font-size: 13px; cursor: pointer; width: 100%;">مطالعه کردم، ببند</button>
              </div>
            </div>
          </div>
        </div>

        <div class="dga-modal" id="dga-first-time-modal" style="display: none; z-index: 1000001;">
          <div class="dga-modal-content" style="text-align: center;">
            <div style="font-size: 50px; margin-bottom: 10px;">👋</div>
            <h3 style="color: ${COLORS.gold}; font-size: 16px; margin-bottom: 12px;">به نوسان‌گیر تریدمون خوش آمدید!</h3>
            <p style="font-size: 12px; color: ${COLORS.textGray}; line-height: 1.8; margin-bottom: 20px; text-align: justify;">
              برای شروع، لطفاً به این چند نکته توجه کنید:
              <br><br>
              🔹 <b>تایم جمع‌آوری:</b> برای عملکرد صحیح، حداقل <b>۱۵ کندل (۱۵ دقیقه)</b> صبر کنید.
              <br>
              🔹 <b>دکمه ریست:</b> بعد از هر چند ساعت که سیستم خاموش بوده، حتماً دکمه <b>ریست (↺)</b> را بزنید تا دیتای جدید جمع‌آوری شود.
              <br>
              🔹 <b>رفرش صفحه:</b> بعد از هر تغییر در افزونه، صفحه مرورگر را <b>رفرش (F5)</b> کنید.
              <br><br>
              <span style="color: ${COLORS.green};">برای اطلاعات بیشتر، از دکمه «راهنما» در بالای پنل استفاده کنید.</span>
            </p>
            <button id="dga-first-time-accept" style="background: ${COLORS.gold}; color: ${COLORS.bgMain}; padding: 10px 24px; border-radius: 6px; border: none; font-weight: bold; font-size: 13px; cursor: pointer;">
              متوجه شدم
            </button>
          </div>
        </div>
      `;
      
      document.body.appendChild(panel);
      panel.style.display = 'block';

      makeDraggable(panel, document.getElementById('dga-drag-handle'));
      setupToggles();
      setupReset();
      setupSound();
      setupTVSound();
      setupHelp();
      setupModal();
      setupAlarmButtons();
      setupTVButton();
      setupCopyHandlers();
      restorePosition(panel);
      restoreMinimizedState(panel);

      const isFirstTimeModal = !localStorage.getItem('dga_first_time_modal');
      if (isFirstTimeModal) {
        const firstTimeModal = document.getElementById('dga-first-time-modal');
        if (firstTimeModal) {
          firstTimeModal.style.display = 'flex';
          document.getElementById('dga-first-time-accept').onclick = () => {
            firstTimeModal.style.display = 'none';
            localStorage.setItem('dga_first_time_modal', 'true');
          };
        }
      }

      setTimeout(() => {
        if (window.DGA_UI && window.DGA_UI.update) {
          window.DGA_UI.update({
            candlesCount: 0, price: 0, isFirstTime: false,
            session: { name: 'unknown', warning: false, message: 'در انتظار داده...' },
            layer1: null, layer2: null, layer3: null, layer4: null,
            consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
          });
        }
      }, 500);
    });
  }

  function playBeep(isStrong = false) {
    if (!audioCtx || !isSoundEnabled) return;
    try {
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.frequency.value = isStrong ? 1000 : 880;
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.2);
    } catch (e) {}
  }

  function flashCard(layer) {
    const card = document.getElementById(`dga-layer${layer}-card`);
    if (!card) return;
    card.style.animation = 'flash 0.5s ease-in-out 3';
    setTimeout(() => { card.style.animation = ''; }, 1500);
  }

  function updateUI(data) {
    if (!window.DGA_UI) window.DGA_UI = {};
    window.DGA_UI.lastData = data;
    window.postMessage({ type: 'DGA_UPDATE_DATA', data: data }, '*');

    const panel = document.getElementById('dga-panel');
    if (!panel) return;

    if (data.price) {
      const priceEl = document.getElementById('dga-price');
      if (priceEl) priceEl.innerText = data.price.toFixed(2);
    }
    
    const count = data.candlesCount || 0;
    const progressEl = document.getElementById('dga-candle-progress');
    if (progressEl) progressEl.style.width = Math.min(100, (count / 200) * 100) + '%';
    const progressTextEl = document.getElementById('dga-candle-progress-text');
    if (progressTextEl) progressTextEl.innerText = `${count}/200`;

    if (data.session) {
      const sessionBar = document.getElementById('dga-session-bar');
      const sessionText = document.getElementById('dga-session-text');
      if (sessionBar && sessionText) {
        sessionText.innerText = data.session.message;
        sessionBar.className = 'dga-session-bar' + (data.session.warning ? ' warning' : ' normal');
      }
    }

    if (data.tvData) {
      const tv = data.tvData;
      const tvPriceEl = document.getElementById('dga-tv-price');
      if (tvPriceEl && tv.price) tvPriceEl.innerText = tv.price;

      const oscBadge = document.getElementById('dga-tv-osc-badge');
      if (oscBadge && tv.oscillatorsSignal) {
        oscBadge.innerText = tv.oscillatorsSignal;
        oscBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.oscillatorsSignal);
      }
      if (tv.oscCounts) {
        const el = document.getElementById('dga-tv-osc-sell'); if (el) el.innerText = tv.oscCounts.sell || 0;
        const el2 = document.getElementById('dga-tv-osc-neutral'); if (el2) el2.innerText = tv.oscCounts.neutral || 0;
        const el3 = document.getElementById('dga-tv-osc-buy'); if (el3) el3.innerText = tv.oscCounts.buy || 0;
      }

      const maBadge = document.getElementById('dga-tv-ma-badge');
      if (maBadge && tv.movingAveragesSignal) {
        maBadge.innerText = tv.movingAveragesSignal;
        maBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.movingAveragesSignal);
      }
      if (tv.maCounts) {
        const el = document.getElementById('dga-tv-ma-sell'); if (el) el.innerText = tv.maCounts.sell || 0;
        const el2 = document.getElementById('dga-tv-ma-neutral'); if (el2) el2.innerText = tv.maCounts.neutral || 0;
        const el3 = document.getElementById('dga-tv-ma-buy'); if (el3) el3.innerText = tv.maCounts.buy || 0;
      }

      const bigSignal = document.getElementById('dga-tv-summary-big-signal');
      const bigCard = document.getElementById('dga-tv-summary-card-big');

      if (tv.summary && bigSignal) {
        bigSignal.innerText = tv.summary;
        bigSignal.className = 'dga-tv-summary-big-signal ' + getBadgeClass(tv.summary);
        if (bigCard) {
          bigCard.classList.remove('summary-long', 'summary-short', 'summary-neutral');
          const tvSumLower = tv.summary.toLowerCase();
          if (tvSumLower.includes('buy')) bigCard.classList.add('summary-long');
          else if (tvSumLower.includes('sell')) bigCard.classList.add('summary-short');
          else bigCard.classList.add('summary-neutral');
        }
      }
      if (tv.summaryCounts) {
        const el = document.getElementById('dga-tv-summary-big-sell'); if (el) el.innerText = tv.summaryCounts.sell || 0;
        const el2 = document.getElementById('dga-tv-summary-big-neutral'); if (el2) el2.innerText = tv.summaryCounts.neutral || 0;
        const el3 = document.getElementById('dga-tv-summary-big-buy'); if (el3) el3.innerText = tv.summaryCounts.buy || 0;
      }
    }

    const layers = [data.layer1, data.layer2, data.layer3, data.layer4];
    layers.forEach((layer, idx) => {
      const num = idx + 1;
      const card = document.getElementById(`dga-layer${num}-card`);
      if (!card) return;
      if (layer) {
        const badge = document.getElementById(`dga-layer${num}-badge`); if (badge) badge.innerText = layer.strength;
        const signal = document.getElementById(`dga-layer${num}-signal`); if (signal) signal.innerText = layer.signal;
        const conf = document.getElementById(`dga-layer${num}-confidence`); if (conf) conf.style.width = layer.confidence + '%';
        const confText = document.getElementById(`dga-layer${num}-confidence-text`); if (confText) confText.innerText = layer.confidence + '%';
        card.className = `dga-layer-card dga-layer${num}-active`;
        if (layer.direction === 'long') card.classList.add('dga-layer-long');
        else if (layer.direction === 'short') card.classList.add('dga-layer-short');

        const slTpDiv = document.getElementById(`dga-layer${num}-sl-tp`);
        if (slTpDiv) {
          if (layer.sl && layer.tp) {
            slTpDiv.style.display = 'flex';
            const slEl = document.getElementById(`dga-layer${num}-sl`); if (slEl) slEl.innerText = layer.sl;
            const tpEl = document.getElementById(`dga-layer${num}-tp`); if (tpEl) tpEl.innerText = layer.tp;
          } else {
            slTpDiv.style.display = 'none';
          }
        }
      }
    });

    if (data.consensus) {
      const card = document.getElementById('dga-consensus-card');
      const textEl = document.getElementById('dga-consensus-text');
      const confEl = document.getElementById('dga-consensus-confidence');
      
      let scenarioEl = document.getElementById('dga-scenario-text');
      if (!scenarioEl && textEl) {
        scenarioEl = document.createElement('div');
        scenarioEl.id = 'dga-scenario-text';
        scenarioEl.style.cssText = 'font-size: 10px; color: #fbbf24; margin-top: 6px;';
        textEl.parentNode.appendChild(scenarioEl);
      }
      
      if (card && textEl && confEl) {
        card.className = 'dga-consensus-card';
        if (data.consensus.direction === 'long') card.classList.add('dga-consensus-long');
        else if (data.consensus.direction === 'short') card.classList.add('dga-consensus-short');
        textEl.innerText = data.consensus.text;
        confEl.innerText = data.consensus.confidence + '%';
        
        if (data.consensus.scenario && scenarioEl) {
          scenarioEl.innerText = data.consensus.scenario;
          scenarioEl.style.display = 'block';
        }
      }
    }

    updateMiniSummary(data);
  }

  function updateMiniSummary(data) {
    const setMini = (valId, direction, text) => {
      const valEl = document.getElementById(valId);
      if (!valEl) return;
      valEl.innerText = text || '--';
      let color = COLORS.yellow;
      if (direction === 'long') color = COLORS.green;
      else if (direction === 'short') color = COLORS.red;
      valEl.style.color = color;
    };

    setMini('mini-val-price', 'neutral', data.price ? data.price.toFixed(2) : '--');

    if (data.tvData && data.tvData.summary) {
      const tvSum = data.tvData.summary;
      const lower = tvSum.toLowerCase();
      let tvDir = 'neutral';
      if (lower.includes('buy')) tvDir = 'long';
      else if (lower.includes('sell')) tvDir = 'short';
      setMini('mini-val-tv', tvDir, tvSum);
    } else {
      setMini('mini-val-tv', 'neutral', '--');
    }

    setMini('mini-val-l1', data.layer1 ? data.layer1.direction : 'neutral', data.layer1 ? data.layer1.signal : '--');
    setMini('mini-val-l2', data.layer2 ? data.layer2.direction : 'neutral', data.layer2 ? data.layer2.signal : '--');
    setMini('mini-val-l3', data.layer3 ? data.layer3.direction : 'neutral', data.layer3 ? data.layer3.signal : '--');
    setMini('mini-val-l4', data.layer4 ? data.layer4.direction : 'neutral', data.layer4 ? data.layer4.signal : '--');
  }

  function getBadgeClass(signal) {
    if (!signal) return 'dga-tv-neutral';
    const s = signal.toLowerCase();
    if (s.includes('strong buy')) return 'dga-tv-strong-buy';
    if (s.includes('strong sell')) return 'dga-tv-strong-sell';
    if (s.includes('buy')) return 'dga-tv-buy';
    if (s.includes('sell')) return 'dga-tv-sell';
    return 'dga-tv-neutral';
  }

  window.DGA_UI = { 
    update: updateUI, 
    playBeep, 
    flashCard, 
    createPanel, 
    lastData: null
  };

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'SHOW_PANEL') {
      isPanelVisible = true;
      chrome.storage.local.set({ panelHidden: false }, () => {
        const panel = document.getElementById('dga-panel');
        if (panel) panel.style.display = 'block';
        else createPanel();
      });
    }
    
    if (request.action === 'HIDE_PANEL') {
      isPanelVisible = false;
      chrome.storage.local.set({ panelHidden: true });
      const panel = document.getElementById('dga-panel');
      if (panel) panel.style.display = 'none';
    }
    
    if (request.action === 'TOGGLE_OPTIONAL') {
      localStorage.setItem('dga_optional_enabled', request.enabled ? 'true' : 'false');
      if (!request.enabled) {
        document.querySelectorAll('.dga-pnl-container').forEach(el => el.remove());
      }
    }
    
    if (request.action === 'SUBSCRIPTION_STATUS') {
      isSubscriptionValid = request.valid;
      if (!isSubscriptionValid) {
        const panel = document.getElementById('dga-panel');
        if (panel) panel.remove();
      } else {
        chrome.storage.local.get(['panelHidden'], (result) => {
          if (!document.getElementById('dga-panel') && result.panelHidden !== true) {
            createPanel();
          }
        });
      }
    }

    if (request.action === 'RESET_CANDLES') {
      window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
      sendResponse({ success: true });
      return true;
    }
  });

  chrome.storage.local.get(['dga_subscription_valid', 'panelHidden'], (result) => {
    if (result.dga_subscription_valid === true && result.panelHidden !== true) {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createPanel);
      } else {
        createPanel();
      }
    }
  });
})();