const apiUrl = 'https://api.trademun.ir';

function formatDate(dateStr) {
  if (!dateStr) return "نامحدود";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "نامشخص";
    return d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch (e) {
    return "نامشخص";
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const states = {
    loading: document.getElementById('state-loading'),
    connected: document.getElementById('state-connected'),
    disconnected: document.getElementById('state-disconnected'),
  };
  const btns = {
    activate: document.getElementById('btn-activate'),
    deactivate: document.getElementById('btn-deactivate'),
    refresh: document.getElementById('btn-refresh'),
    reset: document.getElementById('btn-reset-candles'),
  };
  const toggleContainer = document.getElementById('toggle-panel-container');
  const togglePanel = document.getElementById('toggle-panel');
  const toggleOptionalContainer = document.getElementById('toggle-optional-container');
  const toggleOptional = document.getElementById('toggle-optional');
  const toggleInlineContainer = document.getElementById('toggle-inline-container');
  const toggleInline = document.getElementById('toggle-inline');
  
  const exchangeShortcuts = document.getElementById('exchange-shortcuts');
  const disconnectedTitle = document.getElementById('disconnected-title');
  const userInfo = document.getElementById('user-info');
  const errorReason = document.getElementById('error-reason');
  const guideTip = document.getElementById('extension-guide-tip');

  function showState(stateName) {
    Object.values(states).forEach(el => el.classList.add('hidden'));
    states[stateName].classList.remove('hidden');
    Object.values(btns).forEach(btn => { if(btn) btn.classList.add('hidden'); });
    toggleContainer.classList.add('hidden');
    toggleOptionalContainer.classList.add('hidden');
    if (toggleInlineContainer) toggleInlineContainer.classList.add('hidden');
    exchangeShortcuts.classList.add('hidden');
    if (guideTip) guideTip.classList.add('hidden');
  }

  // 👈 تابع جدید: چک کردن اینکه پنل در صفحه فعال هست یا نه
  function checkPanelExists(callback) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab || !activeTab.url || (!activeTab.url.includes('alphagoldx') && !activeTab.url.includes('daryagold'))) {
        callback(false, false);
        return;
      }

      // چک پنل شناور
      chrome.tabs.sendMessage(activeTab.id, { action: 'CHECK_FLOATING_PANEL' }, (resFloat) => {
        if (chrome.runtime.lastError) {
          callback(false, false);
          return;
        }
        const floatExists = resFloat && resFloat.exists;
        
        // چک پنل ثابت
        chrome.tabs.sendMessage(activeTab.id, { action: 'CHECK_INLINE_PANEL' }, (resInline) => {
          const inlineExists = resInline && resInline.exists;
          callback(floatExists, inlineExists);
        });
      });
    });
  }

  async function checkStatus() {
    showState('loading');
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      const isExchangePage = activeTab && activeTab.url && 
        (activeTab.url.includes('alphagoldx') || activeTab.url.includes('daryagold'));
      
      if (!isExchangePage) {
        showState('disconnected');
        disconnectedTitle.textContent = 'صفحه پشتیبانی نمی‌شود';
        errorReason.innerHTML = 'این اکستنشن فقط در صفحات <b>دریا گلد</b> و <b>آلفا گلد</b> فعال است.<br>لطفاً به صفحه معاملات این صرافی‌ها بروید.';
        exchangeShortcuts.classList.remove('hidden');
        return;
      }

      chrome.storage.local.get(['extToken', 'panelHidden', 'optionalEnabled', 'inlineEnabled'], async (result) => {
        const token = result.extToken;
        const panelHidden = result.panelHidden === true;
        const optionalEnabled = result.optionalEnabled === true;
        const inlineEnabled = result.inlineEnabled === true;
        
        if (!token) {
          showState('disconnected');
          disconnectedTitle.textContent = 'اتصال قطع است';
          errorReason.textContent = 'لطفاً به حساب تریدمون متصل شوید.';
          btns.activate.classList.remove('hidden');
          exchangeShortcuts.classList.remove('hidden'); 
          if (guideTip) guideTip.classList.remove('hidden'); 
          return;
        }

        try {
          const res = await fetch(`${apiUrl}/extension/verify`, {
            method: 'GET',
            headers: { 'X-Extension-Token': token }
          });
          const data = await res.json();

          if (data.valid) {
            showState('connected');
            disconnectedTitle.textContent = 'اتصال قطع است'; 
            
            const planFa = { "free": "رایگان", "1_month": "یک ماهه", "3_months": "سه ماهه", "6_months": "شش ماهه", "12_months": "یک ساله" }[data.plan] || data.plan;
            let expText = formatDate(data.expires_at);
            
            userInfo.innerHTML = `
              <b>${data.user_name}</b><br>
              <span style="font-size:10px; opacity:0.8;">پلن: ${planFa} | انقضا: ${expText}</span>
            `;
            
            toggleContainer.classList.remove('hidden');
            toggleOptionalContainer.classList.remove('hidden');
            if (toggleInlineContainer) toggleInlineContainer.classList.remove('hidden');
            
            btns.deactivate.classList.remove('hidden');
            btns.reset.classList.remove('hidden');
            exchangeShortcuts.classList.remove('hidden'); 
            if (guideTip) guideTip.classList.remove('hidden'); 

            // 👈 چک کردن وضعیت واقعی پنل‌ها در صفحه
            checkPanelExists((floatExists, inlineExists) => {
              togglePanel.checked = floatExists;
              toggleInline.checked = inlineExists;
              toggleOptional.checked = optionalEnabled;
            });

          } else {
            showState('disconnected');
            
            if (data.reason && data.reason.startsWith('expired_at:')) {
              disconnectedTitle.textContent = 'اشتراک منقضی شده';
            } else if (data.reason === 'no_active_subscription') {
              disconnectedTitle.textContent = 'اشتراک فعال نیست';
            } else {
              disconnectedTitle.textContent = 'اتصال قطع است';
            }

            if (data.reason && data.reason.startsWith('expired_at:')) {
              const expDateStr = data.reason.split(':')[1];
              errorReason.innerHTML = `اشتراک شما در تاریخ <b style="unicode-bidi: embed; direction: rtl; display: inline-block;">${formatDate(expDateStr)}</b> به پایان رسیده است.<br>لطفاً از سایت تمدید کنید.`;
            } else if (data.reason === 'no_active_subscription') {
              errorReason.textContent = 'اشتراک فعالی برای این حساب یافت نشد.';
            } else if (data.reason === 'invalid_or_expired_token') {
              errorReason.textContent = 'اتصال منقضی شده است. لطفاً دوباره متصل شوید.';
            } else {
              errorReason.textContent = 'خطا در اتصال. لطفاً دوباره تلاش کنید.';
            }
            
            btns.activate.classList.remove('hidden');
            exchangeShortcuts.classList.remove('hidden');
            if (data.reason === 'invalid_or_expired_token') {
              chrome.storage.local.remove('extToken');
            }
          }
        } catch (err) {
          showState('disconnected');
          disconnectedTitle.textContent = 'خطای شبکه';
          errorReason.textContent = 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید.';
          btns.refresh.classList.remove('hidden');
        }
      });
    });
  }

  // 👈 دکمه اتصال: پنجره باز می‌کند و به background پیام می‌دهد
  btns.activate.addEventListener('click', () => {
    const connectUrl = 'https://trademun.ir/extension/connect';
    
    chrome.windows.create({
      url: connectUrl,
      type: 'popup',
      width: 500,
      height: 650,
      focused: true
    }, (window) => {
      window.close(); // پاپ‌آپ افزونه را می‌بندیم
      
      // 👈 به background پیام می‌دهیم که پنجره باز شد و باید نظارت کند
      chrome.runtime.sendMessage({ 
        action: 'WATCH_AUTH_WINDOW', 
        windowId: window.id 
      });
    });
  });


  btns.deactivate.addEventListener('click', () => {
    chrome.storage.local.remove('extToken', () => {
      // 👈 وضعیت اشتراک را هم false کن تا پنل‌ها ساخته نشوند
      chrome.storage.local.set({ dga_subscription_valid: false }, () => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
              chrome.tabs.sendMessage(tab.id, { action: 'SUBSCRIPTION_STATUS', valid: false, serverError: false }).catch(() => {});
            }
          });
        });
        checkStatus();
      });
    });
  });

  btns.reset.addEventListener('click', () => {
    if (confirm('⚠️ آیا از پاک کردن تمام کندل‌ها و شروع مجدد جمع‌آوری اطلاعات مطمئن هستید؟')) {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
            chrome.tabs.sendMessage(tab.id, { action: 'RESET_CANDLES' }).catch(() => {});
          }
        });
      });
      alert('کندل‌ها ریست شدند. لطفاً صفحه صرافی را رفرش کنید (F5).');
    }
  });

  if(btns.refresh) btns.refresh.addEventListener('click', checkStatus);

  // سوئیچ پنل شناور
  togglePanel.addEventListener('change', (e) => {
    const isVisible = e.target.checked;
    chrome.storage.local.set({ panelHidden: !isVisible }, () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
            if (isVisible) {
              chrome.tabs.sendMessage(tab.id, { action: 'SHOW_PANEL' }).catch(() => {});
            } else {
              chrome.tabs.sendMessage(tab.id, { action: 'HIDE_PANEL' }).catch(() => {});
            }
          }
        });
      });
    });
  });

  // سوئیچ PnL
  toggleOptional.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ optionalEnabled: enabled }, () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
            chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_OPTIONAL', enabled }).catch(() => {});
          }
        });
      });
    });
  });


    // سوئیچ پنل ثابت
  if (toggleInline) {
    toggleInline.addEventListener('change', (e) => {
      const enabled = e.target.checked;
      chrome.storage.local.set({ inlineEnabled: enabled }, () => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('alphagoldx') || tab.url.includes('daryagold'))) {
              chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_INLINE', enabled }).catch(() => {});
            }
          });
        });
      });
    });
  }



    // 👈 تایمر خودکار: فقط بعد از کلیک روی دکمه اتصال و تا زمانی که وضعیت قطع است
  let autoCheckInterval = null;
  let autoCheckCounter = 0; // 👈 شمارنده برای جلوگیری از حلقه بی‌نهایت
  
  function startAutoCheck() {
    if (autoCheckInterval) clearInterval(autoCheckInterval);
    autoCheckCounter = 0; // ریست شمارنده
    
    autoCheckInterval = setInterval(() => {
      autoCheckCounter++;
      
      // 👈 اگر بیش از 15 بار (30 ثانیه) چک کرد و هنوز وصل نشد، متوقف کن
      if (autoCheckCounter > 5) {
        clearInterval(autoCheckInterval);
        autoCheckInterval = null;
        return;
      }
      
      const isDisconnected = !states.disconnected.classList.contains('hidden');
      
      // 👈 فقط اگر وضعیت قطع بود و توکن وجود داشت، چک کن
      if (isDisconnected) {
        chrome.storage.local.get(['extToken'], (result) => {
          if (result.extToken) {
            checkStatus();
          }
        });
      } else {
        // 👈 اگر وصل شد (خواه اشتراک دارد یا لاگین کرده)، تایمر را متوقف کن
        clearInterval(autoCheckInterval);
        autoCheckInterval = null;
      }
    }, 2000); // هر 2 ثانیه
  }
  // 👈 دکمه اتصال: پنجره باز می‌کند و تایمر را شروع می‌کند
  btns.activate.addEventListener('click', () => {
    const connectUrl = 'https://trademun.ir/extension/connect';
    
    chrome.windows.create({
      url: connectUrl,
      type: 'popup',
      width: 500,
      height: 650,
      focused: true
    }, (window) => {
      window.close(); // پاپ‌آپ افزونه را می‌بندیم
    });

    // 👈 بعد از کلیک روی اتصال، تایمر را شروع کن
    startAutoCheck();
  });

  checkStatus();
  // 👈 تایمر خودکار را شروع نکن (فقط بعد از کلیک روی دکمه اتصال شروع می‌شود)
});