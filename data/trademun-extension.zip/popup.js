// popup.js
function formatDate(dateStr) {
  if (!dateStr) return "نامحدود";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "نامشخص";
    return d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch (e) { return "نامشخص"; }
}

document.addEventListener('DOMContentLoaded', async () => {
  const states = {
    loading: document.getElementById('state-loading'),
    connected: document.getElementById('state-connected'),
    disconnected: document.getElementById('state-disconnected'),
  };
  const btns = {
    activate: document.getElementById('btn-activate'),
    deactivate: document.getElementById('btn-deactivate'),
    refresh: document.getElementById('btn-refresh'),
    reset: document.getElementById('btn-reset-candles'),
  };
  const toggleContainer = document.getElementById('toggle-panel-container');
  const togglePanel = document.getElementById('toggle-panel');
  const toggleOptionalContainer = document.getElementById('toggle-optional-container');
  const toggleOptional = document.getElementById('toggle-optional');
  const toggleInlineContainer = document.getElementById('toggle-inline-container');
  const toggleInline = document.getElementById('toggle-inline');
  
  const exchangeShortcuts = document.getElementById('exchange-shortcuts');
  const disconnectedTitle = document.getElementById('disconnected-title');
  const userInfo = document.getElementById('user-info');
  const errorReason = document.getElementById('error-reason');
  const guideTip = document.getElementById('extension-guide-tip');

  function showState(stateName) {
    Object.values(states).forEach(el => el.classList.add('hidden'));
    states[stateName].classList.remove('hidden');
    Object.values(btns).forEach(btn => { if(btn) btn.classList.add('hidden'); });
    toggleContainer.classList.add('hidden');
    toggleOptionalContainer.classList.add('hidden');
    if (toggleInlineContainer) toggleInlineContainer.classList.add('hidden');
    exchangeShortcuts.classList.add('hidden');
    if (guideTip) guideTip.classList.add('hidden');
  }

  function getExchangeTab(callback) {
    chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
      const activeTab = activeTabs[0];
      if (activeTab && activeTab.url && (activeTab.url.includes('alphagoldx') || activeTab.url.includes('daryagold'))) {
        callback(activeTab); return;
      }
      chrome.tabs.query({}, (allTabs) => {
        let exchangeTab = null;
        for (let i = allTabs.length - 1; i >= 0; i--) {
          const tab = allTabs[i];
          const url = tab.url || tab.pendingUrl || '';
          if (url.includes('alphagoldx') || url.includes('daryagold')) { exchangeTab = tab; break; }
        }
        callback(exchangeTab);
      });
    });
  }

  function checkPanelExists(callback) {
    getExchangeTab((exchangeTab) => {
      if (!exchangeTab) { callback(false, false); return; }
      chrome.tabs.sendMessage(exchangeTab.id, { action: 'CHECK_FLOATING_PANEL' }, (resFloat) => {
        if (chrome.runtime.lastError) { callback(false, false); return; }
        const floatExists = resFloat && resFloat.exists;
        chrome.tabs.sendMessage(exchangeTab.id, { action: 'CHECK_INLINE_PANEL' }, (resInline) => {
          const inlineExists = resInline && resInline.exists;
          callback(floatExists, inlineExists);
        });
      });
    });
  }

  function renderUI() {
    showState('loading');
    
    getExchangeTab((exchangeTab) => {
      if (!exchangeTab) {
        showState('disconnected');
        disconnectedTitle.textContent = 'صفحه پشتیبانی نمی‌شود';
        errorReason.innerHTML = 'این اکستنشن فقط در صفحات <b>دریا گلد</b> و <b>آلفا گلد</b> فعال است.';
        exchangeShortcuts.classList.remove('hidden');
        return;
      }

      chrome.storage.local.get(['extToken', 'optionalEnabled'], (result) => {
        if (!result.extToken) {
          showState('disconnected');
          disconnectedTitle.textContent = 'اتصال قطع است';
          errorReason.textContent = 'لطفاً به حساب تریدمون متصل شوید.';
          btns.activate.classList.remove('hidden');
          exchangeShortcuts.classList.remove('hidden'); 
          if (guideTip) guideTip.classList.remove('hidden'); 
          return;
        }

        chrome.runtime.sendMessage({ action: 'FORCE_RECHECK' }, (response) => {
          if (chrome.runtime.lastError || !response) {
            showState('disconnected');
            disconnectedTitle.textContent = 'خطای ارتباط با پس‌زمینه';
            errorReason.textContent = 'لطفاً دوباره تلاش کنید.';
            btns.refresh.classList.remove('hidden');
            return;
          }

          if (response.valid && response.user_info) {
            showState('connected');
            const planFa = { "free": "رایگان", "1_month": "یک ماهه", "3_months": "سه ماهه", "6_months": "شش ماهه", "12_months": "یک ساله" }[response.user_info.plan] || response.user_info.plan;
            
            userInfo.innerHTML = `
              <b>${response.user_info.user_name}</b><br>
              <span style="font-size:10px; opacity:0.8;">پلن: ${planFa} | انقضا: ${formatDate(response.user_info.expires_at)}</span>
            `;
            
            toggleContainer.classList.remove('hidden');
            toggleOptionalContainer.classList.remove('hidden');
            if (toggleInlineContainer) toggleInlineContainer.classList.remove('hidden');
            btns.deactivate.classList.remove('hidden');
            btns.reset.classList.remove('hidden');
            exchangeShortcuts.classList.remove('hidden'); 
            if (guideTip) guideTip.classList.remove('hidden'); 

            checkPanelExists((floatExists, inlineExists) => {
              togglePanel.checked = floatExists;
              toggleInline.checked = inlineExists;
              toggleOptional.checked = result.optionalEnabled === true;
            });
          } else {
            showState('disconnected');
            if (response.reason === 'network_error') {
              disconnectedTitle.textContent = 'خطای شبکه';
              errorReason.textContent = 'اتصال به سرور برقرار نشد. فیلترشکن خود را بررسی کنید.';
            } else if (response.reason === 'invalid_or_expired_token' || response.reason === 'invalid') {
              disconnectedTitle.textContent = 'اتصال نامعتبر است';
              errorReason.textContent = 'لطفاً دوباره متصل شوید.';
            } else {
              disconnectedTitle.textContent = 'اتصال قطع است';
              errorReason.textContent = 'لطفاً دوباره متصل شوید.';
            }
            btns.activate.classList.remove('hidden');
            btns.refresh.classList.remove('hidden');
            exchangeShortcuts.classList.remove('hidden');
          }
        });
      });
    });
  }

  btns.activate.addEventListener('click', () => {
    chrome.windows.create({
      url: 'https://trademun.ir/extension/connect',
      type: 'popup', width: 500, height: 650, focused: true
    }, (window) => {
      if (window && window.id) chrome.runtime.sendMessage({ action: 'WATCH_AUTH_WINDOW', windowId: window.id });
      setTimeout(() => { window.close(); }, 100);
    });
  });

  btns.deactivate.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'FORCE_DISCONNECT' }, () => renderUI());
  });

  btns.reset.addEventListener('click', () => {
    if (confirm('⚠️ آیا از پاک کردن تمام کندل‌ها مطمئن هستید؟')) {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          const url = tab.url || tab.pendingUrl || '';
          if (url.includes('alphagoldx') || url.includes('daryagold')) {
            chrome.tabs.sendMessage(tab.id, { action: 'RESET_CANDLES' }).catch(() => {});
          }
        });
      });
    }
  });

  if(btns.refresh) btns.refresh.addEventListener('click', renderUI);

  togglePanel.addEventListener('change', (e) => {
    const isVisible = e.target.checked;
    chrome.storage.local.set({ panelHidden: !isVisible }, () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          const url = tab.url || tab.pendingUrl || '';
          if (url.includes('alphagoldx') || url.includes('daryagold')) {
            if (isVisible) {
              chrome.tabs.sendMessage(tab.id, { action: 'SHOW_PANEL' }).catch(() => {});
            } else {
              chrome.tabs.sendMessage(tab.id, { action: 'HIDE_PANEL' }).catch(() => {});
            }
          }
        });
      });
    });
  });

  if (toggleInline) {
    toggleInline.addEventListener('change', (e) => {
      const enabled = e.target.checked;
      chrome.storage.local.set({ inlineEnabled: enabled }, () => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            const url = tab.url || tab.pendingUrl || '';
            if (url.includes('alphagoldx') || url.includes('daryagold')) {
              chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_INLINE', enabled }).catch(() => {});
            }
          });
        });
      });
    });
  }

  toggleOptional.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ optionalEnabled: enabled }, () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          const url = tab.url || tab.pendingUrl || '';
          if (url.includes('alphagoldx') || url.includes('daryagold')) {
            chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_OPTIONAL', enabled }).catch(() => {});
          }
        });
      });
    });
  });

  renderUI();

  // 👈 هر تغییری در استوریج، پاپ‌آپ را فوراً آپدیت می‌کند (بدون نیاز به رفرش)
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
      if (changes.extToken || changes.dga_subscription_valid || changes.user_info) {
        renderUI();
      }
    }
  });
});