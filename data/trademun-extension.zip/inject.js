(function() {
  'use strict';
  console.log('%c[Goldmun] Candles builder started...', 'color: orange; font-weight: bold;');

  let currentTF = '1m';
  const tfMs = { '1m': 60000, '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000, '4h': 14400000, '1d': 86400000 };

  // 👈 تابعی که تایم‌فریم رو از روی دکمه‌های فعال سایت تشخیص میده
  function detectSiteTF() {
    try {
      // پیدا کردن دکمه‌های تایم‌فریم در صرافی دریاگلد و آلفا
      const activeBtns = document.querySelectorAll('.timeframe-btn.active, .tf-btn.active, [class*="timeframe"] [class*="active"], [class*="interval"] [class*="active"]');
      
      if (activeBtns.length > 0) {
        for (let btn of activeBtns) {
          const txt = btn.innerText.trim().toLowerCase();
          if (txt.includes('1m') || txt.includes('1د') || txt.includes('1 دقیقه')) return '1m';
          if (txt.includes('5m') || txt.includes('5د')) return '5m';
          if (txt.includes('15m') || txt.includes('15د')) return '15m';
          if (txt.includes('30m') || txt.includes('30د')) return '30m';
          if (txt.includes('1h') || txt.includes('1س') || txt.includes('1 ساعت')) return '1h';
          if (txt.includes('4h') || txt.includes('4س')) return '4h';
          if (txt.includes('1d') || txt.includes('1ر') || txt.includes('روزانه')) return '1d';
        }
      }
    } catch (e) {}
    return currentTF; // اگه پیدا نکرد، همون قبلی رو نگه دار
  }

  function getStorageKey() {
    const path = window.location.pathname;
    const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
    const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';
    return `goldmun_candles_${host}_${symbol}_${currentTF}`;
  }

  function getCandles() {
    try { return JSON.parse(localStorage.getItem(getStorageKey())) || []; } catch (e) { return []; }
  }

  function saveCandles(candles) {
    try { localStorage.setItem(getStorageKey(), JSON.stringify(candles)); } catch (e) {}
  }

  let lastProcessedPrice = 0;
  function handlePrice(price) {
    if (!price || price <= 0 || price === lastProcessedPrice) return;
    lastProcessedPrice = price;
    let candles = getCandles();
    const now = Date.now();
    const interval = tfMs[currentTF] || 60000;
    const currentTime = Math.floor(now / interval) * interval;

    if (candles.length === 0) {
      candles.push({ time: currentTime, open: price, high: price, low: price, close: price });
    } else {
      const last = candles[candles.length - 1];
      
      // 👈 چک کردن گپ زمانی بیش از ۱ ساعت
      const gapMinutes = (currentTime - last.time) / 60000;
      if (gapMinutes > 60) {
        // اگر گپ بیش از ۱ ساعت بود، یک فلگ در localStorage بذار
        localStorage.setItem('goldmun_gap_detected', 'true');
      }

      if (currentTime > last.time) {
        candles.push({ time: currentTime, open: price, high: price, low: price, close: price });
      } else {
        last.close = price;
        if (price > last.high) last.high = price;
        if (price < last.low) last.low = price;
      }
    }
    if (candles.length > 1000) candles = candles.slice(-1000);
    saveCandles(candles);
  }


    // 👈 تایمر مستقل برای تشخیص گپ زمانی (حتی اگر قیمت جدیدی نیاید)
  setInterval(() => {
    try {
      const candles = getCandles();
      if (candles.length > 0) {
        const lastCandle = candles[candles.length - 1];
        const now = Date.now();
        const interval = tfMs[currentTF] || 60000;
        const currentTime = Math.floor(now / interval) * interval;
        
        const gapMinutes = (currentTime - lastCandle.time) / 60000;
        
        // اگر بیش از ۱ ساعت از آخرین کندل گذشته باشد
        if (gapMinutes > 60) {
          const alreadyFlagged = localStorage.getItem('goldmun_gap_detected');
          if (alreadyFlagged !== 'true') {
            localStorage.setItem('goldmun_gap_detected', 'true');
            console.log('[Goldmun] Gap detected via timer:', gapMinutes, 'minutes');
          }
        }
      }
    } catch (e) {
      console.error('[Goldmun] Gap detection error:', e);
    }
  }, 60000); // هر ۱ دقیقه چک کن

  const OriginalWS = window.WebSocket;
  window.WebSocket = function(url, protocols) {
    const ws = new OriginalWS(url, protocols);
    ws.addEventListener('message', function(event) {
      if (!url.includes('/orders/')) return;
      try {
        // هر بار قبل از پردازش قیمت، تایم‌فریم رو چک کن
        currentTF = detectSiteTF();
        const data = JSON.parse(event.data);
        let price = data.orders?.price || data.price || data.P || data.p;
        if (price) handlePrice(parseFloat(price));
      } catch (e) {}
    });
    return ws;
  };
  window.WebSocket.prototype = OriginalWS.prototype;

  window.addEventListener('message', function(event) {
    if (event.data && event.data.type === 'DGA_TF_CHANGE') {
      if (tfMs[event.data.tf]) currentTF = event.data.tf;
    }
    if (event.data && event.data.type === 'DGA_RESET_DATA') {
      const path = window.location.pathname;
      const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
      const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith(`goldmun_candles_${host}_${symbol}_`)) localStorage.removeItem(key);
      });
      lastProcessedPrice = 0;
      const lastKnownPrice = event.data.lastPrice || 0;
      if (lastKnownPrice > 0) {
        const now = Date.now();
        const interval = tfMs[currentTF] || 60000;
        const currentTime = Math.floor(now / interval) * interval;
        saveCandles([{ time: currentTime, open: lastKnownPrice, high: lastKnownPrice, low: lastKnownPrice, close: lastKnownPrice }]);
        lastProcessedPrice = lastKnownPrice;
      }
      window.postMessage({ type: 'DGA_DATA_CLEARED' }, '*');
    }
  });
  console.log('%c[Goldmun] Candles builder ready ✅', 'color: cyan; font-weight: bold;');
})();