// inline.js (نسخه نهایی - رفع مشکل آلفا گلد + استایل اولیه)
(function() {
  'use strict';

  console.log('INLINE.JS LOADED SUCCESSFULLY');

  const isAlpha = window.location.hostname.includes('alphagoldx');
  const exchangeName = isAlpha ? 'آلفا گلد' : 'دریا گلد';
  let inlinePanel = null;
  let isInlineSubscriptionValid = false;

  function getTargetElement() {
    try {
      if (isAlpha) {
        const iframe = document.getElementById('myIframe');
        if (iframe) {
          const chartContainer = iframe.parentElement;
          if (chartContainer && chartContainer.id !== 'dga-chart-wrapper') {
            if (!chartContainer.getAttribute('data-original-styles')) {
              chartContainer.setAttribute('data-original-styles', 'true');
            }

            chartContainer.style.display = 'flex';
            chartContainer.style.gap = '15px';
            chartContainer.style.width = '100%';
            
            const isMobile = window.innerWidth < 1024;
            
            if (isMobile) {
              chartContainer.style.flexDirection = 'column';
              iframe.style.width = '100%';
              iframe.style.minHeight = '400px';
            } else {
              chartContainer.style.flexDirection = 'row';
              chartContainer.style.alignItems = 'stretch';
              iframe.style.width = 'calc(100% - 350px)';
              iframe.style.minHeight = '650px';
              iframe.style.flexGrow = '1';
            }

            let panelContainer = document.getElementById('dga-inline-container');
            if (!panelContainer) {
              panelContainer = document.createElement('div');
              panelContainer.id = 'dga-inline-container';
              panelContainer.style.width = isMobile ? '100%' : '340px';
              panelContainer.style.minWidth = isMobile ? '100%' : '340px';
              panelContainer.style.height = 'auto';
              panelContainer.style.display = 'flex';
              panelContainer.style.flexDirection = 'column';
              
              if (isMobile) {
                chartContainer.appendChild(panelContainer);
              } else {
                chartContainer.insertBefore(panelContainer, iframe);
              }
            }
            
            return panelContainer;
          }
        }
        return null;
      } else {
        const headings = document.querySelectorAll('h3');
        for (let h of headings) {
          if (h.innerText && (h.innerText.trim() === 'سفارش ها' || h.innerText.trim() === 'سفارش‌ها')) {
            let parent = h.parentElement;
            while (parent && parent !== document.body) {
              if (parent.classList.contains('rounded-3xl') || parent.classList.contains('rounded-2xl')) {
                return parent;
              }
              parent = parent.parentElement;
            }
          }
        }
        return null;
      }
    } catch (e) {
      return null;
    }
  }

  function createInlinePanel() {
    if (document.getElementById('dga-inline-panel')) return;

    chrome.storage.local.get(['dga_subscription_valid', 'inlineEnabled'], (result) => {
      if (result.dga_subscription_valid !== true) return;
      if (result.inlineEnabled !== true) return;

      isInlineSubscriptionValid = true;

      const target = getTargetElement();
      if (!target) return;

      console.log('Creating inline panel...');

      const panel = document.createElement('div');
      panel.id = 'dga-inline-panel';
      panel.className = 'dga-panel';
      
      const isMobile = window.innerWidth < 1024;
      const panelHeight = isMobile ? 'auto' : '650px';

      panel.style.cssText = `
        position: relative;
        top: auto;
        right: auto;
        width: 100%;
        height: ${panelHeight};
        max-height: ${isMobile ? 'none' : '100%'};
        overflow-y: auto;
        margin: 0;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      `;

      panel.innerHTML = `
        <div class="dga-header" id="dga-inline-drag-handle">
          <div class="dga-title" style="color: #f3f5f8;">نوسان‌گیر تریدمون (${exchangeName})</div>
          <div class="dga-header-actions">
            <button class="dga-icon-btn" id="dga-inline-help" title="راهنما">؟</button>
            <button class="dga-icon-btn" id="dga-inline-sound" title="صدا">🔊</button>
            <button class="dga-icon-btn" id="dga-inline-reset" title="ریست">↺</button>
          </div>
        </div>
        
        <div class="dga-body" id="dga-inline-body" style="position: relative;">
          <div id="dga-inline-auth-warning" style="
            display: none; flex-direction: column; align-items: center; justify-content: center;
            text-align: center; padding: 20px; box-sizing: border-box;
            background: linear-gradient(145deg, #07111f, #0d1b2d);
            border-radius: 8px; margin: 10px 0; border: 1px solid rgba(239, 68, 68, 0.3);
          ">
            <div style="font-size: 40px; margin-bottom: 10px;">🔒</div>
            <div style="color: #ef4444; font-weight: bold; margin-bottom: 8px; font-size: 14px;">اشتراک شما فعال نیست</div>
            <div style="color: #94a3b8; font-size: 11px; margin-bottom: 16px; line-height: 1.6;">
              برای مشاهده تحلیل‌ها، از سایت تریدمون اشتراک تهیه کنید.
            </div>
            <a href="https://trademun.ir/dashboard" target="_blank" style="background: #d6ad60; color: #07111f; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 12px;">رفتن به داشبورد</a>
          </div>

          <div id="dga-inline-body-content">
            <div class="dga-price-compare-bar">
              <div class="dga-price-compare-item">
                <span class="dga-pc-label">قیمت صرافی:</span>
                <span class="dga-pc-value" id="dga-inline-price">--</span>
              </div>
              <div class="dga-price-compare-item">
                <span class="dga-pc-label">قیمت فارکس:</span>
                <span class="dga-pc-value" id="dga-inline-tv-price">--</span>
              </div>
            </div>

            <div class="dga-top-bar">
              <div class="dga-progress-wrapper">
                <span class="dga-progress-label">کندل‌ها</span>
                <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-inline-candle-progress"></div></div>
                <span class="dga-progress-text" id="dga-inline-candle-progress-text">0/200</span>
              </div>
            </div>

            <div class="dga-session-bar" id="dga-inline-session-bar">
              <span id="dga-inline-session-text">در حال بررسی سشن...</span>
            </div>

            <div class="dga-section-container">
              <div class="dga-section-header">
                <span class="dga-section-title">تحلیل TradingView</span>
              </div>
              
              <div class="dga-tv-launcher">
                <button class="dga-tv-launch-btn" id="dga-inline-tv-launch">
                  📈 باز کردن تحلیل زنده TradingView
                </button>
              </div>

              <div class="dga-tv-summary-card-big" id="dga-inline-tv-summary-card">
                <div class="dga-tv-summary-big-header">
                  <span class="dga-tv-summary-big-title">🎯 خلاصه سیگنال هدف</span>
                  <button class="dga-icon-btn" id="dga-inline-tv-sound" title="صدای TradingView">🔔</button>
                </div>
                <div class="dga-tv-summary-big-signal" id="dga-inline-tv-summary-signal">--</div>
                <div class="dga-tv-summary-big-counts">
                  <span class="sell">🔻 فروش: <b id="dga-inline-tv-summary-sell">0</b></span>
                  <span class="neutral">⚪ خنثی: <b id="dga-inline-tv-summary-neutral">0</b></span>
                  <span class="buy">🔺 خرید: <b id="dga-inline-tv-summary-buy">0</b></span>
                </div>
              </div>

              <div class="dga-tv-cards-grid">
                <div class="dga-tv-card dga-tv-osc-card">
                  <div class="dga-tv-card-header">
                    <span class="dga-tv-card-title">📊 نوسانگیر</span>
                    <span class="dga-tv-badge" id="dga-inline-tv-osc-badge">--</span>
                  </div>
                  <div class="dga-tv-card-counts">
                    <span class="sell">فروش: <b id="dga-inline-tv-osc-sell">0</b></span>
                    <span class="neutral">خنثی: <b id="dga-inline-tv-osc-neutral">0</b></span>
                    <span class="buy">خرید: <b id="dga-inline-tv-osc-buy">0</b></span>
                  </div>
                </div>
                <div class="dga-tv-card dga-tv-ma-card">
                  <div class="dga-tv-card-header">
                    <span class="dga-tv-card-title">📈 میانگین متحرک</span>
                    <span class="dga-tv-badge" id="dga-inline-tv-ma-badge">--</span>
                  </div>
                  <div class="dga-tv-card-counts">
                    <span class="sell">فروش: <b id="dga-inline-tv-ma-sell">0</b></span>
                    <span class="neutral">خنثی: <b id="dga-inline-tv-ma-neutral">0</b></span>
                    <span class="buy">خرید: <b id="dga-inline-tv-ma-buy">0</b></span>
                  </div>
                </div>
              </div>
            </div>

            <div class="dga-section-container" style="margin-top: 10px;">
              <div class="dga-section-header">
                <span class="dga-section-title">تحلیل تیم Trademun</span>
              </div>

              <div class="dga-volatility-warning" id="dga-inline-volatility-warning" style="display: none;">
                <span>⚠️ نوسان بالا — با احتیاط معامله کن.</span>
              </div>

              <div class="dga-layers-grid">
                <div class="dga-layer-card" id="dga-inline-layer1-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">⚡ ۳ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="1">🔔</button>
                      <span class="dga-layer-badge" id="dga-inline-layer1-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-inline-layer1-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-inline-layer1-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-inline-layer1-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-inline-layer1-sl-tp" style="display: none;">
                   <span>SL: <b id="dga-inline-layer1-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-inline-layer1-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-inline-layer1-reason">--</div>
                </div>
                
                <div class="dga-layer-card" id="dga-inline-layer2-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">🎯 ۱۵ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="2">🔔</button>
                      <span class="dga-layer-badge" id="dga-inline-layer2-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-inline-layer2-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-inline-layer2-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-inline-layer2-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-inline-layer2-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-inline-layer2-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-inline-layer2-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-inline-layer2-reason">--</div>
                </div>
                
                <div class="dga-layer-card" id="dga-inline-layer3-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">📊 ۵۰ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="3">🔔</button>
                      <span class="dga-layer-badge" id="dga-inline-layer3-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-inline-layer3-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-inline-layer3-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-inline-layer3-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-inline-layer3-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-inline-layer3-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-inline-layer3-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-inline-layer3-reason">--</div>
                </div>
                
                <div class="dga-layer-card" id="dga-inline-layer4-card">
                  <div class="dga-layer-header">
                    <span class="dga-layer-title">🏆 ۲۰۰ کندل</span>
                    <div class="dga-layer-header-actions">
                      <button class="dga-alarm-btn" data-layer="4">🔔</button>
                      <span class="dga-layer-badge" id="dga-inline-layer4-badge">--</span>
                    </div>
                  </div>
                  <span class="dga-layer-signal" id="dga-inline-layer4-signal">--</span>
                  <div class="dga-layer-confidence">
                    <div class="dga-progress-bar"><div class="dga-progress-fill" id="dga-inline-layer4-confidence"></div></div>
                    <span class="dga-progress-text" id="dga-inline-layer4-confidence-text">0%</span>
                  </div>
                  <div class="dga-layer-sl-tp" id="dga-inline-layer4-sl-tp" style="display: none;">
                    <span>SL: <b id="dga-inline-layer4-sl" class="dga-copyable">--</b></span>
                    <span>TP: <b id="dga-inline-layer4-tp" class="dga-copyable">--</b></span>
                  </div>
                  <div class="dga-layer-reason" id="dga-inline-layer4-reason">--</div>
                </div>
              </div>

              <div class="dga-consensus-card" id="dga-inline-consensus-card">
                <div class="dga-consensus-header">
                  <span class="dga-consensus-title">🎯 نتیجه نهایی Trademun</span>
                  <span class="dga-consensus-confidence" id="dga-inline-consensus-confidence">0%</span>
                </div>
                <div class="dga-consensus-text" id="dga-inline-consensus-text">--</div>
              </div>
            </div>

            <div class="dga-footer">
              <span>Trademun.ir </span>
              <span>تمامی تحلیل‌ها بر اساس الگوریتم‌های ریاضی و داده‌های تاریخی انجام می‌شود</span>
            </div>
          </div>
        </div>

        <div class="dga-modal" id="dga-inline-modal" style="display: none;">
          <div class="dga-modal-content">
            <div class="dga-modal-header">
              <h3 style="color: #d6ad60;">راهنمای جامع نوسان‌گیر تریدمون</h3>
              <button id="dga-inline-modal-close" style="color: #94a3b8;">×</button>
            </div>
            <div class="dga-modal-body">
              <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 12px; margin-bottom: 16px;">
                <h4 style="color: #ef4444; margin-top: 0; font-size: 13px;">⚠️ سلب مسئولیت و قوانین معاملاتی</h4>
                <p style="font-size: 11px; color: #94a3b8; line-height: 1.8; margin: 0; text-align: justify;">
                  سایت <b>تریدمون</b> صرفاً یک <b>تحلیل‌گر داده</b> و ارائه‌دهنده سیگنال‌های کمکی است. تمامی تحلیل‌ها بر اساس الگوریتم‌های ریاضی و داده‌های تاریخی انجام می‌شود و <b>هیچ‌گونه تضمینی برای سودآوری وجود ندارد</b>. تصمیم‌گیری نهایی برای ورود یا خروج از معامله، کاملاً بر عهده کاربر است و تریدمون هیچ مسئولیتی در قبال سود یا زیان احتمالی کاربران نمی‌پذیرد.
                </p>
              </div>

              <h4 style="color: #d6ad60; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">⏳ چرا باید صبر کنید؟ (مهم)</h4>
              <p style="font-size: 11px; color: #94a3b8; line-height: 1.8; text-align: justify;">
                به دلیل عدم فعالیت رباتی و <b>محافظت از حساب شما در صرافی</b>، اکستنشن برای راه‌اندازی اولیه و اطمینان از صحت سیگنال‌ها، نیاز به جمع‌آوری حداقل <b>۱۵ کندل (۱۵ دقیقه)</b> دارد. 
                <br><br>
                🔹 <b>توصیه اکید:</b> لطفاً پس از باز کردن صفحه صرافی، حداقل <b>یک ساعت</b> به اکستنشن زمان دهید تا دیتای کافی جمع‌آوری شده و تحلیل‌های لایه‌های بالاتر (مانند ۵۰ و ۲۰۰ کندل) فعال شوند.
              </p>

              <h4 style="color: #d6ad60; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">🔌 اکستنشن چطور کار می‌کند؟</h4>
              <ul style="padding-right: 20px; margin: 0 0 12px 0; font-size: 11px; line-height: 1.8; color: #94a3b8; text-align: justify;">
                <li>اکستنشن به صورت خودکار به WebSocket داخلی صرافی متصل می‌شود و قیمت‌های لحظه‌ای را بدون دستکاری در حساب شما دریافت می‌کند.</li>
                <li>داده‌ها در مرورگر شما (لوکال) به کندل تبدیل می‌شوند و تحلیل روی همین کندل‌ها انجام می‌شود.</li>
                <li>هیچ‌گونه سفارش خرید یا فروشی به صورت خودکار ثبت نمی‌شود.</li>
              </ul>

              <h4 style="color: #d6ad60; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">📊 نمایش درصد سود/زیان</h4>
              <p style="font-size: 11px; color: #94a3b8; line-height: 1.8; text-align: justify;">
                ما یک قابلیت اختیاری اضافه کردیم که درصد سود/زیان و قیمت لحظه‌ای هر معامله را در جدول معاملات صرافی نمایش می‌دهد. این اطلاعات در کنار هم قابل کپی هستند (برای کپی، روی قیمت کلیک کنید). اگر نمی‌خواهید این اطلاعات نمایش داده شوند، می‌توانید از طریق پاپ‌آپ افزونه (کلید «نمایش امکانات آپشنال») آن را غیرفعال کنید.
              </p>

              <h4 style="color: #d6ad60; border-bottom: 1px solid rgba(75, 85, 99, 0.3); padding-bottom: 4px; font-size: 12px;">🖥️ پنل شناور و پنل ثابت</h4>
              <p style="font-size: 11px; color: #94a3b8; line-height: 1.8; text-align: justify;">
                اکستنشن دو حالت نمایش داره:
                <br>
                🔹 <b>پنل شناور (Floating):</b> که قابل جابه‌جایی با موس هست و همیشه روی صفحه می‌مونه.
                <br>
                🔹 <b>پنل ثابت (Inline):</b> که در بدنه سایت و دقیقاً کنار چارت (در آلفا گلد) یا جای کارت سفارش‌ها (در دریا گلد) قرار می‌گیره.
                <br><br>
                برای فعال یا غیرفعال کردن هر کدوم، از <b>پاپ‌آپ افزونه</b> استفاده کنید.
              </p>

              <div style="text-align: center; margin-top: 20px; border-top: 1px solid rgba(75, 85, 99, 0.3); padding-top: 12px;">
                <button id="dga-inline-modal-accept" style="background: #d6ad60; color: #07111f; padding: 10px 24px; border-radius: 6px; border: none; font-weight: bold; font-size: 13px; cursor: pointer; width: 100%;">مطالعه کردم، ببند</button>
              </div>
            </div>
          </div>
        </div>
        `;

      if (!isAlpha) {
        target.innerHTML = '';
        target.appendChild(panel);
      } else {
        target.appendChild(panel);
      }
      
      inlinePanel = panel;

      document.getElementById('dga-inline-help').onclick = () => {
        const modal = document.getElementById('dga-inline-modal');
        if (modal) modal.style.display = 'flex';
      };
      
      document.getElementById('dga-inline-modal-close').onclick = () => {
        document.getElementById('dga-inline-modal').style.display = 'none';
      };

      document.getElementById('dga-inline-modal-accept').onclick = () => {
        document.getElementById('dga-inline-modal').style.display = 'none';
      };

      document.getElementById('dga-inline-sound').onclick = () => {
        const current = localStorage.getItem('dga_sound_enabled') !== 'false';
        const newState = !current;
        localStorage.setItem('dga_sound_enabled', newState ? 'true' : 'false');
        const btn = document.getElementById('dga-inline-sound');
        btn.style.opacity = newState ? '1' : '0.4';
        btn.style.textDecoration = newState ? 'none' : 'line-through';
      };

      document.getElementById('dga-inline-reset').onclick = () => {
        if (confirm('⚠️ آیا از پاک کردن تمام کندل‌ها مطمئن هستید؟')) {
          window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
        }
      };

      document.getElementById('dga-inline-tv-launch').onclick = () => {
        window.open('https://www.tradingview.com/symbols/XAUUSD/technicals/?exchange=FOREXCOM', '_blank');
      };

      panel.addEventListener('click', (e) => {
        const copyable = e.target.closest('.dga-copyable');
        if (!copyable) return;
        
        const text = copyable.innerText;
        if (!text || text === '--') return;
        
        e.stopPropagation();
        navigator.clipboard.writeText(text).then(() => {
          const originalText = copyable.innerText;
          const originalColor = copyable.style.color;
          
          copyable.innerText = 'کپی شد!';
          copyable.style.color = '#10b981';
          
          setTimeout(() => { 
            copyable.innerText = originalText; 
            copyable.style.color = originalColor; 
          }, 1000);
        }).catch(() => {});
      });
      
      document.querySelectorAll('#dga-inline-panel .dga-alarm-btn').forEach(btn => {
        const layer = btn.getAttribute('data-layer');
        const isEnabled = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
        btn.style.opacity = isEnabled ? '1' : '0.4';
        btn.style.textDecoration = isEnabled ? 'none' : 'line-through';
        btn.onclick = (e) => {
          e.stopPropagation();
          const current = localStorage.getItem(`dga_alarm_layer_${layer}`) !== 'false';
          localStorage.setItem(`dga_alarm_layer_${layer}`, current ? 'false' : 'true');
          btn.style.opacity = current ? '0.4' : '1';
          btn.style.textDecoration = current ? 'line-through' : 'none';
        };
      });
    });
  }

  function updateInlinePanel(data) {
    if (!inlinePanel) return;

    const authWarning = document.getElementById('dga-inline-auth-warning');
    const bodyContent = document.getElementById('dga-inline-body-content');

    if (!isInlineSubscriptionValid) {
      if (authWarning) authWarning.style.display = 'flex';
      if (bodyContent) bodyContent.style.display = 'none';
      return;
    } else {
      if (authWarning) authWarning.style.display = 'none';
      if (bodyContent) bodyContent.style.display = 'block';
    }

    if (data.price) {
      const el = document.getElementById('dga-inline-price');
      if (el) el.innerText = data.price.toFixed(2);
    }
    
    if (data.candlesCount !== undefined) {
      const count = data.candlesCount;
      const progress = document.getElementById('dga-inline-candle-progress');
      if (progress) progress.style.width = Math.min(100, (count / 200) * 100) + '%';
      const text = document.getElementById('dga-inline-candle-progress-text');
      if (text) text.innerText = `${count}/200`;
    }

    if (data.session) {
      const bar = document.getElementById('dga-inline-session-bar');
      const text = document.getElementById('dga-inline-session-text');
      if (bar && text) {
        text.innerText = data.session.message;
        bar.className = 'dga-session-bar' + (data.session.warning ? ' warning' : ' normal');
      }
    }

    if (data.tvData) {
      const tv = data.tvData;
      const tvPriceEl = document.getElementById('dga-inline-tv-price');
      if (tvPriceEl && tv.price) tvPriceEl.innerText = tv.price;

      const oscBadge = document.getElementById('dga-inline-tv-osc-badge');
      if (oscBadge && tv.oscillatorsSignal) {
        oscBadge.innerText = tv.oscillatorsSignal;
        oscBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.oscillatorsSignal);
      }
      if (tv.oscCounts) {
        const sellEl = document.getElementById('dga-inline-tv-osc-sell');
        const neutralEl = document.getElementById('dga-inline-tv-osc-neutral');
        const buyEl = document.getElementById('dga-inline-tv-osc-buy');
        if (sellEl) sellEl.innerText = tv.oscCounts.sell || 0;
        if (neutralEl) neutralEl.innerText = tv.oscCounts.neutral || 0;
        if (buyEl) buyEl.innerText = tv.oscCounts.buy || 0;
      }

      const maBadge = document.getElementById('dga-inline-tv-ma-badge');
      if (maBadge && tv.movingAveragesSignal) {
        maBadge.innerText = tv.movingAveragesSignal;
        maBadge.className = 'dga-tv-badge ' + getBadgeClass(tv.movingAveragesSignal);
      }
      if (tv.maCounts) {
        const sellEl = document.getElementById('dga-inline-tv-ma-sell');
        const neutralEl = document.getElementById('dga-inline-tv-ma-neutral');
        const buyEl = document.getElementById('dga-inline-tv-ma-buy');
        if (sellEl) sellEl.innerText = tv.maCounts.sell || 0;
        if (neutralEl) neutralEl.innerText = tv.maCounts.neutral || 0;
        if (buyEl) buyEl.innerText = tv.maCounts.buy || 0;
      }

      const bigSignal = document.getElementById('dga-inline-tv-summary-signal');
      if (bigSignal && tv.summary) {
        bigSignal.innerText = tv.summary;
        bigSignal.className = 'dga-tv-summary-big-signal ' + getBadgeClass(tv.summary);
        const card = document.getElementById('dga-inline-tv-summary-card');
        if (card) {
          card.className = 'dga-tv-summary-card-big';
          const lower = tv.summary.toLowerCase();
          if (lower.includes('buy')) card.classList.add('summary-long');
          else if (lower.includes('sell')) card.classList.add('summary-short');
          else card.classList.add('summary-neutral');
        }
      }
      if (tv.summaryCounts) {
        const sellEl = document.getElementById('dga-inline-tv-summary-sell');
        const neutralEl = document.getElementById('dga-inline-tv-summary-neutral');
        const buyEl = document.getElementById('dga-inline-tv-summary-buy');
        if (sellEl) sellEl.innerText = tv.summaryCounts.sell || 0;
        if (neutralEl) neutralEl.innerText = tv.summaryCounts.neutral || 0;
        if (buyEl) buyEl.innerText = tv.summaryCounts.buy || 0;
      }
    }

    const volWarning = document.getElementById('dga-inline-volatility-warning');
    if (volWarning) volWarning.style.display = data.volatilityWarning ? 'flex' : 'none';

    const layers = [data.layer1, data.layer2, data.layer3, data.layer4];
    layers.forEach((layer, idx) => {
      const num = idx + 1;
      const card = document.getElementById(`dga-inline-layer${num}-card`);
      if (!card || !layer) return;
      
      const badge = document.getElementById(`dga-inline-layer${num}-badge`);
      if (badge) badge.innerText = layer.strength;
      
      const signal = document.getElementById(`dga-inline-layer${num}-signal`);
      if (signal) signal.innerText = layer.signal;
      
      const conf = document.getElementById(`dga-inline-layer${num}-confidence`);
      if (conf) conf.style.width = layer.confidence + '%';
      
      const confText = document.getElementById(`dga-inline-layer${num}-confidence-text`);
      if (confText) confText.innerText = layer.confidence + '%';
      
      const reason = document.getElementById(`dga-inline-layer${num}-reason`);
      if (reason) reason.innerText = layer.reason || '--';
      
      card.className = `dga-layer-card dga-layer${num}-active`;
      if (layer.direction === 'long') card.classList.add('dga-layer-long');
      else if (layer.direction === 'short') card.classList.add('dga-layer-short');
      
      if (badge) {
        if (layer.strength === 'قوی') badge.style.background = 'rgba(16, 185, 129, 0.3)';
        else if (layer.strength === 'متوسط') badge.style.background = 'rgba(245, 158, 11, 0.3)';
        else badge.style.background = 'rgba(107, 114, 128, 0.3)';
      }
      
      const slTpDiv = document.getElementById(`dga-inline-layer${num}-sl-tp`);
      if (slTpDiv) {
        if (layer.sl && layer.tp) {
          slTpDiv.style.display = 'flex';
          const slEl = document.getElementById(`dga-inline-layer${num}-sl`);
          const tpEl = document.getElementById(`dga-inline-layer${num}-tp`);
          if (slEl) slEl.innerText = layer.sl;
          if (tpEl) tpEl.innerText = layer.tp;
        } else {
          slTpDiv.style.display = 'none';
        }
      }
    });

    if (data.consensus) {
      const card = document.getElementById('dga-inline-consensus-card');
      const textEl = document.getElementById('dga-inline-consensus-text');
      const confEl = document.getElementById('dga-inline-consensus-confidence');
      
      if (card && textEl && confEl) {
        card.className = 'dga-consensus-card';
        if (data.consensus.direction === 'long') card.classList.add('dga-consensus-long');
        else if (data.consensus.direction === 'short') card.classList.add('dga-consensus-short');
        
        let scenarioText = '';
        if (data.consensus.scenario) {
          scenarioText = ` — ${data.consensus.scenario}`;
        }
        textEl.innerText = data.consensus.text + scenarioText;
        confEl.innerText = data.consensus.confidence + '%';
      }
    }
  }

  function getBadgeClass(signal) {
    if (!signal) return 'dga-tv-neutral';
    const s = signal.toLowerCase();
    if (s.includes('strong buy')) return 'dga-tv-strong-buy';
    if (s.includes('strong sell')) return 'dga-tv-strong-sell';
    if (s.includes('buy')) return 'dga-tv-buy';
    if (s.includes('sell')) return 'dga-tv-sell';
    return 'dga-tv-neutral';
  }
  
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'TOGGLE_INLINE') {
      if (request.enabled) {
        chrome.storage.local.set({ inlineEnabled: true }, () => {
          createInlinePanel();
        });
      } else {
        chrome.storage.local.set({ inlineEnabled: false }, () => {
          const panel = document.getElementById('dga-inline-panel');
          if (panel) panel.remove();
          
          if (isAlpha) {
            const iframe = document.getElementById('myIframe');
            if (iframe) {
              iframe.style.width = '100%';
              iframe.style.minHeight = '500px';
            }
            const container = document.getElementById('dga-inline-container');
            if (container) container.remove();
          }
          location.reload();
        });
      }
      sendResponse({ success: true });
      return true;
    }

    if (request.action === 'CHECK_INLINE_PANEL') {
      const panel = document.getElementById('dga-inline-panel');
      sendResponse({ exists: !!panel });
      return true;
    }
  
    if (request.action === 'SUBSCRIPTION_STATUS') {
      isInlineSubscriptionValid = request.valid;
      
      if (!isInlineSubscriptionValid) {
        chrome.storage.local.set({ inlineEnabled: false }, () => {
          const panel = document.getElementById('dga-inline-panel');
          if (panel) panel.remove();
          
          if (isAlpha) {
            const iframe = document.getElementById('myIframe');
            if (iframe) {
              iframe.style.width = '100%';
              iframe.style.minHeight = '500px';
            }
            const container = document.getElementById('dga-inline-container');
            if (container) container.remove();
          }
        });
      } else {
        chrome.storage.local.get(['inlineEnabled'], (r) => {
          if (r.inlineEnabled === true && !document.getElementById('dga-inline-panel')) {
            createInlinePanel();
          }
        });
      }
    }
  });

  window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'DGA_UPDATE_DATA') {
      updateInlinePanel(event.data.data);
    }
  });

  chrome.storage.local.get(['inlineEnabled', 'dga_subscription_valid'], (result) => {
    if (result.inlineEnabled === true && result.dga_subscription_valid === true) {
      createInlinePanel();
      
      const interval = setInterval(() => {
        if (document.getElementById('dga-inline-panel')) {
          clearInterval(interval);
          return;
        }
        chrome.storage.local.get(['inlineEnabled', 'dga_subscription_valid'], (r) => {
          if (r.inlineEnabled === true && r.dga_subscription_valid === true) {
            createInlinePanel();
          }
        });
      }, 500);
    }
  });

  window.DGA_INLINE = {
    update: updateInlinePanel,
    create: createInlinePanel
  };
})();