// content.js - نسخه ۷.۱.۰
(function() {
  'use strict';

  const state = {
    ohlcv: [],
    price: 0,
    currentTF: '1m',
    isFirstTime: !localStorage.getItem('dga_onboarded'),
    higherTFData: {},
    lastAlarmTime: {},
    layerResetTimes: { 1: 0, 2: 0, 3: 0, 4: 0 }
  };

  console.log('%c[Goldmun] Content Script Loaded. 🎯', 'color: cyan; font-weight: bold;');

  chrome.runtime.sendMessage({ action: "inject_early" });

  // ═══════════════════════════════════════════════════════════
  // ساخت پنل فقط بعد از تأیید اشتراک
  // ═══════════════════════════════════════════════════════════
  function ensurePanelExists() {
    if (document.getElementById('dga-panel')) return;
    chrome.storage.local.get(['dga_subscription_valid', 'panelHidden'], (result) => {
      if (result.dga_subscription_valid !== true) {
        console.log('[Goldmun] Panel creation prevented: subscription invalid');
        return;
      }
      if (result.panelHidden === true) {
        console.log('[Goldmun] Panel creation prevented: panel hidden');
        return;
      }
      if (window.DGA_UI && window.DGA_UI.createPanel) {
        window.DGA_UI.createPanel();
      }
    });
  }

  const initInterval = setInterval(() => {
    if (document.body) {
      ensurePanelExists();
      clearInterval(initInterval);
    }
  }, 300);

  if (document.body) {
    ensurePanelExists();
    clearInterval(initInterval);
  }

  // ═══════════════════════════════════════════════════════════
  // مدیریت هوشمند گپ زمانی
  // ═══════════════════════════════════════════════════════════
  let isDataStale = false;
  let hasShownStaleModal = false;

// content.js - بخش ابتدایی (فقط بخش مربوط به readCandlesFromStorage و showStaleDataModal تغییر کرده است)
// در فایل content.js خود، این بخش‌ها را جایگزین کنید:

  function readCandlesFromStorage() {
    try {
      state.currentTF = '1m';

      chrome.storage.local.get(['dga_subscription_valid'], (result) => {
        if (result.dga_subscription_valid !== true) {
          if (window.DGA_UI) {
            window.DGA_UI.update({
              candlesCount: 0, price: 0, isFirstTime: false,
              layer1: null, layer2: null, layer3: null, layer4: null,
              consensus: null, volatilityWarning: false, tvData: null, staleWarning: false
            });
          }
          return;
        }

        const path = window.location.pathname;
        const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
        const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';

        const currentKey = `goldmun_candles_${host}_${symbol}_1m`;
        const stored = localStorage.getItem(currentKey);

        if (!stored) {
          state.ohlcv = [];
          if (window.DGA_UI) window.DGA_UI.update({
            candlesCount: 0, price: 0, isFirstTime: state.isFirstTime,
            layer1: null, layer2: null, layer3: null, layer4: null,
            consensus: null, volatilityWarning: false, tvData: null, staleWarning: isDataStale
          });
          return;
        }

        const candles = JSON.parse(stored);
        if (candles.length > 0) {
          const lastCandle = candles[candles.length - 1];
          const now = Date.now();
          const gapMinutes = Math.floor((now - lastCandle.time) / 60000);

          // 👈 این بخش مستقل از inject.js گپ را چک می‌کند
          if (gapMinutes > 60 && !isDataStale) {
            isDataStale = true;
            if (!hasShownStaleModal) {
              showStaleDataModal(gapMinutes);
              hasShownStaleModal = true;
            }
          }

          if (gapMinutes <= 60) {
            isDataStale = false;
            hasShownStaleModal = false;
            localStorage.removeItem('goldmun_gap_detected'); // پاک کردن فلگ
          }

          state.ohlcv = candles;
          state.price = candles[candles.length - 1].close;
        }
      });
    } catch (e) {
      console.error('[Goldmun] Read Error:', e);
    }
  }

  function showStaleDataModal(gapMinutes) {
    if (document.getElementById('dga-stale-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'dga-stale-modal';
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.85); z-index: 1000000;
      display: flex; align-items: center; justify-content: center;
      font-family: Vazirmatn, Tahoma, sans-serif; direction: rtl;
    `;

    modal.innerHTML = `
      <div style="background: #1f2937; border: 2px solid #f59e0b; border-radius: 12px; padding: 20px; max-width: 420px; text-align: center; color: #f9fafb; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
        <div style="font-size: 40px; margin-bottom: 10px;">⏳</div>
        <h3 style="color: #fbbf24; margin-bottom: 10px; font-size: 16px;">وقفه در دریافت دیتا!</h3>
        <p style="font-size: 12px; color: #d1d5db; line-height: 1.7; margin-bottom: 15px;">
          آخرین کندل <b>${gapMinutes} دقیقه</b> پیش ثبت شده است (بیش از ۱ ساعت).
          <br>آیا مایلید دیتای قدیمی پاک شود و از الان شروع کنیم؟
        </p>
        <div style="display: flex; gap: 10px; justify-content: center;">
          <button id="dga-stale-reset" style="background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; flex: 1;">ریست کن</button>
          <button id="dga-stale-cancel" style="background: #4b5563; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; flex: 1;">بعداً</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('dga-stale-reset').onclick = () => {
      const path = window.location.pathname;
      const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
      const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';

      Object.keys(localStorage).forEach(key => {
        if (key.startsWith(`goldmun_candles_${host}_${symbol}_`)) {
          localStorage.removeItem(key);
        }
      });

      state.ohlcv = [];
      state.layerResetTimes = { 1: 0, 2: 0, 3: 0, 4: 0 };
      isDataStale = false;
      hasShownStaleModal = false;
      modal.remove();

      window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
    };

    document.getElementById('dga-stale-cancel').onclick = () => {
      modal.remove();
    };
  }
  
  function showStaleDataModal(gapMinutes) {
    if (document.getElementById('dga-stale-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'dga-stale-modal';
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.85); z-index: 1000000;
      display: flex; align-items: center; justify-content: center;
      font-family: Vazirmatn, Tahoma, sans-serif; direction: rtl;
    `;

    modal.innerHTML = `
      <div style="background: #1f2937; border: 2px solid #f59e0b; border-radius: 12px; padding: 20px; max-width: 420px; text-align: center; color: #f9fafb; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
        <div style="font-size: 40px; margin-bottom: 10px;">⏳</div>
        <h3 style="color: #fbbf24; margin-bottom: 10px; font-size: 16px;">وقفه در دریافت دیتا!</h3>
        <p style="font-size: 12px; color: #d1d5db; line-height: 1.7; margin-bottom: 15px;">
          آخرین کندل <b>${gapMinutes} دقیقه</b> پیش ثبت شده است (بیش از ۱ ساعت).
          <br>آیا مایلید دیتای قدیمی پاک شود و از الان شروع کنیم؟
        </p>
        <div style="display: flex; gap: 10px; justify-content: center;">
          <button id="dga-stale-reset" style="background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; flex: 1;">ریست کن</button>
          <button id="dga-stale-cancel" style="background: #4b5563; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; flex: 1;">بعداً</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('dga-stale-reset').onclick = () => {
      const path = window.location.pathname;
      const symbol = path.includes('mazaneh') ? 'MAZANEH' : 'OUNCE';
      const host = window.location.hostname.includes('alphagoldx') ? 'ALPHA' : 'DARYA';

      Object.keys(localStorage).forEach(key => {
        if (key.startsWith(`goldmun_candles_${host}_${symbol}_`)) {
          localStorage.removeItem(key);
        }
      });

      state.ohlcv = [];
      state.layerResetTimes = { 1: 0, 2: 0, 3: 0, 4: 0 };
      isDataStale = false;
      hasShownStaleModal = false;
      modal.remove();

      window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
    };

    document.getElementById('dga-stale-cancel').onclick = () => {
      modal.remove();
    };
  }

  setInterval(readCandlesFromStorage, 1000);
  setInterval(runAnalysis, 1000);

  function getTradingSession() {
    const hour = new Date().getHours();
    if (hour >= 2 && hour < 10) {
      return { name: 'آسیا', warning: true, message: '⚠️ سشن آسیا — نقدینگی کم، با احتیاط معامله کن.' };
    }
    if (hour >= 10 && hour < 18) {
      return { name: 'لندن', warning: false, message: '✅ سشن لندن — نقدینگی مناسب.' };
    }
    return { name: 'نیویورک', warning: false, message: '✅ سشن نیویورک — نقدینگی بالا.' };
  }

  async function getTVDataFromStorage() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['tv_data'], (result) => {
        if (result.tv_data && Date.now() - result.tv_data.timestamp < 30000) {
          resolve(result.tv_data);
        } else {
          resolve(null);
        }
      });
    });
  }

  async function runAnalysis() {
    const count = state.ohlcv.length;
    if (count < 1) return;
    if (isDataStale) return;

    try {
      const session = getTradingSession();
      const closes = state.ohlcv.map(c => c.close);
      const highs = state.ohlcv.map(c => c.high);
      const lows = state.ohlcv.map(c => c.low);
      const price = closes[closes.length - 1];

      const atr = calcATR(highs, lows, closes, 14) || 0;
      const atrPct = price > 0 ? (atr / price) * 100 : 0;
      const volatilityWarning = atrPct > 0.5;

      const tvData = await getTVDataFromStorage();

      let layer1 = null, layer2 = null, layer3 = null, layer4 = null;

      if (count >= 3) {
        const rsi = calcRSI(closes, 3) || 50;
        const stoch = calcStochastic(highs, lows, closes, 3) || 50;
        const atr3 = calcATR(highs, lows, closes, 3) || 0;
        let score = 0;
        if (rsi > 52) score += 1.0; else if (rsi < 48) score -= 1.0;
        if (stoch > 55) score += 0.4; else if (stoch < 45) score -= 0.4;
        let trend = 'neutral', confidence = 0;
        if (score >= 1.0) trend = 'long'; else if (score <= -1.0) trend = 'short';
        confidence = Math.round((Math.abs(score) / 1.4) * 100);
        if (trend === 'neutral') confidence = Math.round(confidence * 0.3);
        confidence = Math.min(80, Math.max(1, confidence || 1));

        let sl = null, tp = null;
        if (trend !== 'neutral' && atr3 > 0) {
          if (trend === 'long') { sl = price - atr3 * 1.0; tp = price + atr3 * 1.5; }
          else { sl = price + atr3 * 1.0; tp = price - atr3 * 1.5; }
        }

        layer1 = {
          signal: trend === 'long' ? 'خرید' : (trend === 'short' ? 'فروش' : 'خنثی'),
          direction: trend, confidence, strength: confidence >= 70 ? 'قوی' : (confidence >= 40 ? 'متوسط' : 'ضعیف'),
          recommendation: '⚡', reason: `RSI=${rsi.toFixed(0)}`,
          sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, layer: 1
        };
      }

      if (count >= 15) {
        const rsi = calcRSI(closes, 14) || 50;
        const stoch = calcStochastic(highs, lows, closes, 14) || 50;
        const willr = calcWilliamsR(highs, lows, closes, 14) || -50;
        const atr15 = calcATR(highs, lows, closes, 14) || 0;
        let score = 0;
        if (rsi > 53) score += 1.0; else if (rsi < 47) score -= 1.0;
        if (stoch > 55) score += 0.4; else if (stoch < 45) score -= 0.4;
        if (willr > -40) score += 0.3; else if (willr < -60) score -= 0.3;
        let trend = 'neutral', confidence = 0;
        if (score >= 1.2) trend = 'long'; else if (score <= -1.2) trend = 'short';
        confidence = Math.round((Math.abs(score) / 1.7) * 100);
        if (trend === 'neutral') confidence = Math.round(confidence * 0.3);
        confidence = Math.min(85, Math.max(1, confidence || 1));

        let sl = null, tp = null;
        if (trend !== 'neutral' && atr15 > 0) {
          if (trend === 'long') { sl = price - atr15 * 1.2; tp = price + atr15 * 2.0; }
          else { sl = price + atr15 * 1.2; tp = price - atr15 * 2.0; }
        }

        layer2 = {
          signal: trend === 'long' ? 'خرید' : (trend === 'short' ? 'فروش' : 'خنثی'),
          direction: trend, confidence, strength: confidence >= 70 ? 'قوی' : (confidence >= 40 ? 'متوسط' : 'ضعیف'),
          recommendation: '🎯', reason: `RSI=${rsi.toFixed(0)}`,
          sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, layer: 2
        };
      }

      if (count >= 50) {
        const ema20 = calcEMA(closes, 20).pop() || price;
        const ema50 = calcEMA(closes, 50).pop() || price;
        const rsi = calcRSI(closes, 14) || 50;
        const atr50 = calcATR(highs, lows, closes, 14) || 0;
        const bb = calcBB(closes, 20, 2);
        const macd = calcMACD(closes, 12, 26, 9);
        const cci = calcCCI(highs, lows, closes, 20) || 0;
        let signals = [];
        if (price > ema50) signals.push(1); else signals.push(-1);
        if (ema20 > ema50) signals.push(1); else signals.push(-1);
        if (macd.hist > 0) signals.push(1); else signals.push(-1);
        if (rsi > 50) signals.push(1); else signals.push(-1);
        if (price < bb.lower) signals.push(1); else if (price > bb.upper) signals.push(-1); else signals.push(0);
        if (cci > 100) signals.push(1); else if (cci < -100) signals.push(-1); else signals.push(0);
        const sum = signals.reduce((a, b) => a + b, 0);
        let trend = 'neutral';
        if (sum >= 3) trend = 'long'; else if (sum <= -3) trend = 'short';
        let confidence = Math.round((Math.abs(sum) / 6) * 100);
        if (trend === 'neutral') confidence = Math.round(confidence * 0.3);
        confidence = Math.min(90, Math.max(1, confidence || 1));

        let sl = null, tp = null;
        if (trend !== 'neutral' && atr50 > 0) {
          if (trend === 'long') { sl = price - atr50 * 1.3; tp = price + atr50 * 2.2; }
          else { sl = price + atr50 * 1.3; tp = price - atr50 * 2.2; }
        }

        layer3 = {
          signal: trend === 'long' ? 'خرید' : (trend === 'short' ? 'فروش' : 'خنثی'),
          direction: trend, confidence, strength: confidence >= 70 ? 'قوی' : (confidence >= 40 ? 'متوسط' : 'ضعیف'),
          recommendation: '📊', reason: `EMA | MACD`,
          sl: sl ? sl.toFixed(2) : null, tp: tp ? tp.toFixed(2) : null, layer: 3
        };
      }

      if (count >= 200) {
        const res = window.DGA_Analyzer.analyze(state, state.currentTF, 'aggressive');
        if (res) {
          let signalFa = 'خنثی';
          if (res.direction === 'long') signalFa = 'خرید';
          else if (res.direction === 'short') signalFa = 'فروش';

          layer4 = {
            signal: signalFa, direction: res.direction, confidence: res.confidence,
            strength: res.confidence >= 70 ? 'قوی' : (res.confidence >= 40 ? 'متوسط' : 'ضعیف'),
            recommendation: '🏆', reason: res.overrideReason || `ADX: ${res.adx}`,
            sl: res.sl, tp: res.tp, rsi: res.rsi, atr: res.groups?.volatility?.details?.atr?.toFixed(2) || '--',
            layer: 4
          };
        }
      }

      // سیستم رأی‌گیری وزنی
      let tvOscDir = null, tvMaDir = null, tvSumDir = null;

      if (tvData) {
        if (tvData.oscillatorsSignal) {
          const osc = tvData.oscillatorsSignal.toLowerCase();
          if (osc.includes('buy')) tvOscDir = 'long';
          else if (osc.includes('sell')) tvOscDir = 'short';
          else tvOscDir = 'neutral';
        }
        if (tvData.movingAveragesSignal) {
          const ma = tvData.movingAveragesSignal.toLowerCase();
          if (ma.includes('buy')) tvMaDir = 'long';
          else if (ma.includes('sell')) tvMaDir = 'short';
          else tvMaDir = 'neutral';
        }
        if (tvData.summary) {
          const sum = tvData.summary.toLowerCase();
          if (sum.includes('buy')) tvSumDir = 'long';
          else if (sum.includes('sell')) tvSumDir = 'short';
          else tvSumDir = 'neutral';
        }
      }

      const WEIGHTS = {
        layer1: 1.0, layer2: 1.5, layer3: 2.0, layer4: 3.0,
        tvSum: 2.0, tvOsc: 1.0, tvMa: 1.0
      };

      let W_long = 0, W_short = 0, W_neutral = 0;
      let longVotes = 0, shortVotes = 0, neutralVotes = 0;

      function addWeightedVote(dir, weight) {
        if (dir === 'long') { W_long += weight; longVotes++; }
        else if (dir === 'short') { W_short += weight; shortVotes++; }
        else { W_neutral += weight * 0.5; neutralVotes++; }
      }

      if (layer1) addWeightedVote(layer1.direction, WEIGHTS.layer1);
      if (layer2) addWeightedVote(layer2.direction, WEIGHTS.layer2);
      if (layer3) addWeightedVote(layer3.direction, WEIGHTS.layer3);
      if (layer4) addWeightedVote(layer4.direction, WEIGHTS.layer4);
      if (tvSumDir !== null) addWeightedVote(tvSumDir, WEIGHTS.tvSum);
      if (tvOscDir !== null) addWeightedVote(tvOscDir, WEIGHTS.tvOsc);
      if (tvMaDir !== null) addWeightedVote(tvMaDir, WEIGHTS.tvMa);

      const W_total = W_long + W_short + W_neutral;

      let finalDirection = 'neutral';
      let finalConfidence = 0;

      if ((longVotes + shortVotes) >= 2) {
        if (W_long > W_short) {
          finalDirection = 'long';
          finalConfidence = Math.round(((W_long - W_short) / W_total) * 100);
        } else if (W_short > W_long) {
          finalDirection = 'short';
          finalConfidence = Math.round(((W_short - W_long) / W_total) * 100);
        }
      }

      let trapProb = 0;
      let reversalProb = 0;
      const rsi14 = calcRSI(closes, 14) || 50;
      const bb = calcBB(closes, 20, 2);

      if (rsi14 > 70 || rsi14 < 30) trapProb += 35;
      if (price > bb.upper || price < bb.lower) trapProb += 25;

      if (rsi14 > 70 && finalDirection === 'short') reversalProb += 30;
      if (rsi14 < 30 && finalDirection === 'long') reversalProb += 30;

      trapProb = Math.min(100, Math.max(0, trapProb));
      reversalProb = Math.min(100, Math.max(0, reversalProb));

      let scenarioText = '';
      if (trapProb > 60) scenarioText = '⚠️ احتمال تله بالا! وارد نشو.';
      else if (reversalProb > 60) scenarioText = '🔄 احتمال برگشت بالا: روند خسته شده.';
      else if (finalConfidence >= 70) scenarioText = '✅ اجماع بالا: روند قوی.';
      else if (finalConfidence >= 40) scenarioText = '🟢 سیگنال معتبر.';
      else scenarioText = '⚪ بازار در تعادل.';

      let consensusText = '';
      if (finalDirection === 'long') {
        if (finalConfidence >= 70) consensusText = '✅ سیگنال قوی خرید.';
        else if (finalConfidence >= 40) consensusText = '🟢 سیگنال خرید.';
        else consensusText = '🟡 خرید ضعیف.';
      } else if (finalDirection === 'short') {
        if (finalConfidence >= 70) consensusText = '🔴 سیگنال قوی فروش.';
        else if (finalConfidence >= 40) consensusText = '🟠 سیگنال فروش.';
        else consensusText = '🟡 فروش ضعیف.';
      } else {
        consensusText = '⚪ خنثی.';
      }

      const consensus = {
        direction: finalDirection,
        confidence: finalConfidence,
        text: consensusText,
        scenario: scenarioText,
        trapProb: trapProb,
        reversalProb: reversalProb,
        longVotes, shortVotes, neutralVotes
      };

      if (window.DGA_UI && window.DGA_UI.update) {
        window.DGA_UI.update({
          candlesCount: count,
          price: state.price,
          isFirstTime: state.isFirstTime,
          session: session,
          layer1: layer1,
          layer2: layer2,
          layer3: layer3,
          layer4: layer4,
          consensus: consensus,
          volatilityWarning: volatilityWarning,
          tvData: tvData
        });
      }

      window.postMessage({ type: 'DGA_UPDATE_DATA', data: {
        price: state.price,
        tvData: tvData,
        consensus: consensus
      }}, '*');

      [layer1, layer2, layer3, layer4].forEach(layer => {
        if (layer && layer.confidence >= 90) {
          const layerNum = layer.layer;
          const isEnabled = localStorage.getItem(`dga_alarm_layer_${layerNum}`) !== 'false';
          const soundEnabled = localStorage.getItem('dga_sound_enabled') !== 'false';
          if (isEnabled && soundEnabled) {
            if (state.lastAlarmTime[layerNum] !== layer.direction) {
              state.lastAlarmTime[layerNum] = layer.direction;
              if (window.DGA_UI) {
                if (window.DGA_UI.playBeep) window.DGA_UI.playBeep();
                if (window.DGA_UI.flashCard) window.DGA_UI.flashCard(layerNum);
              }
            }
          }
        }
      });

    } catch (err) {
      console.error('[Goldmun] Analysis Error:', err);
    }
  }

  // ابزارهای مشترک (بدون تغییر)
  function calcEMA(data, period) {
    const ema = []; const k = 2 / (period + 1); let prev = null;
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) { ema.push(null); continue; }
      if (prev === null) { let sum = 0; for (let j = 0; j < period; j++) sum += data[i - j]; prev = sum / period; }
      else { prev = (data[i] - prev) * k + prev; }
      ema.push(prev);
    }
    return ema;
  }
  function calcMACD(closes, fast = 12, slow = 26, signal = 9) {
    const emaFast = calcEMA(closes, fast); const emaSlow = calcEMA(closes, slow);
    const macdLine = []; for (let i = 0; i < closes.length; i++) { if (emaFast[i] !== null && emaSlow[i] !== null) macdLine.push(emaFast[i] - emaSlow[i]); else macdLine.push(null); }
    const validMacd = macdLine.filter(v => v !== null); const signalLine = calcEMA(validMacd, signal);
    const alignedSignal = []; let idx = 0;
    for (let i = 0; i < macdLine.length; i++) { if (macdLine[i] !== null) { alignedSignal.push(signalLine[idx] !== undefined ? signalLine[idx] : null); idx++; } else alignedSignal.push(null); }
    const hist = []; for (let i = 0; i < macdLine.length; i++) { if (macdLine[i] !== null && alignedSignal[i] !== null) hist.push(macdLine[i] - alignedSignal[i]); else hist.push(null); }
    return { macd: macdLine, signal: alignedSignal, hist: hist[hist.length - 1] || 0 };
  }
  function calcRSI(closes, period = 14) {
    if (!Array.isArray(closes) || closes.length < period + 1) return null;
    let gain = 0, loss = 0;
    for (let i = 1; i <= period; i++) { const diff = closes[i] - closes[i - 1]; gain += Math.max(diff, 0); loss += Math.max(-diff, 0); }
    let avgGain = gain / period, avgLoss = loss / period;
    for (let i = period + 1; i < closes.length; i++) { const diff = closes[i] - closes[i - 1]; avgGain = (avgGain * (period - 1) + Math.max(diff, 0)) / period; avgLoss = (avgLoss * (period - 1) + Math.max(-diff, 0)) / period; }
    if (avgGain === 0 && avgLoss === 0) return 50; if (avgLoss === 0) return 100; if (avgGain === 0) return 0;
    const rs = avgGain / avgLoss; return 100 - 100 / (1 + rs);
  }
  function calcATR(highs, lows, closes, period = 14) {
    const n = closes.length; if (n < period + 1 || highs.length !== n || lows.length !== n) return null;
    const tr = []; for (let i = 1; i < n; i++) { if (!Number.isFinite(highs[i]) || !Number.isFinite(lows[i]) || !Number.isFinite(closes[i - 1])) return null; tr.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]))); }
    if (tr.length < period) return null; let atr = tr.slice(0, period).reduce((sum, v) => sum + v, 0) / period;
    for (let i = period; i < tr.length; i++) { atr = (atr * (period - 1) + tr[i]) / period; }
    return Number.isFinite(atr) ? atr : null;
  }
  function calcStochastic(highs, lows, closes, period = 14) {
    if (closes.length < period) return 50; let highest = -Infinity; let lowest = Infinity;
    for (let i = closes.length - period; i < closes.length; i++) { highest = Math.max(highest, highs[i]); lowest = Math.min(lowest, lows[i]); }
    const denom = highest - lowest; if (denom === 0) return 50; return ((closes[closes.length - 1] - lowest) / denom) * 100;
  }
  function calcWilliamsR(highs, lows, closes, period = 14) {
    if (closes.length < period) return -50; let highest = -Infinity; let lowest = Infinity;
    for (let i = closes.length - period; i < closes.length; i++) { highest = Math.max(highest, highs[i]); lowest = Math.min(lowest, lows[i]); }
    const denom = highest - lowest; if (denom === 0) return -50; return ((highest - closes[closes.length - 1]) / denom) * -100;
  }
  function calcBB(closes, period = 20, stdDev = 2) {
    if (closes.length < period) return { upper: 0, lower: 0, mid: 0 };
    const slice = closes.slice(-period); const mid = slice.reduce((a, b) => a + b, 0) / period;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mid, 2), 0) / period; const std = Math.sqrt(variance);
    return { upper: mid + stdDev * std, lower: mid - stdDev * std, mid };
  }
  function calcCCI(highs, lows, closes, period = 20) {
    if (closes.length < period) return 0; const sliceH = highs.slice(-period); const sliceL = lows.slice(-period); const sliceC = closes.slice(-period);
    const tp = []; for (let i = 0; i < period; i++) { tp.push((sliceH[i] + sliceL[i] + sliceC[i]) / 3); }
    const sma = tp.reduce((a, b) => a + b, 0) / period; let meanDev = 0;
    for (let i = 0; i < period; i++) { meanDev += Math.abs(tp[i] - sma); } meanDev /= period;
    if (meanDev === 0) return 0; return (tp[tp.length - 1] - sma) / (0.015 * meanDev);
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "TOGGLE_ENGINE") {
      if (!request.isOn) {
        if (window.DGA_UI) window.DGA_UI.update({ signal: 'خاموش', confidence: 0, direction: 'neutral', recommendation: 'موتور خاموش است' });
      } else { runAnalysis(); }
    }

    if (request.action === 'CHECK_FLOATING_PANEL') {
      const panel = document.getElementById('dga-panel');
      const isVisible = panel && panel.style.display !== 'none';
      sendResponse({ exists: isVisible });
      return true;
    }

    // 👈 پشتیبانی از RESET_CANDLES از پاپ‌آپ
    if (request.action === 'RESET_CANDLES') {
      window.postMessage({ type: 'DGA_RESET_DATA' }, '*');
      sendResponse({ success: true });
      return true;
    }
  });

  window.addEventListener('message', function(event) {
    if (event.data && event.data.type === 'DGA_TF_CHANGE') {
      state.currentTF = event.data.tf; state.ohlcv = []; state.higherTFData = {}; state.lastAlarmTime = {};
      readCandlesFromStorage();
    }
    if (event.data && event.data.type === 'DGA_RESET_DATA') { window.postMessage({ type: 'DGA_RESET_DATA' }, '*'); }
    if (event.data && event.data.type === 'DGA_DATA_CLEARED') {
      state.ohlcv = []; state.price = 0; state.lastAlarmTime = {};
      if (window.DGA_UI) window.DGA_UI.update({ candlesCount: 0, price: 0, layer1: null, layer2: null, layer3: null, layer4: null, consensus: null, volatilityWarning: false, tvData: null });
    }
  });

  if (state.isFirstTime) { localStorage.setItem('dga_onboarded', 'true'); }

  // ═══════════════════════════════════════════════════════════
  // ماژول PnL (بدون تغییر)
  // ═══════════════════════════════════════════════════════════
  function injectPnLPercentage() {
    try {
      chrome.storage.local.get(['optionalEnabled'], (result) => {
        if (!result.optionalEnabled) {
          document.querySelectorAll('.dga-pnl-container').forEach(el => el.remove());
          return;
        }

        const isAlpha = window.location.hostname.includes('alphagoldx');
        let baseMargin = 1000000;
        let livePrice = '--';

        if (isAlpha) {
          const priceDivs = document.querySelectorAll('.bg-mainColor3');
          for (let div of priceDivs) {
            if (div.innerText && div.innerText.includes('انس')) {
              const match = div.innerText.match(/انس\s*:\s*([\d.]+)/);
              if (match) { livePrice = match[1]; break; }
            }
          }
        } else {
          const priceEl = document.querySelector('.text-indigo-700.tabular-nums, .dark\\:text-cyan-400.tabular-nums');
          if (priceEl) livePrice = priceEl.innerText.trim();
        }

        if (isAlpha) {
          const marginElements = document.querySelectorAll('span, div');
          for (let el of marginElements) {
            if (el.innerText && el.innerText.includes('وجه تضمین:')) {
              const parent = el.parentElement;
              if (parent) {
                const match = parent.innerText.match(/وجه تضمین:\s*([\d,]+)/);
                if (match) { baseMargin = parseFloat(match[1].replace(/,/g, '')); break; }
              }
            }
          }
        } else {
          const profileButtons = document.querySelectorAll('.grid.grid-cols-2.gap-2.p-1 button');
          for (let btn of profileButtons) {
            if (btn.innerText.includes('نیم واحدی') && (btn.classList.contains('bg-white') || btn.classList.contains('dark:bg-gray-800'))) {
              baseMargin = 500000; break;
            }
          }
        }

        const rows = document.querySelectorAll('tbody tr');

        rows.forEach(row => {
          const cells = row.querySelectorAll('td');
          if (cells.length < 6) return;

          let units = 0, pnlValue = 0, pnlCell = null;

          if (isAlpha) {
            const pnlSpan = row.querySelector('td:nth-child(5) span');
            if (!pnlSpan) return;
            pnlCell = row.querySelector('td:nth-child(5)');
            const amountText = cells[1] ? cells[1].innerText.trim() : '';
            units = parseFloat(amountText) || 0;
            const pnlText = pnlSpan.innerText.replace(/,/g, '').replace(/[^\d.-]/g, '');
            pnlValue = parseFloat(pnlText);
          } else {
            pnlCell = cells[4];
            if (!pnlCell) return;
            const pnlSpan = pnlCell.querySelector('span[dir="ltr"]');
            if (!pnlSpan) return;
            const amountText = cells[1] ? cells[1].innerText.trim() : '';
            units = parseFloat(amountText) || 0;
            const pnlText = pnlSpan.innerText.replace(/,/g, '').replace(/[^\d.-]/g, '');
            pnlValue = parseFloat(pnlText);
          }

          if (units <= 0 || isNaN(pnlValue)) return;

          const totalMargin = baseMargin * units;
          if (totalMargin === 0) return;
          const pnlPercentage = (pnlValue / totalMargin) * 100;

          let container = pnlCell.querySelector('.dga-pnl-container');
          if (!container) {
            container = document.createElement('div');
            container.className = 'dga-pnl-container';
            if (isAlpha) {
              const span = pnlCell.querySelector('span');
              if (span) span.after(container); else pnlCell.appendChild(container);
            } else {
              pnlCell.appendChild(container);
            }
          }

          let priceEl = container.querySelector('.dga-live-price');
          if (!priceEl) {
            priceEl = document.createElement('span');
            priceEl.className = 'dga-live-price tabular-nums text-xs mt-1 font-sans';
            priceEl.title = 'برای کپی قیمت لحظه‌ای کلیک کنید';
            container.appendChild(priceEl);

            priceEl.onclick = (e) => {
              e.stopPropagation();
              const text = priceEl.innerText;
              navigator.clipboard.writeText(text).then(() => {
                const orig = priceEl.innerText;
                priceEl.innerText = 'کپی شد!';
                priceEl.style.color = '#34d399';
                setTimeout(() => { priceEl.innerText = orig; }, 1500);
              }).catch(() => {});
            };
          }

          if (pnlPercentage > 0) priceEl.style.color = '#34d399';
          else if (pnlPercentage < 0) priceEl.style.color = '#f87171';
          else priceEl.style.color = '#9ca3af';

          priceEl.innerText = livePrice;

          let badge = container.querySelector('.dga-pnl-badge');
          if (!badge) {
            badge = document.createElement('span');
            badge.className = 'dga-pnl-badge tabular-nums font-sans';
            container.prepend(badge);
          }

          let bgColor, textColor, sign;
          if (pnlPercentage > 0) { bgColor = 'rgba(16, 185, 129, 0.15)'; textColor = '#34d399'; sign = '+'; }
          else if (pnlPercentage < 0) { bgColor = 'rgba(239, 68, 68, 0.15)'; textColor = '#f87171'; sign = ''; }
          else { bgColor = 'rgba(156, 163, 175, 0.15)'; textColor = '#9ca3af'; sign = ''; }

          badge.style.cssText = `
            display: inline-block; padding: 2px 6px; border-radius: 4px;
            font-size: 10px; font-weight: 700; background: ${bgColor}; color: ${textColor};
            direction: ltr;
          `;
          badge.innerText = `${sign}${pnlPercentage.toFixed(2)}%`;
        });
      });
    } catch (e) {
      console.error('[Goldmun] PnL Injection Error:', e);
    }
  }

  setInterval(injectPnLPercentage, 1000);

  // ═══════════════════════════════════════════════════════════
  // دکمه شناور برای باز کردن پاپ‌آپ در Kiwi (فقط صفحات صرافی)
  // ═══════════════════════════════════════════════════════════
  function addPopupFloatingButton() {
    // بررسی اینکه آیا در Kiwi هستیم (تشخیص از روی userAgent)
    const isKiwi = /Kiwi/i.test(navigator.userAgent);
    if (!isKiwi) return; // اگر مرورگر کروم دسکتاپ است، کاری نکن

    // اگر دکمه قبلاً اضافه شده، خارج شو
    if (document.getElementById('dga-popup-floating-btn')) return;

    // چک کردن وضعیت اشتراک (فقط وقتی کاربر لاگین است دکمه را نشان بده)
    chrome.storage.local.get(['dga_subscription_valid'], (result) => {
      if (result.dga_subscription_valid !== true) return; // اگر اشتراک ندارد، دکمه را نشان نده

      const btn = document.createElement('div');
      btn.id = 'dga-popup-floating-btn';
      btn.innerHTML = '⚙️'; // آیکون چرخ‌دنده
      btn.title = 'تنظیمات نوسان‌گیر تریدمون';
      
      btn.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: linear-gradient(135deg, #c89a49, #d6ad60);
        color: #07111f;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        cursor: pointer;
        z-index: 9999999;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        border: 2px solid rgba(255,255,255,0.2);
      `;

      btn.onmouseenter = () => { btn.style.transform = 'scale(1.1)'; };
      btn.onmouseleave = () => { btn.style.transform = 'scale(1)'; };

      btn.onclick = () => {
        // باز کردن پاپ‌آپ اکستنشن در یک تب جدید
        window.open(chrome.runtime.getURL('popup.html'), '_blank');
      };

      document.body.appendChild(btn);
    });
  }

  // اجرای تابع بعد از لود کامل صفحه
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addPopupFloatingButton);
  } else {
    addPopupFloatingButton();
  }
  // هر ۳ ثانیه چک کن که اگر اشتراک فعال شد دکمه اضافه شود
  setInterval(addPopupFloatingButton, 3000);



})();